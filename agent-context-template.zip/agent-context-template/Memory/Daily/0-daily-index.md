---
title: Daily Notes
type: context
tags: [context, daily, memory]
---

# Daily Notes

> Raw session capture. One file per day, multiple sessions separated by `---`.
> These are the input — the [[Skills/extraction/SKILL|extraction subagent]] reads them
> during nightly `/rem-cycle` and routes knowledge to topic notes in
> `Memory/People/`, `Memory/Lessons/`, `Memory/Preferences/`, and domain logs.

*(empty on day zero — the Stop hook will start capturing sessions here automatically)*
