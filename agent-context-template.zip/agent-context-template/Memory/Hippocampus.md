---
title: Hippocampus
type: hippocampus
tags: [hippocampus, working-memory]
updated: {{hatch_date}}
arc-updated: {{hatch_date}}
maintained-by: /rem-cycle (nightly hippo-refresh; Arc refreshed every ~48h)
---

# Hippocampus — {{agent_name}}'s Working Memory

> Always loaded (via `@Memory/Hippocampus.md` in vault root CLAUDE.md). **Now** = live state, rewritten every nightly `/rem-cycle`. **Arc** = strategic state, refreshed every ~48h. Everything else lives in the vault and is reached through the wikilinks below.

---

## Now

> Empty on day zero. The first `/rem-cycle` run after hatching populates this with current state derived from Memory/Daily/, Memory/Connectors/*, lookback findings, and Radar.md.

*(awaiting first /rem-cycle)*

---

## Arc

> Strategic state — major life/work threads. Refreshed every ~48h. Empty on day zero; populated by extraction over the first weeks as {{user_name}} works in the vault and the Stop hook captures sessions into Memory/Daily/.

*(awaiting first arc-refresh)*

---

## Pointers

- [[Radar]] — living operational priorities
- [[Memory/Daily/0-daily-index|Daily notes]] — raw session capture
- [[Memory/Weekly/0-weekly-index|Weekly syntheses]] — end-of-week distillation
- [[Memory/People/|People]] — one note per person, enriched by /lookback
- [[Skills/0-skills-index|Skills]] — reusable procedures
- [[Vault-Architecture]] — full system manual
