---
name: auto-dream
title: Auto Dream — Nightly Memory Consolidation
type: skill
created: 2026-04-06
updated: 2026-04-06
tags: [skill, memory, auto-dream, architecture]
trigger: "Nightly cron or manual invocation. Processes Daily/ entries into Memory/ topic notes."
---

# Auto Dream

> The librarian that turns daily noise into structured knowledge.

> **Note:** auto-dream is the predecessor to the current [[Skills/extraction/SKILL|Extraction (Librarian)]] skill. The nightly chain is now orchestrated by [[Skills/rem-cycle/SKILL|REM Cycle]]. auto-dream may be invoked standalone for historical backfill.

## Procedure

1. **Read all unprocessed Daily/ entries** (check for entries without `[->]` markers)
2. **For each learning/event/observation, determine the topic:**
   - Person mentioned? → `Memory/People/[Name].md`
   - Project-specific? → `Memory/Projects/[Project].md`
   - Preference or pattern? → `Memory/Preferences/[Topic].md`
   - Lesson learned? → `Memory/Lessons/[Topic].md`
   - Health/lifestyle? → `Memory/Health/[Topic].md`
3. **Route to the topic note:**
   - If topic note exists: append under a dated section
   - If topic note doesn't exist: create it with standard frontmatter
4. **Mark source as consolidated** in the Daily file:
   - Append `[-> Memory/People/Mom]` (or relevant path) inline after the paragraph
5. **Update wikilinks** in relevant index files if new connections emerge

## Rules

- Never delete or modify the original Daily/ entry text
- Only append consolidation markers
- If unsure where something routes, leave it unconsolidated and flag for review
- Run as [[Skills/session-handoff/SKILL|Session Handoff]] or nightly cron

## Topic Note Template

```yaml
---
title: "[Topic Name]"
type: memory
created: YYYY-MM-DD
updated: YYYY-MM-DD
tags: [memory, topic-category]
---

## Summary
[Auto Dream maintains this — 2-3 sentence overview]

## Timeline
### YYYY-MM-DD
[Consolidated entry from Daily/]
```
