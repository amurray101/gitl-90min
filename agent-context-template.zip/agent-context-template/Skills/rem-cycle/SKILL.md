---
name: rem-cycle
description: Master nightly orchestrator. Runs extract → embed → spider → radar-verify (apply mode) in sequence, then runs inline diagnostics, then writes one report. The full nightly vault chain in one process.
title: "REM Cycle — Nightly Vault Orchestrator"
type: skill
created: 2026-04-28
updated: 2026-05-07
tags: [skill, vault, orchestrator, automation, sleep, system]
trigger: "Nightly scheduler at 4:00am via launchd on macOS or Task Scheduler on Windows; or manual /rem-cycle"
---

# REM Cycle — Nightly Vault Orchestrator

> {{agent_name}}'s full nightly vault chain. Extracts, embeds, audits, verifies, and reports — in that order, in one process. The system catching {{agent_name}} when {{agent_name}} forgets, plus actually closing out the near-certain stuff via radar-verify.

This skill OWNS the night. It is the only nightly cron in the vault maintenance chain. Each subordinate skill runs in sequence; failure of one step does not block subsequent steps. Findings aggregate into a single dated report under `agent/Logs/rem-cycle/`.

## Design rules

1. **Sequential orchestration.** Subroutines run in fixed order: extract → session-retitle → embed → spider → radar-verify → hippo-refresh. Each step's status (ok / failed / error message) is captured in the report.
2. **Failure isolation.** If a step fails, capture the error, write it to the report, continue to the next step. Do not abort the chain. A failed subroutine becomes its own Radar item.
3. **One report per night.** All output goes to `agent/Logs/rem-cycle/YYYY-MM-DD.md` — top of the report has a 3-line summary for instant morning skim.
4. **Action authority bounded by never-delete-files rule.** Two auto-actions are allowed: (a) radar-verify in apply mode deletes Radar *lines* (not files) for HIGH-confidence cleared items; (b) hippo-refresh rewrites `Memory/Hippocampus.md` (atomic write of one file, no deletions). Inline diagnostics propose, never auto-fix. No file or directory is deleted by this skill or any of its subroutines.
5. **Idempotent Radar items.** If the same finding-fingerprint already exists in Radar, append `· Recurrence: <today>` rather than minting a duplicate.
6. **Cron-safe.** No HITL prompts. Skill must run unattended.

## Procedure

### Step 0 — Setup

1. Compute `today = YYYY-MM-DD` (system date, local timezone).
2. Ensure `agent/Logs/rem-cycle/` exists; create if missing.
3. Set `report_path = agent/Logs/rem-cycle/<today>.md`. If the file already exists, append a new dated section rather than overwriting.
4. Read `Radar.md` and harvest existing IDs (regex `r_[a-z0-9]{5}`) into a set — used for collision-checking new IDs.
5. Initialize per-step status tracker: `{extract: pending, session_retitle: pending, embed: pending, spider: pending, radar_verify: pending, hippo_refresh: pending}`.

### Step 1 — Extract (subroutine)

1. Invoke `/extract` via the Skill tool.
2. Capture: skill exit status, count of newly-routed daily files, list of routes (e.g., `2026-04-30.md → agent/Logs/...`).
3. On success: status = ok, summary in report.
4. On failure: status = failed, error message in report, queue a `rem-cycle: extract failed` Radar item, continue to Step 2.

### Step 1.5 — Session retitle (subroutine)

The Stop-hook (`agent/scripts/session-capture-hook.sh` on macOS/Linux, `agent/scripts/session-capture-hook.ps1` on Windows) writes one transcript per conversation under `Memory/Daily/sessions/` with a first-5-words slug and only baseline `[session, transcript, daily-<date>]` tags. This step retitles those files with content-derived slugs, assigns topical tags from the vault's color-coded taxonomy (wingen/swordpoint/foundry/academics/{{agent_name}}-infra/etc.), and writes the daily-side `sessions:` backlink array. Sits between extract and embed so embed indexes the renamed paths, new tags, and `sessions:` frontmatter.

1. Invoke [[Skills/session-retitle/SKILL|/session-retitle]] via the Skill tool.
2. The subroutine walks `Memory/Daily/sessions/` for files lacking `retitled: true`, asks the LLM for `{slug, tags[]}` per transcript, renames the file (preserving date+HHMM prefix + `session_id` frontmatter), merges the topical tags into the existing `tags:` list (never drops baseline tags), then merges a `sessions:` array of wikilinks into the matching `Memory/Daily/<date>.md` frontmatter. Cap 50/run; idempotent via `retitled:` flag.
3. Capture: skill exit status + summary structure (`candidates_found`, `renamed`, `tagged`, `tag_frequency`, `skipped`, `errors`, `daily_files_updated`, `backlog_remaining`, `sample_renames`).
4. On success: status = ok, summary in report.
5. On failure: status = failed, error in report, queue `rem-cycle: session-retitle failed` Radar item, continue to Step 2.

### Step 2 — Embed (subroutine)

1. Invoke `/embed` via the Skill tool.
2. Capture: skill exit status, count of newly-embedded files.
3. On success: status = ok, embedded count in report.
4. On failure: status = failed, error in report, queue `rem-cycle: embed failed`, continue to Step 3.

### Step 3 — Spider (subroutine)

1. Invoke `/spider` via the Skill tool.
2. Capture: skill exit status, summary (orphans resolved, wikilinks added, tags applied, Context.md files refreshed).
3. On success: status = ok, summary in report.
4. On failure: status = failed, error in report, queue `rem-cycle: spider failed`, continue to Step 4.

### Step 4 — Radar Verify in apply mode (subroutine, the one auto-action)

1. Invoke `/radar-verify` via the Skill tool with `apply` mode.
2. radar-verify walks every Radar item with a `✓ Done when:` clause, probes for evidence, and:
   - **Auto-deletes** HIGH-confidence cleared items from `Radar.md` (line removal — within the never-delete-files rule).
   - Surfaces **MEDIUM** candidates for review.
   - Lists items **missing Done-when criteria**.
3. Capture: cleared count + IDs, MEDIUM candidates, missing-criteria items.
4. On success: status = ok, verifier output in report.
5. On failure: status = failed, error in report, queue `rem-cycle: radar-verify failed`, continue to Step 5.

### Step 5 — Hippocampus refresh (subroutine, the second auto-action)

The morning-fresh step. Where v1 of rem-cycle ran a read-only drift watchdog and queued Radar items if Hippocampus went stale, v2 rewrites it directly — `/handoff` is sunsetting in favor of hooks, and rem-cycle is now the canonical morning state of working memory.

1. Invoke [[Skills/hippo-refresh/SKILL|/hippo-refresh]] via the Skill tool.
2. The subroutine reads `Memory/Hippocampus.md` frontmatter, computes `arc_age_hours`, gathers last 3 days of `Memory/Daily/` + current `Radar.md`, rewrites the `## Now` block from scratch, and rewrites `## Arc` only if `arc-updated:` is ≥48h stale. Pruning rubric P1–P5 (defined in the subroutine's SKILL.md) drops items that no longer have an upstream referent.
3. Atomic write: tmp-file + rename. A crash mid-write leaves the prior Hippocampus intact.
4. Capture: skill exit status + summary structure (`now_rewritten`, `arc_rewritten`, `arc_age_hours_at_start`, items pruned by section, `word_count`, `oversize_warning`).
5. On success: status = ok, summary in report.
6. On failure: status = failed, error in report, queue `rem-cycle: hippo-refresh failed` Radar item, continue to Step 6.

**Frontmatter discipline still enforced — but as a precondition, not a watchdog.** `/hippo-refresh` itself respects the scalar-timestamp rule (per [[Skills/session-handoff/SKILL|session-handoff]] line 142). If the subroutine encounters malformed frontmatter on the existing file, it logs `HIPPO_FRONTMATTER_RECOVERED` and forces a full Now+Arc refresh from upstream sources (which produces a clean YAML block).

### Step 6 — Frontmatter audit (inline)

1. If `agent/scripts/frontmatter-audit.py` exists, shell out: `python3 agent/scripts/frontmatter-audit.py --json --limit 100`.
2. Otherwise, do an inline walk: scan `.md` files under the vault (skip `Archive/` and `.claude/`). For each file: check for missing frontmatter, missing `tags:`, malformed `updated:`/`arc-updated:` scalars (multi-line, embedded colons/brackets/wikilinks/prose), inconsistent `type:` values.
3. Compose a "Frontmatter audit" section in the report containing:
   - Counts: scanned / clean / flagged.
   - Breakdown by flag (`missing_frontmatter: N`, `dead_updated: N`, `malformed_yaml: N`, ...).
   - Top 10 worst offenders by file (paths + flags).
   - Type-frequency note: surface any `type:` value appearing fewer than 3 times across the vault (likely typos).
4. Radar threshold:
   - If any single flag count is **≥10**, queue ONE aggregated Radar item ("frontmatter drift: N missing frontmatter, M dead updated"). Don't mint per-file items.
   - If counts are <10 per flag, the report bullet is sufficient — no Radar item.

### Step 7 — Radar staleness (inline)

1. Read `Radar.md`, parse it section-by-section. Each item is one bullet line.
2. For each Urgent + Active item, check whether the line contains `✓ Done when:`. Items without it → collect into `MISSING_DONE_WHEN` list.
3. If non-empty:
   - Add a "Radar staleness" report section listing the IDs.
   - Queue ONE aggregated Radar item: "N Urgent/Active items missing `✓ Done when:` criteria — see today's rem-cycle report for IDs". Done-when on the queued item: "all listed IDs have a `✓ Done when:` clause appended to their line in Radar.md".

### Step 8 — Weekly synthesis cadence (inline)

1. Compute current ISO week: `today.isocalendar()` → `YYYY-Www` (e.g., `2026-W18`).
2. Look for `Memory/Weekly/<YYYY-Www>.md`. Check both existence and that the file is non-stub (>200 chars).
3. Walk `Memory/Weekly/` and find the most-recent existing weekly file. Build gap list if there's a hole between it and the current week.
4. Two independent flags:
   - **Sunday + missing current week** → queue Radar item (`✓ Done when: Memory/Weekly/<current-week>.md exists and is non-stub`).
   - **Past-week gap exists** → queue ONE aggregated Radar item ("weekly synthesis backlog: <gap list>"). Done-when: all listed weekly files exist and are non-stub.
5. If both fire today, the past-week gap item subsumes the Sunday-current item; emit only one.

### Step 9 — Aggregate report

Write `report_path` with this structure:

```markdown
---
title: "REM Cycle — <today>"
type: log
created: <today>
updated: <today>
tags: [log, {{agent_name}}, rem-cycle, diagnostic]
---

# REM Cycle — <today>

> 3-line summary for instant skim:
> - Subroutines: extract <ok/failed>, session-retitle <ok/failed>, embed <ok/failed>, spider <ok/failed>, radar-verify <ok/failed>, hippo-refresh <ok/failed>
> - session-retitle renamed N (M backlog); radar-verify cleared N items; hippo-refresh rewrote Now (+ Arc / Arc-fresh); X alerts flagged across inline diagnostics
> - Y new Radar items queued (IDs: ...) · Z items received Recurrence: <today>

## Subroutines

### Extract
[status + summary, or error]

### Session Retitle
[status + N renamed (sample with tags), T tagged, top-3 tags this run, M skipped, P errors, Q daily files updated, B backlog remaining, or error]

### Embed
[status + summary, or error]

### Spider
[status + summary, or error]

### Radar Verify (apply mode)
[N auto-cleared (IDs), M candidates for review, P missing Done-when criteria, or error]

### Hippocampus Refresh
[Now rewritten · Arc <rewritten/skipped, age=Nh> · pruned: A active / W watching / O open-loops · word_count=N · oversize_warning=<true/false>, or error]

## Inline diagnostics

### Frontmatter audit
[counts table + top offenders, or "✅ clean"]

### Radar staleness
[N items missing Done-when, or "✅ clean"]

### Weekly synthesis cadence
[Current week file: present/missing; gap list if any, or "✅ clean"]

## Radar items queued
- `r_xxxxx` — <description> (section: Active/Urgent)
- ...
```

### Step 10 — Queue Radar items

For each Radar item to be queued:

1. **Generate ID**: produce a 5-char base36 string `r_xxxxx` (lowercase a–z + 0–9). Re-roll if it collides with the harvested ID set or with any new ID minted in this run.
2. **Idempotency check**: search Radar.md for an existing item with the same fingerprint (e.g., title prefix "rem-cycle: Hippocampus updated >24h"). If found:
   - Don't mint a new item.
   - Append `· Recurrence: <today>` to the existing item's line, just before its `<!-- id:r_xxxxx -->` comment.
3. **Append**: insert the new line into the appropriate Radar section. Default to **Active**. Use **Urgent** only if the diagnostic explicitly demands sub-48h action (rare for nightly drift; subroutine failures qualify).
4. **Done-when criterion**: every new Radar item must carry a `✓ Done when:` clause that points back at observable proof — typically the rem-cycle report file or a vault-state check that `/radar-verify` can probe next night.

#### Radar item fingerprints

| Diagnostic | Title prefix |
|------------|--------------|
| Subroutine failure (extract/session-retitle/embed/spider/radar-verify/hippo-refresh) | `rem-cycle: <subroutine> failed` |
| Hippocampus oversized (>1,500 words) | `rem-cycle: Hippocampus oversized — needs trim` |
| Hippocampus thin arc (<3 days of Daily/) | `rem-cycle: Hippocampus thin arc` |
| Frontmatter audit ≥10 in one flag | `rem-cycle: Vault frontmatter drift` |
| Radar items missing Done-when | `rem-cycle: Radar items missing Done-when criteria` |
| Weekly synthesis backlog | `rem-cycle: Weekly synthesis backlog` |
| Weekly synthesis (Sunday only) | `rem-cycle: Weekly synthesis due tonight` |

The drift-watchdog Radar fingerprints from rem-cycle v1 (`Hippocampus Now stale`, `Hippocampus Arc stale`, `Hippocampus frontmatter malformed`) are retired in v2 — those failure modes are now eliminated by hippo-refresh writing the file directly. Existing Radar items with those fingerprints will clear themselves on the next radar-verify pass once Hippocampus is freshly rewritten.

### Step 11 — Exit

- Print the 3-line summary to stdout (cron picks it up in `rem-cycle.log`).
- Exit 0 even if findings exist — drift is data, not failure. Exit non-zero only on script crash, Radar.md parse error, or Hippocampus.md missing.

## What this skill does

- Owns the full nightly vault chain (extract → embed → spider → radar-verify → hippo-refresh).
- Runs the inline diagnostics (frontmatter audit, Radar staleness, weekly synthesis cadence).
- Auto-clears HIGH-confidence Radar items via radar-verify in apply mode (line removal in Radar.md, within the never-delete-files rule).
- Auto-rewrites `Memory/Hippocampus.md` via hippo-refresh in apply mode (atomic write, single file, within the never-delete-files rule).
- Aggregates everything into one dated report.

## What this skill does NOT do

- Does not delete files or directories. (Never-delete-files rule.)
- Does not send messages or external API calls.
- Does not retry failed subroutines — failure becomes a Radar item, retry happens next night.

## Failure modes

- **Scheduler not running on macOS**: `launchctl list | grep com.{{agent_name}}.rem-cycle` should show `0` exit. Check `agent/Logs/rem-cycle/launchd-stderr.log`.
- **Scheduler not running on Windows**: `Get-ScheduledTask -TaskName "Foundry-<agent-name-lower>-rem-cycle"` should show the task. Check `agent\Logs\rem-cycle\scheduled-task.log`.
- **Subroutine failure**: caught and reported, chain continues, Radar item queued.
- **Radar.md unparseable**: emit "rem-cycle aborted: Radar.md parse error at line N" to err.log and exit 2.
- **Hippocampus missing**: emit "rem-cycle aborted: Hippocampus.md not found" to err.log and exit 2.

## Coexistence with prior macOS cron set

v1 of rem-cycle ran in parallel with independent extract/embed/spider crons. v2 subsumes them. After v2 has had 2–3 clean runs, disable the old crons (this is a soft-disable — plists stay in `~/Library/LaunchAgents/`, can be re-bootstrapped if rollback is needed):

```bash
launchctl bootout gui/$(id -u)/com.{{agent_name}}.extract
launchctl bootout gui/$(id -u)/com.{{agent_name}}.embed
launchctl bootout gui/$(id -u)/com.{{agent_name}}.spider
```

Until they're disabled, the early-AM extract/embed/spider crons fire as usual, then rem-cycle at 4:55am calls them again as subroutines — extract is idempotent (checks `extracted: true`), embed is incremental, spider is read-then-write — so double-fires are wasteful but not destructive.

Schedule recommendation: shift rem-cycle from 4:55am to 4:00am once the old crons are disabled (extract → embed → spider sequentially takes ~30–40 min; starting at 4:00am gives the chain margin and still finishes well before any morning use).

## Related skills

- [[Skills/extraction/SKILL|Extract]] — Step 1 subroutine.
- [[Skills/session-retitle/SKILL|Session Retitle]] — Step 1.5 subroutine; retitles raw session transcripts and writes daily-side backlinks.
- Embed — Step 2 subroutine (no dedicated SKILL.md; invoked via /embed slash command).
- [[Skills/spider/SKILL|Spider]] — Step 3 subroutine.
- [[Skills/radar-verify/SKILL|Radar Verify]] — Step 4 subroutine; the first auto-action.
- [[Skills/hippo-refresh/SKILL|Hippo Refresh]] — Step 5 subroutine; the second auto-action; rewrites Memory/Hippocampus.md.
- [[Skills/session-handoff/SKILL|Session Handoff]] — line 142 frontmatter discipline rule (scalar timestamps); sunsetting in favor of hooks, currently a transitional dual-writer with hippo-refresh.
- [[Skills/frontmatter-audit/SKILL|Frontmatter Audit]] — composed in Step 6 if `agent/scripts/frontmatter-audit.py` exists.
- [[agent/cron-runbook|Cron Runbook]] — launchd management + debugging.
