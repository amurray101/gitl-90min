---
name: coding-protocol
title: Coding Protocol
type: skill
created: 2026-04-08
updated: 2026-04-08
tags: [skill, coding, process]
trigger: "Any coding task beyond trivial changes (adding a reminder, fixing a typo, updating a value)"
---

# Coding Protocol

## Plan Before You Build

For any coding task beyond trivial changes:

1. **Read the relevant code first.** Understand what's actually there before forming an opinion.
2. **Write a plan.** State: what the problem is, root cause, what you'll change, why, and any risks or side effects.
3. **Get confirmation** (explicit or implicit — {{user_name}} saying "do it" / "looks good" counts).
4. **Then implement.** One clean pass, not iterative deploy-and-see.

### What counts as "trivial" (can skip planning)

- Adding a task, reminder, calendar event
- Updating a single config value or text string
- Small isolated one-liners with no side effects

### What requires a plan

- Any logic change in a running system
- New features or significant refactors
- Anything touching state, timers, async flows, or event handlers
- Bug fixes in non-obvious code

## Zoom Out When Debugging Incrementally-Built Code

When a bug has been patched more than 2-3 times without fully resolving, **stop patching and zoom out.**

Incrementally-built systems accumulate:
- Dead code from old approaches that was never deleted
- Duplicate logic solving the same problem two different ways
- State managed in overlapping places
- Confusingly similar variable names that diverge in meaning over time

**The signal to zoom out:** You're adding a patch that works around a problem instead of eliminating it. If you find yourself saying "this fixes it but the underlying reason is..." — stop. That's the moment.

**What to do:**
1. Audit the whole relevant module for dead code, duplicate paths, split state ownership
2. Present a cleanup plan to {{user_name}} — Phase 1 (safe deletes) + Phase 2 (logic consolidation)
3. Clean first, then the bug often resolves itself or becomes obvious

**Real example (2026-03-10):** Voice panel auto-listen wasn't opening after responses. Root cause was `isListening` stuck `true` because two paths led to `_finishListening` — one via `stopListening()` (which cleared the flag), one directly from `dg.onFinal` (which didn't). We patched it 3 times before zooming out and seeing: ~100 lines of dead TTS code, two auto-listen scheduling paths, two listening-finalization paths. Dead code removal + architecture audit revealed the root cause cleanly.

## Delegation

For multi-agent delegation (swarm protocol), see [[Skills/swarm/SKILL|Swarm Protocol]].

**Quick rule:** Main session thinks and coordinates. Subagents execute mechanical work. If the task can be expressed as a self-contained instruction with no ambiguity, delegate it to a haiku subagent.
