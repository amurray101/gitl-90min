---
name: sweep-imessage
description: Triage iMessage state — surface unreads, unresponded threads, enrich people graph from texts, propose Radar/calendar/reply actions. Never sends without approval.
title: "iMessage Sweep"
type: skill
created: 2026-04-21
updated: 2026-04-21
tags: [skill, imessage, triage, people-graph, sweep]
trigger: "User runs /sweep-imessage, or as part of a scheduled morning sweep"
---

# iMessage Sweep Skill

> Triage iMessage state. Surface unreads, unresponded threads, and proposed actions. Enrich the people graph from thread content. Never sends anything without {{user_name}}'s explicit approval.

## Inputs

- **Mode** (optional): `dry-run` (default on first-ever run) or `live`. Dry-run presents proposals only — no sends, no file edits.
- **Window** (optional): `incremental` (default — since last cursor) or `lookback` (full history, one-time).
- **Scope** (optional): comma-separated list of contact identifiers to limit the sweep to specific threads (e.g., `mom,dani`). Default: all threads.

## Prerequisites

1. MCP `jons-mcp-imessage` server loaded. Tool schemas must be fetched via `ToolSearch` with query `select:<tool_name>` before first use (e.g., `select:mcp__jons-mcp-imessage__list_conversations,...`).
2. Run `check_permissions` once to verify Full Disk Access is granted.
3. Reading via SQLite does **not** mark messages as read and does **not** trigger read receipts to senders. Reads are only flipped when Messages.app actually opens the thread. (Verify once on first run before trusting.)

## Procedure

### 1. Pull Conversation State

Use `list_conversations` (large limit) to get every thread with:
- Conversation ID
- Contact identifier (phone/email)
- `unread_count`
- `last_message_date`
- `last_message_from_me` (where available)

Store a cursor file at `agent/state/imessage-cursor.json`:

```json
{
  "last_sweep_at": "2026-04-21T09:00:00Z",
  "per_thread": {
    "<conversation_id>": "2026-04-21T08:42:13Z"
  }
}
```

In incremental mode, skip threads whose `last_message_date` ≤ the per-thread cursor.

### 2. Classify Each Thread

For each thread in scope, pull the last ~10 messages via `get_conversation_messages` and classify:

> **Note:** `list_conversations` does **not** return an `unread_count` field. UNREAD must be inferred from `last_message_date > cursor` AND last message `is_from_me=false`. The skill previously assumed `unread_count` — it doesn't exist in the API.

| State | Definition |
|-------|------------|
| **UNREAD** | Last message after cursor with `is_from_me=false` (you haven't seen it since last sweep) |
| **UNRESPONDED** | Last message `is_from_me = false` (ball in your court), regardless of read state |
| **STALE-WAITING** | You sent last, >5 days ago, no reply (they owe you) |
| **ACTIVE** | Back-and-forth in last 24h, nothing pending |
| **IDLE** | Caught up, nothing to do |

`UNREAD` and `UNRESPONDED` can overlap (haven't seen AND haven't replied). Both classifications attach.

### 3. Resolve Contacts

**Primary path: normalized vault grep.** Run the resolver helper:

```bash
<your-vault>/agent/scripts/resolve-phone.py +1XXXXXXXXXX [+1YYYYYYYYYY ...]
```

This walks `Memory/People/*.md`, extracts phones via anchored patterns, normalizes to last-10-digits, and returns `<phone>\t<filename>`. For batch resolution use `--build-index` to dump the full map as JSON, then look up locally.

**Fallback: MCP `lookup_contact`.** Only useful if Contacts.app on the host machine has data. As of 2026-04-24 the Mac Mini's Contacts.app is empty (iCloud Contacts sync not enabled — only {{user_name}}'s own card present), so `lookup_contact` returns null for every number. Don't trust it as primary on this machine.

For each phone in scope:
- **Match in vault** → link to that People file
- **No match** → candidate for stub creation (see step 5). When {{user_name}} resolves an unknown manually, **add the phone to the matched People file's Contact section** so the next sweep auto-resolves it.

For group chats, run the resolver on each participant's phone separately.

### 4. Extract Signal Per Thread

For each `UNREAD` or `UNRESPONDED` thread, read the messages and extract:

- **Ask or statement** — what they actually said (quote verbatim, 1–2 lines max)
- **Time elapsed** — since their last message
- **Commitments, dates, decisions** — anything that could become a Radar item, calendar event, or task
- **Vibe** — casual / important / time-sensitive / emotional
- **Names mentioned in message text** — e.g., "I saw Sarah at the party" — collect as candidates for People stub creation (step 5.b)

### 5. People Graph Enrichment

**5.a — Thread participants without a People file**

If `lookup_contact` returns a name and no `Memory/People/firstname-lastname.md` exists:

Create a stub with the template below (mirrors granola-sync pattern).

**5.b — Names mentioned inside messages**

If a message contains a proper name (first-name or first-last) that isn't already a People file, propose a stub with a "first mentioned" link back to the thread. **Propose only** — do not auto-create for mentioned names, because resolution is fuzzy (could be a celebrity, a brand, a fictional person). Ask {{user_name}} before creating.

**People stub template:**

```yaml
---
title: "Firstname Lastname"
type: person
created: YYYY-MM-DD
updated: YYYY-MM-DD
tags: [person]
relation: ""
---

# Firstname Lastname

- **Phone:** +1XXXXXXXXXX  (if known from contact resolution)
- **First seen (iMessage):** YYYY-MM-DD
- **First seen context:** [brief one-liner — "texting re: weekend plans" etc.]
```

Add the new person to the appropriate group roster at `Memory/People/groups/<group>.md` (e.g. `swordpoint.md`, `stanford.md`, `family.md`). Create a new group file if no existing roster fits and the cluster warrants one.

### 6. Cross-Check Vault

For each extracted thread, read:
- `Memory/People/<name>.md` (if it exists) for relationship context
- `Radar.md` for anything related already on your mind
- Calendar (via `gog calendar events --account <user-email>`) for events involving this person in the next 7 days

This context informs the proposed action in step 7.

### 7. Produce Triage Output

Group into tiers, lightest-load first (following the inbox-triage pattern):

**Tier 1 — Needs reply (time-sensitive / UNRESPONDED)**
Sorted by time elapsed, descending.

```
[Name] — UNRESPONDED [N days]
> "Their last message (quoted, truncated to ~80 chars)"
Proposed reply: "[draft text]"
```

**Tier 2 — UNREAD, low-stakes**
Clustered by theme (group chats, newsletters, quick confirmations).

**Tier 3 — STALE-WAITING (nudge candidates)**
Threads where you're owed a response >5 days.

**Tier 4 — Vault updates**
- New People stubs (from 5.a — **auto-create**)
- Updates to existing People notes — new topic / last interaction (**auto-apply**)
- Candidate People stubs (from 5.b — need approval)
- New Radar items (commitments, open threads — need approval)
- New calendar events (dates mentioned in messages — need approval)

### 8. Auto-Apply + Approval Loop

**Auto-apply (no approval needed):**
- Create new People stubs from 5.a
- Append to existing `Memory/People/<name>.md` under "Recent interactions" — new topic, last-interaction date, short context. This runs every sweep without asking.

**Approval-gated** — present to {{user_name}}, wait for explicit green light:

| Approval signal | Action |
|-----------------|--------|
| ✅ send reply | `send_message(recipient, text)` |
| ✅ add to Radar | Edit `Radar.md` — append under correct tier |
| ✅ create event | `gog calendar create` |
| ✅ create candidate stub (5.b) | Create `Memory/People/<name>.md` |
| ❌ skip | Leave state unchanged, note in handoff |

Sensible batch approvals are encouraged ("approve all Tier 2 clears").

### 9. Update Cursors and Log

After approved actions execute:
- Update per-thread cursor to the latest `last_message_date` processed
- Update `last_sweep_at` on the cursor file
- Append sweep summary to `Memory/Daily/YYYY-MM-DD.md` under a `## iMessage Sweep` section

### 10. Report

Print a concise summary:

```
iMessage Sweep complete.
- Threads reviewed: N
- Tier 1 (needs reply): X → Y replies sent, Z skipped
- Tier 4 (vault updates): A People stubs created, B Radar items added, C events created
- Names flagged for potential stubs: [list]
- Next sweep cursor: YYYY-MM-DD HH:MM
```

## Rules

- **Never send without approval.** Every `send_message` call requires explicit green light from {{user_name}} for that specific thread and that specific draft text.
- **Idempotent.** Re-running the sweep with no new activity should produce an empty report. Per-thread cursors enforce this.
- **Don't auto-create stubs for mentioned names.** Only contact-resolved names (5.a) auto-create. Mentioned names (5.b) are proposals.
- **Respect read state.** Reading via SQLite doesn't mark read — preserve that invariant. Never use `send_message` as a workaround to force read state.
- **Skip noise by default.** 2FA codes, delivery confirmations, marketing-style broadcasts — classify as `IDLE` unless {{user_name}} opts them in.
- **Privacy floor.** The sweep output stays local to the vault. Never paste raw message content into any external-facing draft without explicit approval. Quotes used in triage output should be minimal (~80 chars).
- **Handle group chats carefully.** Group threads have multiple participants. Contact resolution applies to each. Don't over-surface — a single group chat with 200 unreads shouldn't dominate the sweep.

## Integration with Other Skills

- **Inbox Triage** ([[Memory/Lessons/global/inbox-triage]]) — mirror the email playbook. Both sweeps can run in a combined "comms sweep" morning routine.
- **Prep Sweep** ([[Skills/prep-sweep/SKILL]]) — morning dashboard can trigger iMessage sweep as a step.
- **Extraction** ([[Skills/extraction/SKILL]]) — People note updates written by this sweep feed the normal extraction pipeline.
- **Radar updates** — new commitments found in texts become Radar items, following the standard placement rules (Urgent / Active / Watching). Urgent items must be **SMART** (specific artifact, measurable done-state, ≤48h deadline) — see [[Skills/session-handoff/SKILL|session-handoff § 2]]. Vague commitments ("circle back on X") go in Active.

## Key Links

- [[Memory/People/Context|People Hub]] — destination for stubs + enrichment
- [[Memory/Lessons/global/inbox-triage|Inbox Triage Lessons]] — parallel playbook for email
- [[Radar]] — destination for new commitments / open threads
- [[agent/state/imessage-cursor|Sweep cursor]] — state file (created on first run)

## Future: Scheduled Sweep

Once dry-run has proven the classification is sane across 2–3 real sweeps, wire up a daily cron:

1. Pull incremental since cursor
2. Generate triage output
3. Push to Telegram as a "morning iMessage digest" so {{user_name}} can approve from phone
4. Execute approved actions, update cursors

This matches the autonomy roadmap from inbox-triage (Phase 1 → Phase 2 → Phase 3).

## Edge Cases

- **New thread, no contact match, no name resolvable**: classify as `UNREAD`, show phone/email, ask {{user_name}} who it is before any proposed action.
- **Very long thread lookback**: for the one-time initial sweep, window by month and extract per-window. Don't try to hold an entire multi-year thread in context.
- **Attachments / images / reactions**: note their presence ("[image]", "[reacted ❤️]") in triage output but don't attempt to interpret.
- **Messages you sent from another device that show as `is_from_me`**: these are still you — don't misclassify as UNRESPONDED.
