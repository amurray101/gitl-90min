---
name: search
description: Search the vault and external sources for information. Escalates through Radar → adaptive graph walk → keywords → calendar/email → web.
title: Vault Search Skill
type: skill
created: 2026-04-09
updated: 2026-04-09
tags: [skill, search, vault]
---

# Vault Search

> Tiered search with adaptive graph traversal. Radar is working memory. Wikilinks are associative memory. Embeddings (future) are semantic memory. Keywords and external sources are the safety net.

## When to Use

**Trigger when:**
- {{user_name}} asks for information: "Find my notes on X", "What do I know about Y?"
- You need missing context before acting on a task
- A vague reference needs grounding: "That thing I wrote about..."
- You want supporting material for advice or a decision

**Don't trigger for:**
- Direct file operations where the path is known
- Continuing conversations with context already loaded
- Quick factual questions you can answer from general knowledge

## Search Tiers

Work through tiers in order. **Stop as soon as the query is answered.** Each tier builds on hits from the previous one.

---

### Tier 0: Radar (Working Memory)

Radar.md is {{agent_name}}'s active short-term memory. If {{user_name}} is asking about something, there's a strong chance it's being tracked here.

1. Read `<your-vault>/Radar.md`
2. Scan all sections (Urgent, Active, Watching, Open Loops) for relevance
3. If a Radar item matches → its wikilinks are your first entry points for Tier 1

**If answered:** Stop. Report what you found and where.

---

### Tier 1: Adaptive Graph Walk (Associative Memory)

Wikilinks are intentional connections — more precise than keyword search because a human or {{agent_name}} decided these things are related. **Do not use fixed hop counts.** Use judgment.

**Seed entry points:**
- Radar hits from Tier 0
- The relevant domain's index file (e.g., `Swordpoint/0-swordpoint-index.md`)
- Known People files (`Memory/People/`)
- Known project files (`Memory/Projects/`)
- Domain `Logs/` files (narrative arcs with rich context)

**Adaptive traversal loop:**

```
1. Read the entry point file
2. Evaluate: Does this answer the query?
   → Yes: Stop. Cite the file.
   → Partially: Note what you learned. Continue.
   → No: Continue.
3. Scan the file's wikilinks. Which ones look relevant to the query?
   → Follow only the promising links (not all of them)
4. For each followed link, go back to step 1
5. Stop when:
   - The query is fully answered, OR
   - The last expansion added no new relevant information (diminishing returns), OR
   - You've read ~15 files without convergence (escalate to Tier 2)
```

**Key principles:**
- **Be selective, not exhaustive.** A file with 8 wikilinks might have 1-2 worth following for this query. Follow those, ignore the rest.
- **Favor depth on hot paths over breadth.** If a file is clearly relevant, follow its links aggressively. If it's tangential, stop there.
- **Index files are hub nodes.** They link to everything in their domain — great for orientation, but don't blindly follow all their links.
- **Logs/ files are narrative gold.** They often contain the "why" and "how" that individual files lack.

---

### Tier 1.5: Vector Similarity (Semantic Memory)

Embeddings are optional. If `vsearch` and local embeddings have been installed, this tier can run **in parallel with the graph walk**, not after it.

**Automatic, only if wired:** A `UserPromptSubmit` recall hook may inject relevant vault chunks before you start searching. Default Foundry onboarding does not install this hook; it requires a later `/wire-recall` setup once `vsearch`/Ollama are present.

**Manual, when `vsearch` exists:**
```bash
cd <your-vault>/Workbench/vault-embeddings && uv run vsearch search "query" --json-output
```

**How to integrate with the graph walk:**
- Vector search surfaces files that are *semantically related but not yet linked*
- Use vector hits as new entry points for Tier 1's adaptive walk — follow their wikilinks
- Over time, Spider converts repeated embedding discoveries into permanent wikilinks
- The two systems make each other stronger: wikilinks give structure, embeddings find what structure missed

---

### Tier 2: Keyword Search (Full Vault)

When graph or vector memory does not land, cast a wider net.

1. **Multi-keyword grep** across `<your-vault>/` with `*.md` filter
   - Try multiple keyword variations (abbreviations, aliases, full names)
   - Use domain-scoped search first if you have a hunch, then broaden

2. **Daily notes search** (last 14 days in `Memory/Daily/`)
   - Raw context not yet extracted elsewhere often lives here

3. **For each hit:** Read the file, then feed it back into Tier 1's adaptive walk — follow its wikilinks if they look promising

**Max 4-5 searches before escalating.** Don't thrash on synonyms.

---

### Tier 3: Recent Activity (Calendar + Email)

Information {{user_name}} interacts with daily may not be in the vault yet.

1. **Calendar:**
   ```bash
   gog calendar --days 14
   gog calendar --search "event_name" --details
   ```

2. **Email (Stanford — primary):**
   ```bash
   gog email search "relevant keywords" --limit 10
   ```

3. **Email (MCP fallback):** If gog fails, use Gmail MCP tools

4. **Synthesize:** Connect external findings back to vault files if they exist

---

### Tier 4: External (Web + Deep Search)

Go outside the vault only when internal sources are exhausted.

1. **Web search** for companies, people, policies, terms
2. **Deep email search** with broader keywords or longer time ranges
3. **Canvas/academic sources** if the query is course-related

---

## Common Search Patterns

### People
- **Seed:** `Memory/People/[name].md` → follow wikilinks to projects, emails, meetings
- **Fallback:** Grep for name variations, then email search

### Projects / Business
- **Seed:** Domain index file → `[Domain]/Logs/` for narrative arc
- **Fallback:** Grep project name, check `Memory/Projects/`

### Academic
- **Seed:** `Academics/0-academics-index.md` → course folder → course index file within
- **Fallback:** Canvas API, course registry, email from professors

### "When did I..." / Temporal
- **Seed:** `Memory/Daily/` grep for the event/topic
- **Fallback:** Calendar search, then email timestamps

### "What was that thing about..."
- **Seed:** Radar (is it active?), then keyword grep
- **Graph walk** from any hit is usually where the answer lives

## Execution Guidelines

- **Total time limit: 2 minutes** across all tiers
- **~15 file reads max** in Tier 1 before escalating — this is a soft cap, use judgment
- **Always cite source files** with paths so {{user_name}} can navigate in Obsidian
- **Summarize findings** even if incomplete — partial answers beat silence
- **Escalate proactively** through tiers rather than giving up at any one
- **The graph is the product** — a single good hit + its wikilinks often beats 10 keyword searches
