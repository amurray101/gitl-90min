---
name: extract
description: Run the Librarian — extract knowledge from daily notes into structured vault locations (People, Logs, Lessons, Preferences, Radar).
title: "Extraction — The Librarian"
type: skill
created: 2026-04-07
updated: 2026-04-09
tags: [skill, memory, extraction]
trigger: "Called by [[Skills/session-handoff/SKILL|/handoff]] on today's Daily file, by [[Skills/bulk-extract/SKILL|bulk-extract]] on any extracted: false file, or as first phase of [[Skills/spider/SKILL|/spider]]. Also used for one-time historical lookback."
---

# Extraction Skill — The Librarian

> Reads raw source files (Daily notes, imported chats, Granola meetings) and routes knowledge into structured vault locations.

## Inputs

- One or more source files with `extracted: false` in frontmatter
- Can process Daily files, Meeting files from Granola, or any imported content

## What Gets Extracted

| Category        | Source Signal                                     | Destination                                          | File Pattern            |
| --------------- | ------------------------------------------------- | ---------------------------------------------------- | ----------------------- |
| **People**      | Names, roles, relationships, interactions         | `Memory/People/firstname-lastname.md`                | One file per person     |
| **Domain Logs** | Project decisions, milestones, progress, setbacks | `Domain/Logs/YYYY-MM-DD_topic.md`                    | Dated narrative entries |
| **Lessons**     | Things that broke, surprises, what worked         | `Memory/Lessons/project/slug.md` or `global/slug.md` | Append or create        |
| **Preferences** | Working style patterns, tool choices              | `Memory/Preferences/topic.md`                        | Append or create        |
| **Health**      | Health observations, routines, patterns           | `Memory/Health/topic.md`                             | Append or create        |
| **Action Items**| Decisions, next steps, deliverables, commitments  | `Radar.md` under appropriate section                 | Append                  |
| **Open Loops**  | Unresolved questions, ambiguous routing           | `Radar.md` under appropriate section                 | Append                  |

## Procedure

1. **Auto-discovery scan:** Look for all files with `extracted: false` in Memory/Daily/ and Memory/Meetings/
2. Read each source file fully.
3. Identify distinct knowledge units: decisions made, lessons learned, people mentioned, project state changes, preferences revealed, health/lifestyle observations, action items, open loops.
4. For each knowledge unit, route to the correct destination per the table above.
5. For each destination file written to:
   - Add wikilink back to source file: `[→ source: [[Memory/Daily/YYYY-MM-DD]]]` or `[→ source: [[Memory/Meetings/YYYY-MM-DD_meeting-title]]]`
   - Add or update relevant tags in frontmatter
   - Update the parent index file if a new file was created
6. In the source file:
   - Add inline breadcrumbs showing where insights were routed: `[→ Memory/People/peter-tiktinsky]`
   - Set `extracted: true` in frontmatter
7. Verify no orphans were created (every new file has at least one inbound wikilink).

## Meeting File Extraction

Granola meeting files in `Memory/Meetings/` follow the same extraction pattern as Daily files:

- **Action items → Radar** under Urgent/Active/Watching based on timeline. **Urgent placement requires SMART framing** (specific artifact, measurable done-state, ≤48h deadline). See [[Skills/session-handoff/SKILL|session-handoff § 2]] for the template. Items that lack a tight deliverable belong in Active, not Urgent.
- **People mentions → Memory/People/** with role and context from the meeting
- **Project updates → Domain/Logs/** as dated narrative entries
- **Decisions and lessons → Memory/Lessons/** or **Memory/Preferences/**

Meeting files use the naming pattern: `YYYY-MM-DD_meeting-title.md`

## File Templates

### People Files (`Memory/People/firstname-lastname.md`)
```yaml
---
title: "Firstname Lastname"
type: person
created: YYYY-MM-DD
updated: YYYY-MM-DD
tags: [person]
relation: ""  # e.g., "WinGen colleague", "Stanford classmate", "client"
---
```

Content should include:
- Role / title / organization
- Relationship to {{user_name}} (how they know each other)
- Key interactions and context
- Wikilinks back to source conversations and relevant domain files

**Do NOT create a person file for {{user_name}} himself** — his profile lives at `Memory/People/eitan-background.md`.

### Domain Logs (`Domain/Logs/`)

Each log entry is a dated narrative — not a raw event dump. It tells the story of what happened and why it matters for the domain.
```yaml
---
title: "Brief descriptive title"
type: log
created: YYYY-MM-DD
updated: YYYY-MM-DD
tags: [log, domain-tag]
sources: []  # wikilinks to source files
---
```

For historical lookback (processing imported chats), create synthesis files that cover a date range:
- `YYYY-MM_chat-synthesis.md` for months with multiple chats
- `YYYY-MM-DD_topic.md` for individual significant conversations

### Lessons (`Memory/Lessons/`)
```yaml
---
title: "Lesson title"
type: lesson
created: YYYY-MM-DD
tags: [lesson]
---

## Lesson: [title]

**Trigger:** What happened
**Root cause:** Why it happened
**Resolution:** What was done
**Tags:** [relevant tags]
**Learned:** YYYY-MM-DD
**Source:** [[wikilink to source]]
```

## Rules

- Never modify {{user_name}}'s writing in source files. Only add breadcrumbs and update frontmatter.
- If a destination file doesn't exist yet, create it with proper frontmatter and add it to the parent index file.
- If routing is ambiguous (could go to multiple domains), flag it in Radar.md under Open Loops rather than guessing.
- Extraction is idempotent — running it twice on the same file should not create duplicates. Check destination files before appending.

## Swarm Execution (Parallel Bulk Operations)

When running as parallel subagents for large batches via [[Skills/swarm/SKILL|Swarm]], each agent gets an **exclusive write zone**:

- Agent writes ONLY to its assigned directories
- Agent NEVER edits files outside its zone
- For files that need cross-zone updates (like index files), agent outputs a manifest of requested changes to `/tmp/{{agent_name}}-extraction/` — the main session applies them

### Write Zone Assignments

| Agent            | Write Zone                                                          | Read Zone                            |
| ---------------- | ------------------------------------------------------------------- | ------------------------------------ |
| wingen           | `Swordpoint/WinGen/Logs/`                                           | WinGen-related sources               |
| swordpoint-other | `Swordpoint/{ShipAdvisor,Journey,HoldCo}/Logs/`, `Swordpoint/Logs/` | Other Swordpoint sources             |
| academics        | `Academics/Logs/`                                                   | Academic sources                     |
| {{agent_name}}-infra       | `agent/Logs/`                                                        | Infrastructure/{{agent_name}} sources          |
| slidebitch       | `SlideBitch/Logs/`                                                  | SlideBitch sources                   |
| personal         | `Personal/Logs/`, `Finance/Logs/`, `Memory/Health/`                 | Personal/health/finance/misc sources |
| people           | `Memory/People/`                                                    | All sources (read-only scan)         |
| lessons          | `Memory/Lessons/`, `Memory/Preferences/`                            | All sources (read-only scan)         |

## Single-File Operation (Daily [[Skills/session-handoff/SKILL|/handoff]])

1. Read today's `Memory/Daily/YYYY-MM-DD.md`
2. Extract and route to topic notes, domain Logs/, etc.
3. Mark source with extraction breadcrumbs and set `extracted: true`
4. Single-agent execution (no [[Skills/swarm/SKILL|swarm]] needed for one file)

## Historical Lookback (Bulk Import)

For processing a large backlog (e.g., imported Claude chats):
1. Main session categorizes source files by domain
2. Spawns domain-scoped subagents in parallel (Phase 1)
3. Each subagent reads its files, writes to its Logs/ zone, and outputs people/lessons manifests
4. Main session spawns people + lessons subagents (Phase 2) using manifests
5. Main session updates index files with new wikilinks
6. All processed source files marked `extracted: true`

## Outputs

- Updated topic notes in Memory/ subdirectories
- Updated domain Logs/ with dated entries
- Updated Radar.md if action items or open loops found
- Source files marked `extracted: true`