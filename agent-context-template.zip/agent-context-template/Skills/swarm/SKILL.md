---
name: swarm
description: Parallel subagent coordination protocol — orchestrator breaks work into atomic tasks, spawns Haiku/Sonnet domain agents in parallel, coordinates results. 2-tier model; subagents cannot spawn sub-subagents.
title: "Swarm Architecture Protocol"
type: skill
created: 2026-03-12
updated: 2026-04-12
tags: [skill, architecture, token-usage]
---

# Swarm Architecture Protocol

> Cost-efficient multi-agent framework for Claude Code. Main session thinks, subagents do.
> Originally developed for agent HQ (OpenClaw). Revised 2026-04-12 for Claude Code's flat spawning model.

---

## Platform Constraint

**Claude Code subagents cannot spawn their own subagents.** Spawning is one level deep only. The 3-tier model from OpenClaw doesn't apply here — we use a 2-tier model instead.

---

## The 2-Tier Model

```
TIER 1 — Orchestrator: YOU (main session, Opus or Sonnet)
  • Understand the task
  • Write the Goal Doc (what we're trying to accomplish)
  • Turn Goal Doc into a Work Order (atomic tasks for subagents)
  • Spawn subagents, collect results
  • Handle cross-cutting coordination

TIER 2 — Executors: subagents (Haiku by default, Sonnet if complex)
  • One atomic task each — zero reasoning required
  • Fresh context ~3-5K tokens
  • Spawned by Orchestrator directly
  • Cannot delegate further
```

---

## The Pipeline: Goal → Work Order → Execute

### Step 1: Goal Doc (1 turn)

The orchestrator writes a brief goal doc — what are we trying to accomplish, what's the scope, what does "done" look like. This is the PRD for the swarm. Save to `/tmp/[task-name]/GOAL.md`.

```markdown
# Goal: [task name]

## Objective
[What we're trying to accomplish in 1-2 sentences]

## Scope
[What's in scope, what's out]

## Done When
[Concrete success criteria]

## Inputs
[Files, data, context the agents will need]
```

### Step 2: Work Order (sequential, from Goal Doc)

Read the Goal Doc and break it into atomic tasks. Each task should be simple enough for Haiku — if you find yourself writing complex reasoning instructions, that task needs Sonnet or needs to be split further.

Save to `/tmp/[task-name]/WORK_ORDER.md`.

```markdown
## TASK N — [description]
### Model: haiku | sonnet
### Parallel group: A | B | C  (tasks in the same group run in parallel)
### Input:
[Files to read, data to use]
### Action:
[Exact instructions — what to do, what to write, where to write it]
### Output:
[What this agent should produce — a file, a manifest, a report]
### Verify:
[How to confirm success]
```

**Rules:**
- Each task = one atomic operation = one subagent
- Haiku should never need to reason — if it does, the Work Order is too vague
- The orchestrator decides model per task: default Haiku, escalate to Sonnet only for tasks requiring judgment
- Group tasks by parallelism — tasks in the same group can run simultaneously

### Step 3: Execute

Spawn subagents per the Work Order. Use the `model` parameter on the Agent tool:

```
Agent({
  description: "Spider: academics domain scan",
  model: "haiku",
  prompt: "[task instructions from Work Order]"
})
```

- Launch all tasks in the same parallel group simultaneously
- Wait for group completion before starting the next group
- Collect outputs (typically written to `/tmp/[task-name]/` or directly to vault files)

### Step 4: Coordinate (Orchestrator)

After all agents complete:
- Review outputs for conflicts or gaps
- Handle cross-cutting work (e.g., cross-domain links that span multiple agents' scopes)
- Apply any final edits that require full-picture context
- Clean up `/tmp/` artifacts

---

## When to Swarm

| Task type | Pattern | Parallelism |
|-----------|---------|-------------|
| Multi-file refactor | Work Order → Haiku editors per file | Parallel across files |
| Research (N sources) | N parallel Haiku readers → Orchestrator synthesizes | Parallel |
| [[Skills/spider/SKILL\|Spider]] | Domain-scoped Haiku scanners → Orchestrator cross-links | Parallel |
| [[Skills/extraction/SKILL\|Extraction]] (bulk) | Domain-scoped Haiku extractors → Orchestrator merges | Parallel |
| [[Skills/prep-sweep/SKILL\|Prep Sweep]] | Calendar + email + Canvas → 3 parallel Haiku → Orchestrator briefs | Parallel |
| Long-form writing | Outline sections → parallel Haiku drafters → Orchestrator edits | Parallel |
| Status / health checks | N parallel Haiku checkers → bubble up only if alert | Parallel |

**Do directly in main session:** conversations, strategic decisions, anything requiring accumulated personal context, tasks under ~3 tool calls.

---

## The Math

```
Haiku input:  $0.80/M tokens    (vs Sonnet $3/M, Opus $15/M)
Haiku output: $4/M tokens       (vs Sonnet $15/M, Opus $75/M)

Typical Spider run:
  Orchestrator (Sonnet): ~10K tokens for planning + coordination
  8 Haiku domain agents: ~5K tokens each = ~40K total
  Estimated cost: ~$0.25-0.50 per run

vs. monolithic Opus Spider: ~100K+ tokens = ~$3-5 per run
```

Fresh subagent context is cheap. Every message in a long session pays for ALL accumulated context. Swarm avoids this by keeping each agent's context minimal.

---

## When NOT to Swarm

- Simple one-liner fixes (just edit directly)
- Tasks under ~3 tool calls total
- Conversations — output IS the conversation
- Tasks requiring accumulated personal context
- Reading/exploring code (use tools directly in main session)

---

## Session Hygiene

Fresh sessions are cheap. Starting over costs nothing except the ~10K startup injection.

**Suggest a fresh session when:**
- Major topic shift
- Context has grown past ~50K tokens and the next task doesn't need history
- A fresh subagent would have the same context it needs anyway
