---
name: frontmatter-audit
description: Read-only walker that surfaces vault frontmatter drift — missing blocks, missing tags, malformed YAML scalars, dead `updated:` dates. Stdlib-only Python; safe to run anytime.
title: "Frontmatter Audit — Drift Detection"
type: skill
created: 2026-04-28
updated: 2026-04-28
tags: [skill, vault, frontmatter, diagnostic, automation]
trigger: "Manual /frontmatter-audit, or composed by /rem-cycle nightly"
---

# Frontmatter Audit — Drift Detection

> Walks the vault and reports which files have frontmatter drift, without fixing anything. Sibling to /spider, which handles auto-additions; this one detects the cases spider doesn't (malformed YAML, dead dates, embedded prose in scalar fields).

## What it checks

| Flag | Meaning |
|------|---------|
| `missing_frontmatter` | No `---` block at the top of the file |
| `missing_tags` | Has frontmatter but no `tags:` key |
| `malformed_yaml` | YAML parse error, or scalar timestamp field contains forbidden chars (`(`, `[`, `**`, wikilinks, embedded colons) per [Skills/session-handoff/SKILL.md:142](../session-handoff/SKILL.md) |
| `malformed_tags` | `tags:` value is not a list |
| `dead_updated` | `updated:` field is more than 30 days old |
| `future_updated` | `updated:` field is in the future (clock skew or typo) |

## What it does NOT do

- **No fixes.** Output is structured findings only. The /spider skill already auto-adds `tags: []` to files missing it; this skill deliberately doesn't duplicate that. Fixes for malformed/dead findings happen via Radar items + human judgment.
- **No prose validation.** Body content is untouched.
- **No re-routing.** This is a sibling diagnostic, not a graph audit.

## Scope

Walks `<your-vault>/` recursively and excludes:

- `Archive/`, `.claude/`, `.git/`, `node_modules/`, `.venv/`, `__pycache__/`, `.obsidian/`, `.trash/`
- Cloned third-party repos under Workbench: `Workbench/vault-embeddings`, `Workbench/whatsapp-access/whatsapp-mcp`, `Workbench/imessage-access/jons-mcp-imessage`

These are configured in `agent/scripts/frontmatter-audit.py` constants (`EXCLUDE_DIR_NAMES`, `EXCLUDE_PATH_FRAGMENTS`).

## How to invoke

### Standalone (manual)

```bash
python3 <your-vault>/agent/scripts/frontmatter-audit.py --summary
```

Returns:
- Counts: scanned / clean / flagged
- Breakdown by flag (`missing_frontmatter: 14`, `dead_updated: 9`, ...)
- `type:` frequency table across the vault — useful for spotting typos (a `type:` value appearing only once is often a typo)

### JSON for downstream parsing

```bash
python3 <your-vault>/agent/scripts/frontmatter-audit.py --json
```

Emits one JSON object with `summary` (counts, by_flag, type_counts) and `findings` (one record per flagged file). Each finding has `path`, `flags` (array), `detail` (array of human-readable diagnostic strings), and `type`.

Use `--limit N` to cap the findings array length.

### Composed by /rem-cycle

`/rem-cycle` calls this script in `--json` mode each night, parses the result, and writes a section into `agent/Logs/rem-cycle/<date>.md`. If any flag has ≥10 findings, /rem-cycle queues a Radar item for triage.

## Procedure (when invoked manually)

1. Run `python3 <your-vault>/agent/scripts/frontmatter-audit.py --json --limit 100`.
2. Parse the JSON.
3. Render a markdown table:
   - Top 20 worst offenders (most flags first), with file path + flags + detail.
   - Counts by flag.
   - Optional: top 5 `type:` values that appear <3 times across the vault (likely typos).
4. Surface findings to the user; do not auto-fix.

## Output format example

```
## Frontmatter audit — 2026-04-28

scanned: 2,060 / flagged: 24 (1.2%)

| Flag | Count |
|------|-------|
| missing_frontmatter | 14 |
| dead_updated | 9 |
| malformed_yaml | 1 |

### Top offenders
- `Prototype.md` — missing_frontmatter
- `Swordpoint/HoldCo/3i-strategy-meetings/_template.md` — malformed_yaml (created field is `'YYYY-MM-DD'` literal placeholder)
- ...
```

## Performance

- 2,060-file vault scan: ~0.4s on Mac Mini M4 Pro.
- Stdlib-only — no `pip install` ever needed.
- Memory: holds findings in a list; cap with `--limit` if vault grows past 10k files.

## Related skills

- [[Skills/spider/SKILL|Spider]] — graph audit; auto-adds missing `tags: []`. The two skills are deliberately split: spider fixes the easy stuff, frontmatter-audit reports the hard stuff.
- [[Skills/rem-cycle/SKILL|REM Cycle]] — nightly composer that calls this skill.
- [[Skills/session-handoff/SKILL|Session Handoff]] — defines the YAML scalar discipline this skill enforces (see line 142).
