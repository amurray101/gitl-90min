---
name: send-email
title: Send Email
type: skill
created: 2026-04-08
updated: 2026-05-08
tags: [skill, email, composio, gog]
trigger: "Any time Eitan asks to send an email, forward something, or share a file via email."
---

# Send Email

> Send email via Composio Gmail by default; fall back to gog CLI; STOP if neither is active.

**Routing:** see [[Skills/connector-routing|connector-routing.md]]. Default Composio Gmail (`GMAIL_SEND_EMAIL`); fall back to `gog gmail send`; STOP if neither connector has an active connection for the requested alias.

## Defaults

- **From / Account alias:** `stanford` (maps to `edarwish@stanford.edu`).
- **To:** `edarwish@stanford.edu` if Eitan says "email this to me."
- Override any default if Eitan specifies a different sender, recipient, or alias (`personal` for `eitan@darwish.com`, etc.).

Multi-account note: the alias is the routing key on both paths. Composio uses connected-account aliases (e.g., `stanford`, `personal`, `work`); gog uses `--account <alias>`. Same mental model, different surface.

## Procedure

1. Confirm recipient if ambiguous. If Eitan says "email this to me," use `edarwish@stanford.edu`.
2. **Before drafting body**, read [[Reference/email-writing-style|Reference/email-writing-style.md]] for Eitan's voice (openers, closers, tone, templates). Don't skip — generic AI prose doesn't sound like Eitan.
3. Draft subject + body. Keep it short and natural — write as Eitan, not as an AI.
4. Attach files if relevant.
5. Send via the route picked above (see ROUTE A or ROUTE B below).
6. Confirm success — Composio returns `id` + `threadId`; gog returns `message_id`.
7. If the chosen route errors, fall through to the next route once, then surface the error to Eitan.

## ROUTE A — Composio Gmail (default)

Tool: `mcp__composio__GMAIL_SEND_EMAIL`

```
GMAIL_SEND_EMAIL({
  recipient_email: "recipient@example.com",
  subject: "Subject line",
  body: "Email body",
  is_html: false,
  // attachment: { name, mimetype, s3key }   // see attachment note below
  // user_id defaults to "me" (the authed account); for multi-account,
  // make sure the active connection's alias matches the desired sender.
})
```

**Reply in thread:** use `GMAIL_REPLY_TO_THREAD` with the original `thread_id` — leave `subject` empty so it stays in the same thread.

**Drafts:** `GMAIL_CREATE_EMAIL_DRAFT` then `GMAIL_SEND_DRAFT` when Eitan confirms.

**Attachments:** Composio supports attachments via the `attachment` field (`{ name, mimetype, s3key }`). The schema is marked `file_uploadable: true`, which means Composio's MCP runtime handles local-file uploads transparently — pass the file and it does the S3 step behind the scenes. *Not yet end-to-end-tested in this vault* — if the upload flow misbehaves, fall through to Route B until verified.

## ROUTE B — gog CLI (fallback)

```bash
gog gmail send \
  --account stanford \
  --to "recipient@example.com" \
  --subject "Subject line" \
  --body "Email body" \
  --attach "/path/to/file"  # if applicable
```

## Flags / Field Reference

| Concept | Composio (Route A) | gog (Route B) |
|---|---|---|
| Recipient | `recipient_email` / `extra_recipients` | `--to` |
| CC / BCC | `cc` / `bcc` | `--cc` / `--bcc` |
| Subject | `subject` | `--subject` |
| Plain body | `body` (with `is_html: false`) | `--body` |
| HTML body | `body` (with `is_html: true`) | `--body-html` |
| Attachment | `attachment` (requires s3key) | `--attach <path>` |
| Send-from alias | `from_email` (verified alias only) | `--from` |
| Reply in-thread | `GMAIL_REPLY_TO_THREAD` w/ `thread_id` | `--reply-to-message-id` / `--thread-id` |

## Notes

- `eitan@darwish.com` should be added as a Composio Gmail account (alias `personal`) so multi-account routing works on Route A. Until then, sending from personal requires Route B.
- Composio is authenticated per-account; gog is a single-process auth tied to your active credentials file.
- For academic assignment reviews, see also `Skills/academic-pipeline/review.md`.
