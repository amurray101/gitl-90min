---
name: draft-email
title: Draft Email
type: skill
tags: [skill, email, communication, composio, gog]
created: 2026-04-10
updated: 2026-05-08
---

# Draft Email Skill

> Create properly formatted email drafts with verified recipient addresses, written in Eitan's voice. Defaults to Composio Gmail; falls back to gog.

**Routing:** see [[Skills/connector-routing|connector-routing.md]]. Default Composio Gmail (`GMAIL_CREATE_EMAIL_DRAFT`); fall back to `gog gmail drafts create`; STOP if neither is active.

## Process

### 0. Load Eitan's Voice
**Before writing any body content**, read [[Reference/email-writing-style|Reference/email-writing-style.md]]. It covers openers, closers, tone, templates for common email types (cold reconnect, decline, group ask, structured recommendation), and what to avoid. Skipping this step produces generic AI prose that doesn't sound like Eitan.

### 1. Verify Recipients
For each recipient:
1. **Check People files first** — search `Memory/People/[name].md` for existing email.
2. **If no email found, try contacts search:**
   - **Route A (Composio):** Search via `mcp__composio__COMPOSIO_SEARCH_TOOLS` with use_case `"search Google contacts for a person by name"` to discover the right tool slug, then execute.
   - **Route B (gog):** `gog contacts search "First Last"` (note: Directory search requires People API which may not be enabled).
3. **If found via search, enrich the People file** with the email address.
4. **If still no email found, ASK USER** — never guess addresses.

### 2. Format Email Content
- Plain text is fine for most email; use HTML only when the formatting matters (lists, bold, multi-direction asks).
- Composio: pass `body` and set `is_html: true` for HTML.
- gog: use `--body-html` for HTML.
- Convert markdown to HTML if needed:
  - `**bold**` → `<b>bold</b>`
  - `- item` → `<ul><li>item</li></ul>`
  - Line breaks → `<br>`
  - Paragraphs → `<p>text</p>`

### 3. Create Draft

**Route A — Composio (default):**

```
GMAIL_CREATE_EMAIL_DRAFT({
  recipient_email: "verified@email.com",
  extra_recipients: ["second@email.com"],     // additional 'To' recipients
  subject: "Subject Line",
  body: "<properly formatted HTML>",
  is_html: true,                                // false for plain text
})
```

**Route B — gog (fallback):**

```bash
gog gmail drafts create \
  --to="verified@emails.com,second@email.com" \
  --subject="Subject Line" \
  --body-html="<properly formatted HTML>"
```

## Critical Rules
- **NEVER guess email addresses**
- **ALWAYS verify against People files or available search**
- **AUTO-ENRICH People files when you find new emails**
- **ASK USER if you can't find verified addresses**

## Example HTML Formatting
```html
Hey Name,<br><br>

<b>Direction 1: Topic</b><br>
<ul>
<li><b>Option A:</b> Description</li>
<li><b>Option B:</b> Description</li>
</ul>

<b>Direction 2: Topic</b><br>
<ul>
<li><b>Option A:</b> Description</li>
</ul>

Best,<br>
Eitan
```
