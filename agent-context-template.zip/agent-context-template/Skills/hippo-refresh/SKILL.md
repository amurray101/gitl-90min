---
name: hippo-refresh
description: Atomic skill — rewrites Memory/Hippocampus.md every nightly /rem-cycle. Refreshes Now from last 3 days of Daily/ + current Radar; refreshes Arc if ≥48h stale; prunes items that no longer have an upstream referent. The morning-fresh working-memory step in the brain analogy.
title: "Hippocampus Refresh — Nightly Working-Memory Rewrite"
type: skill
created: 2026-05-06
updated: 2026-05-06
tags: [skill, vault, memory, automation, sleep, system, hippocampus]
trigger: "Nightly via /rem-cycle as Step 5; or manual /hippo-refresh"
---

# Hippocampus Refresh — Nightly Working-Memory Rewrite

> The morning-fresh step. Every night, after extract/embed/spider/radar-verify have done their consolidation, this skill rebuilds [[Memory/Hippocampus|Hippocampus.md]] from the upstream sources of truth — last 3 days of `Memory/Daily/` and current `Radar.md` — and prunes anything that no longer has a referent there.

The biological analogy is tight. REM/NREM consolidation moves recent experience into long-term storage and resets the hippocampus for the next day. This skill plays the same role: Daily/ → topic notes is the cortical handoff (extract); the rewrite here is the working-memory reset that lets {{agent_name}} wake up to a clean Now.

## Design rules

1. **rem-cycle is the only writer.** `/handoff` is being sunset in favor of hooks. Until that lands, `/handoff` may still write Hippocampus during a session — but the canonical morning state comes from this skill at 4:00am. The latest write wins; rem-cycle is always latest by definition (it runs after the last possible session of the night).
2. **Refresh-always, no skip-if-fresh check.** rem-cycle owns mornings, period. The failure mode of skip-if-fresh is silent no-op; refresh-always avoids that and re-affirms recent state cheaply.
3. **Now is rebuilt, not patched.** Read the upstream sources, regenerate the Now block from scratch. Never carry forward a Now bullet whose referent isn't in last 3 days of Daily/ or current Radar.
4. **Arc is refreshed only if ≥48h stale.** Cheaper, more stable. `arc-updated:` is the gate.
5. **Frontmatter discipline (inherited).** `updated:` and `arc-updated:` are scalar timestamps only — `YYYY-MM-DD` or `YYYY-MM-DD <coarse-time>`. No prose, parens, brackets, wikilinks, or colons inside these fields. ([[Skills/session-handoff/SKILL|session-handoff]] line 142.)
6. **Wikilinks are mandatory.** Hippocampus is the most-read file in the vault; every named person/project/meeting/course/doc must be a wikilink so {{agent_name}} can jump in the same turn. Confirm targets exist before linking.
7. **Target ≤1,500 words.** If it grows, cut. Hippocampus is a snapshot, not a library.
8. **Cron-safe.** No HITL prompts. Skill must run unattended.

## Procedure

### Step 0 — Setup

1. `today = YYYY-MM-DD` (system date, local timezone).
2. Read current `Memory/Hippocampus.md`. Parse frontmatter; capture `arc-updated:`.
3. Compute `arc_age_hours = now - arc-updated`. If unparseable, treat as stale (force Arc refresh).
4. Set `refresh_arc = (arc_age_hours >= 48)`.

### Step 1 — Gather upstream sources

1. **Daily/** — read `Memory/Daily/<today>.md`, `<today-1>.md`, `<today-2>.md`. Skip files that don't exist. These are the raw arc input.
2. **Radar** — read `Radar.md`. Parse the four sections (Urgent / Active / Watching / Open Loops). Capture each item's title + body + `<!-- id:r_xxx -->`.
3. **Topic notes (optional)** — if extract just promoted entries into specific topic notes (visible in the rem-cycle report from Step 1), capture the new locations to wikilink them in the arc.
4. **Hippocampus prior Now** — read it but use only as a *reference for what was happening yesterday*, not as a source of truth. Anything in prior Now without a current referent must be pruned.

### Step 2 — Rewrite the Now block

The Now section has six standard sub-blocks. Rebuild each from scratch using the rubric below.

#### 2a. Today

`**Today — <Day> <Month> <Date>, <Year> (<coarse-time>).**` followed by 1–3 sentences on what's heavy right now. Pull the headline from Radar.Urgent + the most recent Daily/ entry. Keep it tight — this is the snap-into-context line.

#### 2b. Last session

`**Last session (<approx start> → <approx end>) — <one-line title>.**` followed by 2–6 sentences distilling the most recent session block from today's (or yesterday's) Daily/ file. Replace what was there last night; do not concatenate.

#### 2c. Earlier today / earlier session blocks (optional)

If today's Daily/ contains multiple distinct session blocks, cascade them in reverse-chrono. Otherwise omit.

#### 2d. Last 3 days — the arc

One bullet per day, 2–4 lines each:

```markdown
- **[[Memory/Daily/YYYY-MM-DD|Mon May N]]:** distilled summary…
```

Drop the oldest day off the bottom each cycle. The arc is always exactly 3 days deep.

#### 2e. Active this week

Mirror Radar.Active line-for-line, compressed to short-form. Each item carries its `r_xxx` ID. **Do not invent items not present in Radar.Active.** If Radar shows it cleared, it's gone here too — that's the prune.

#### 2f. Watching

Mirror Radar.Watching. One-line compressed list (` · `-separated IDs + half-sentence labels). Same prune rule.

#### 2g. Parked / open loops

Mirror Radar.Open Loops. Same compressed format. Same prune rule.

### Step 3 — Pruning rubric (the explicit reset)

Apply in order. Each rule names what it removes from the new Now, even if it appeared in the prior Now.

| Rule | Removes |
|------|---------|
| **P1 — No daily referent** | Any "Last session" / "Earlier today" content from yesterday or older. The block is replaced, not merged. |
| **P2 — Off the 3-day horizon** | Day bullets from >3 days ago drop off the arc bottom. |
| **P3 — Cleared from Radar** | Any Active/Watching/Open-Loops item that is no longer present in `Radar.md` (radar-verify ran in Step 4 of rem-cycle and already deleted HIGH-confidence cleared lines). |
| **P4 — Recurrence-only** | If a Radar item carries `Recurrence:` markers but no fresh activity in last 3 days of Daily/, demote from Active → Open Loops. |
| **P5 — Empty wikilink targets** | If a wikilink in the new Now points to a file that doesn't exist (target was archived/renamed since last cycle), drop the wikilink — keep the plain-text mention. |

Pruning is the half of the brain analogy {{agent_name}} has been missing. Without it, Now grows monotonically and stops being working memory.

### Step 4 — Refresh the Arc block (conditional)

If `refresh_arc` is True, rewrite `## Arc` from current state. Sub-sections (existing convention):

- **Swordpoint** — HoldCo state, who's who, current strategic posture.
- **RACI** — product status snapshot.
- **Academics** — current quarter, live courses, upcoming deadlines.
- **Foundry** — client pipeline state.
- **Relationships currently active** — close circle + recent surfacing + parked-but-alive.
- **The through-line right now** — 2–3 sentences on what this chapter is about.

Source material: `Hippocampus.Now` (just rewritten), top-level domain index files (`0-*-index.md`), `Memory/People/` for the close circle.

If `refresh_arc` is False, **leave Arc untouched**. Do not re-stamp `arc-updated:`.

### Step 5 — Write the file

1. Build the new Hippocampus.md content: frontmatter + `# Hippocampus — {{agent_name}}'s Working Memory` + tagline + `---` + `## Now` (rewritten) + `---` + `## Arc` (rewritten if refresh_arc, else carried forward verbatim) + `---` + `## Pointers`.
2. Update frontmatter:
   - `updated: <today> <coarse-time>` — always.
   - `arc-updated: <today>` — only if `refresh_arc` was True.
   - `maintained-by: /rem-cycle (Now nightly; Arc if >48h stale)` — replace the `/handoff` reference once handoff is fully sunset; until then leave both attributions if useful.
3. Word-count check: if the rendered file exceeds 1,500 words, log a `HIPPO_OVERSIZE` warning to the rem-cycle report and proceed (don't auto-truncate — {{user_name}} reviews).
4. Write atomically (write to `Memory/Hippocampus.md.tmp` then rename) so a crash mid-write doesn't corrupt the file.

### Step 6 — Report back to /rem-cycle

Return a summary structure:

```yaml
status: ok
now_rewritten: true
arc_rewritten: <true|false>
arc_age_hours_at_start: <int>
items_pruned:
  - active: <count>
  - watching: <count>
  - open_loops: <count>
word_count: <int>
oversize_warning: <true|false>
```

rem-cycle's Step 5 section in the morning report shows this verbatim plus a one-line summary.

## What this skill does

- Rewrites `Memory/Hippocampus.md` Now block every cycle from Daily/ + Radar.
- Refreshes Arc block if ≥48h since last Arc stamp.
- Prunes items per rubric P1–P5; this is the explicit "reset" the brain analogy demands.
- Reports its work to `/rem-cycle` for inclusion in the nightly report.

## What this skill does NOT do

- Does not modify Daily/, Radar.md, topic notes, People/, or any other vault file.
- Does not delete files (never-delete-files rule).
- Does not retry on partial failure — it either rewrites cleanly or reports an error and leaves the prior Hippocampus.md in place.
- Does not auto-truncate over-1,500-word output ({{user_name}} reviews oversized writes).
- Does not send messages or external API calls.

## Failure modes

- **Daily/ files missing for last 3 days** — degrade gracefully: arc carries fewer than 3 day-bullets; emit a `HIPPO_THIN_ARC` warning to the report.
- **Radar.md unparseable** — abort (don't write a half-built Hippocampus). Status = failed; rem-cycle queues a Radar item.
- **Frontmatter parse error on existing Hippocampus** — treat as Arc-stale, force full refresh, log `HIPPO_FRONTMATTER_RECOVERED`.
- **Word count >1,500** — write anyway, flag for review.
- **Atomic-rename failure** — leave prior Hippocampus.md untouched; status = failed.

## Coexistence with /handoff (transitional)

Right now `/handoff` Step 3 also rewrites Hippocampus. Per {{user_name}}'s May 6 call, `/handoff` is being sunset in favor of hooks (Foundry process learning). Until that migration is complete, both writers may touch this file:

- `/handoff` writes during/after a session.
- `/rem-cycle → hippo-refresh` writes overnight.

Latest-write-wins is fine because rem-cycle is always latest in the daily cycle. No skip-if-fresh check; rem-cycle re-affirms or replaces whatever `/handoff` wrote.

Once `/handoff` is fully sunset, this skill is the sole writer.

## Related skills

- [[Skills/rem-cycle/SKILL|REM Cycle]] — calls this as Step 5, after radar-verify, before diagnostics.
- [[Skills/extraction/SKILL|Extract]] — Step 1 of rem-cycle; produces the topic-note promotions that the arc references.
- [[Skills/spider/SKILL|Spider]] — Step 3 of rem-cycle; ensures wikilink targets resolve.
- [[Skills/radar-verify/SKILL|Radar Verify]] — Step 4 of rem-cycle; deletes HIGH-confidence cleared Radar lines so this skill's prune mirrors them.
- [[Skills/session-handoff/SKILL|Session Handoff]] — line 142 frontmatter discipline rule (scalar timestamps only); transitional dual-writer until handoff sunsets.
