---
name: spider
description: Graph audit — crawls the vault to discover missing links, apply tags, resolve orphans, and freshen Context.md files.
title: "Spider — Graph Audit"
type: skill
created: 2026-04-08
updated: 2026-04-09
tags: [skill, architecture, vault]
trigger: "Manual invocation (/spider). Also useful after bulk extraction or imports."
---

# Spider — Graph Audit

> Crawls the vault and weaves the graph tighter: discovers missing links, applies tags, resolves orphans, freshens index files.

## Procedure Overview

1. **Phase 0: Extraction** — Find and extract all unprocessed content first
2. **Phase 1-4: Graph Audit** — Connect what exists

**Spider always starts with extraction** to ensure all raw content is processed before optimizing connections.

## Phase 0: Extraction First

Before any graph audit work, Spider runs extraction:

1. **Auto-discovery:** Scan `Memory/Daily/` and `Memory/Meetings/` for files with `extracted: false`
2. **Batch extraction:** Process all unextracted files using [[Skills/extraction/SKILL|The Librarian]]
3. **Wait for completion:** Only proceed to graph work after all source files marked `extracted: true`

This ensures Spider is connecting complete knowledge, not missing insights trapped in unprocessed Daily files or Granola meetings.

## Phase 1-4: Graph Audit

**Spider doesn't create new knowledge or extract content — that's The Librarian's job.** Spider connects what already exists.

### What Spider Does

| Pass                     | What it finds                                                             | What it does                                                           |
| ------------------------ | ------------------------------------------------------------------------- | ---------------------------------------------------------------------- |
| **Orphan scan**          | Files with zero inbound wikilinks                                         | Adds them to the nearest index file or cross-links from a related file |
| **Link discovery**       | Files that share entities, topics, or themes but don't link to each other | Adds wikilinks between them                                            |
| **Tag enrichment**       | Files that touch themes in the tag taxonomy but aren't tagged for them    | Adds relevant tags to frontmatter                                      |
| **Index file freshness** | Index files missing links to children in their directory                  | Adds the missing entries                                               |
| **Frontmatter hygiene**  | Files missing `tags: []` or other recommended frontmatter fields          | Adds minimum viable frontmatter                                        |
| **Meeting back-link pass** | Meeting files in `Memory/Meetings/` with no inbound wikilinks            | Back-links the meeting from each attendee's People file + relevant domain Logs; if still orphaned, enriches the meeting body with outbound wikilinks |

### What Spider Does NOT Do

- Create new files (extraction does that)
- Extract knowledge from Daily/Meeting files (that's The Librarian)
- Modify {{user_name}}'s prose — only frontmatter and link/reference sections
- Delete or restructure anything
- Move files between directories

## Link Discovery — The Core Pass

This is the highest-value pass. The goal: find files that *should* know about each other but don't.

### Discovery Signals

Spider looks for these signals that two files should be linked:

| Signal | Example | Link Type |
|--------|---------|-----------|
| **Shared entity names** | Two files mention "WinGen" but neither links to `Swordpoint/WinGen/0-wingen-index.md` | Add `[[Swordpoint/WinGen/0-wingen-index.md\|WinGen]]` to both |
| **Shared people** | A lesson file and a log file both mention the same person | Add `[[Memory/People/name]]` to both; add back-links from the person file |
| **Shared tags** | Two files tagged `#gtm` in different domains with overlapping content | Add a "See also" wikilink between them |
| **Temporal proximity + topic overlap** | A Daily file and a domain Log from the same date cover the same event | Cross-link them |
| **Parent-child gap** | A file lives inside a domain folder but isn't linked from that domain's index file | Add to index file |
| **Dangling references** | A file mentions a concept by name that has its own file, but uses plain text instead of a wikilink | Convert plain text to `[[wikilink]]` |

### Link Placement Rules

- **Wikilinks go in natural reading positions** — not dumped in a "Links" section at the bottom unless there's no better spot.
- **For entity mentions in prose:** convert the first occurrence of a plain-text name to a wikilink. Don't wikilink every occurrence.
- **For cross-domain "see also" connections:** add a brief `> See also: [[path]]` line near the relevant content, or in a "Related" section if the file already has one.
- **For index file additions:** add to the appropriate category group. Don't just append to the bottom.
- **Never break existing links.** Only add new ones.

### Meeting Back-Link Pass

`Memory/Meetings/` has no index file by design — the folder + attendee wikilinks + Spider are the discovery layer. To keep meetings tied to the graph:

1. **Read each meeting's frontmatter.** Pull `attendees: []` and `domains: []`.
2. **Push back-links into People files.** For each attendee, ensure their `Memory/People/<name>.md` references this meeting — either via a `## Recent interactions` section (preferred) or inline if the meeting is already discussed in prose. Skip if the back-link already exists.
3. **Push back-links into domain Logs.** For each entry in `domains:`, ensure the domain's `Logs/` (or domain index, if no Logs file exists) references the meeting where temporally appropriate.
4. **Orphan fallback — outbound enrichment.** If after steps 2–3 the meeting still has zero inbound wikilinks (rare, but possible for solo / off-topic meetings), enrich the meeting itself:
   - Run dangling-reference detection on the meeting body — convert plain-text entity mentions (people, projects, lessons, concepts with their own files) to wikilinks in place.
   - If still nothing lands, append a `## Related` section with judgment-call wikilinks to entities the meeting discusses or implicates. Use restraint — 1–3 high-quality links beat 10 weak ones.

This is the one place Spider is allowed to add wikilinks *inside* a meeting's prose body (vs. just frontmatter / Related sections elsewhere). Justification: meeting summaries are Granola-generated transcripts, not {{user_name}}'s prose, so converting plain-text mentions to wikilinks doesn't violate the "don't modify {{user_name}}'s prose" rule.

### Dangling Reference Detection

Spider builds a lookup table of all file titles and common aliases, then scans file content for plain-text mentions that could be wikilinks:

1. Build index: `{filename-without-extension → full-path}` + `{frontmatter title → full-path}`
2. For each file, scan content for exact matches against the index
3. Skip matches inside existing wikilinks, code blocks, and frontmatter
4. Convert first plain-text occurrence to `[[path|display text]]`

**Alias examples:**
- `WinGen` → `[[Swordpoint/WinGen/0-wingen-index.md|WinGen]]`
- `SlideBitch` → `[[SlideBitch/0-slidebitch-index.md|SlideBitch]]`
- Person names → `[[Memory/People/firstname-lastname.md|Firstname Lastname]]`

## Full Procedure

### Phase 0: Extraction (Always First)

1. Run [[Skills/extraction/SKILL|extraction]] auto-discovery and processing
2. Verify all source files in `Memory/Daily/` and `Memory/Meetings/` have `extracted: true`
3. Only proceed if extraction is complete

### Phase 1: Inventory

1. Scan all `.md` files in scope (excluding Archive/)
2. For each file, record:
   - Path
   - Frontmatter (tags, type, title)
   - All outbound wikilinks
   - All inbound wikilinks (computed from other files' outbound links)
   - Plain-text mentions of known entities (for dangling reference detection)
3. Build the file index and alias lookup table

### Phase 2: Analysis (domain-scoped, parallelizable)

For each domain in scope, a subagent:

1. **Orphan check:** files in this domain with zero inbound links → propose index file addition or cross-link
2. **Link discovery:** scan files for shared entities, people, tags, topics → propose new wikilinks
3. **Tag enrichment:** check each file against the tag taxonomy → propose tag additions
4. **Index file freshness:** diff directory contents against index file entries → propose additions
5. **Frontmatter hygiene:** files missing `tags: []` → propose addition
6. **Meeting back-link pass** (memory agent only, scoped to `Memory/Meetings/`): back-link each meeting into attendee People files + domain Logs; orphan fallback enriches the meeting body. See [[#Meeting Back-Link Pass]].

Output: a change manifest (list of proposed edits) written to `/tmp/{{agent_name}}-spider/domain-name.json`

### Phase 3: Cross-Domain Connections

A coordinator agent reads all domain manifests and looks for:
- Files in different domains that should link to each other
- Cross-domain tag patterns (e.g., a finance file and a swordpoint file both touching `#gtm`)
- People files that should back-link to newly discovered mentions

Output: appends cross-domain proposals to `/tmp/{{agent_name}}-spider/cross-domain.json`

### Phase 4: Apply

1. Review all manifests
2. Apply changes — each edit is minimal and additive
3. Produce a summary: links added, tags applied, orphans resolved, index file entries added
4. Flag ambiguous cases to Radar.md under Open Loops

### Phase 5: Embedding Sync

After all edits are applied, re-embed changed and new files only if the embedding stack exists:

1. Check for `<your-vault>/Workbench/vault-embeddings/.venv/bin/vsearch`
2. If present, run `uv run vsearch index --diff` from `<your-vault>/Workbench/vault-embeddings/`
3. If missing, skip embedding sync and report `embed_mode: skipped`; do not fail Spider
4. When it runs, report embedding stats alongside the spider summary

## Swarm Execution

Follows [[Skills/swarm/SKILL|swarm protocol]]. Domain-scoped agents get exclusive write zones matching extraction's pattern:

| Agent | Scope | Write Zone |
|-------|-------|------------|
| academics | `Academics/` | Academics/ frontmatter + links |
| swordpoint | `Swordpoint/` (all sub-entities) | Swordpoint/ frontmatter + links |
| slidebitch | `SlideBitch/` | SlideBitch/ frontmatter + links |
| {{agent_name}}-infra | `agent/` | agent/ frontmatter + links |
| personal | `Personal/`, `Finance/` | Personal/, Finance/ frontmatter + links |
| memory | `Memory/` (People, Lessons, Preferences, etc.) | Memory/ frontmatter + links |
| skills | `Skills/`, `Reference/` | Skills/, Reference/ frontmatter + links |
| cross-domain | All (read-only in Phase 2, write in Phase 3) | Cross-domain links only |

## Scoping

Spider can run at different scopes:

| Scope | When to use | Command |
|-------|------------|---------|
| **Full vault** | Periodic deep audit, after major imports | `/spider` |
| **Single domain** | After domain-specific extraction | `/spider Swordpoint` |
| **Recent files** | After /handoff creates new extracted files | `/spider --recent 7d` |

## Cost Management

- Full vault audit on 400+ files is token-intensive. Use `--model sonnet` for domain agents; reserve Opus for cross-domain coordination.
- For routine use, scope to recent files or a single domain.
- The inventory phase (Phase 1) is cheap — just file reads and indexing. The analysis phases are where tokens burn.

## Output

- Summary of all changes made (printed to conversation)
- Change counts: links added, tags applied, orphans resolved, index file entries updated, frontmatter fixed
- Ambiguous cases appended to Radar.md under Open Loops