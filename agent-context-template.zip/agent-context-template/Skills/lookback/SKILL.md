---
name: lookback
description: Mine 6 months of email, calendar, and meeting transcripts to draft a vault proposal — the Foundry "wow moment." Surfaces candidate people, threads, themes, and voice samples for {{firstName}}'s review.
title: "Lookback — Discovery-First Phase 2"
type: skill
created: {{today}}
updated: {{today}}
tags: [skill, lookback, onboarding, discovery, phase-2, library-standard]
trigger: "First-session use during onboarding (Phase 2 of discovery-first flow). Also `/lookback --refresh` to re-mine on a schedule (default: monthly)."
---

# Lookback — Discovery-First Phase 2

> The wow moment. {{agentName}} reads the last 90 (or 180, or 365) days of {{firstName}}'s email, calendar, and meeting transcripts and proposes — in writing, with evidence — who their important people are, what threads keep coming back, what themes the emails actually argue about, and what {{firstName}}'s own voice sounds like. {{firstName}} reads the proposal and confirms / corrects. The corrected proposal becomes the seed for People stubs, domain Logs, and the agent's voice anchoring.
>
> This is **not** an extract pass — extraction reads vault notes and routes them. Lookback reads the *outside world* (email, calendar, Granola, pre-seeded data) and produces a draft *for the vault*. The two are siblings: lookback proposes; extract files. The pipeline is `lookback → review → extract on accepted proposals`.

## What this produces

Three files written under `~/{{vaultDir}}/Memory/Daily/_lookback/`:

| File | Format | Audience | Consumer |
|---|---|---|---|
| `proposal.md` | Markdown — the human-readable headline | {{firstName}} reads this | The seminar moment ("look at what {{agentName}} found") |
| `candidates.json` | Structured JSON | Downstream prompts (`extract`, `spider`) and the portal UI | Programmatic — parse to seed People stubs, themes, domain configs |
| `voice-samples.md` | Markdown — 10-20 samples of {{firstName}}'s sent emails | Future drafts, voice anchoring | `Skills/draft-email/` reads this for voice ground |

Plus **one** observation row appended to `~/{{vaultDir}}/{{agentName}}/state/prompt_observations.jsonl` for the drift dashboard (per `r_promptaudit`).

## What this DOES NOT do

- **Never writes back to gog / Gmail / Calendar / Granola.** This is read-only on every external surface. The skill mines; it does not mutate. Even labels are off-limits in this skill (the [[Skills/email-triage/SKILL|email-triage]] skill is what handles labels — different contract).
- **Never auto-creates People stubs.** Proposals are *proposals*. {{firstName}} reviews the proposal, then runs extract or `/onboard --apply-lookback` to convert accepted candidates to vault files. Lookback doesn't write under `Memory/People/` or `<Domain>/Logs/`.
- **Never sends data off-machine.** The LLM extraction passes (Phase 5) run via the local `claude` CLI on metadata + bodies that stay on disk. No third-party services.
- **Never deletes anything.** Including from `Memory/Daily/_seed/`. {{firstName}} curates the seed.

## Why this is the wow moment

The May 11 seminar attendees see {{agentName}} produce, in five minutes of clock time, a proposal that says: "Here are the 30 people you actually email most, the 12 threads that keep recurring, the 4 domains your work organizes around, and 15 sent emails that anchor your voice. Confirm what's right and I'll seed your vault." That output, grounded in evidence the user can audit ("you mentioned this 47 times across 12 threads"), is what makes the rest of the Foundry library worth shipping. Lookback IS the discovery-first onboarding's Phase 2 made tangible.

---

# PRE-CHECKS

> Pre-checks are mandatory per the [[Foundry/Templates/library-standard|Library Standard]] § The Prompt Contract § PRE-CHECKS. Lookback reads from external surfaces (gog, Granola, filesystem) AND writes to {{firstName}}'s vault — so the pre-checks verify both halves of that contract. Run all probes in parallel; emit one status panel; halt on any FAIL before mining begins.
>
> The only legitimate bypass is when a single follow-up question gates a pre-check itself (e.g. "which time window do you want?" before scoping the gog queries). Ask, wait, then run pre-checks with the answer.

## PC-1 — Canonical-architecture probe

Verify the load-bearing vault paths the lookback writes to. Run all four checks in parallel:

```bash
test -d ~/{{vaultDir}}/Memory/Daily/                && echo "PC-1a OK" || echo "PC-1a FAIL"
test -d ~/{{vaultDir}}/Memory/Daily/_seed/          && echo "PC-1b OK (pre-seed present)" || echo "PC-1b INFO (no pre-seed)"
mkdir -p ~/{{vaultDir}}/Memory/Daily/_lookback/     && test -w ~/{{vaultDir}}/Memory/Daily/_lookback/ && echo "PC-1c OK" || echo "PC-1c FAIL"
test -f ~/{{vaultDir}}/CLAUDE.md                    && echo "PC-1d OK" || echo "PC-1d FAIL (need this for vault-deviation parse)"
test -f ~/{{vaultDir}}/answers.yaml                 && echo "PC-1e OK" || echo "PC-1e MISSING (will prompt for accounts inline)"
```

**Failure modes and remediation:**

- `PC-1a FAIL` → **HALT.** Tell {{firstName}}: "I can't find `~/{{vaultDir}}/Memory/Daily/`. Run the onboarding setup prompt first OR add a `## ⚠️ Vault customized` block in `CLAUDE.md` documenting the path rename. See [[Foundry/Templates/library-standard]] § Canonical-Architecture Assumption."
- `PC-1b INFO` → Acceptable. Pre-seed is optional — lookback will skip Phase 1 (pre-seed read) and start at Phase 2 (gog mining). Surface in panel: "No `_seed/` directory — skipping Phase 1, starting at connector mining. Drop VCFs / essays / Claude exports under `~/{{vaultDir}}/Memory/Daily/_seed/` if you want them folded in."
- `PC-1c FAIL` → **HALT.** Filesystem permissions issue or disk full on the output directory. Surface and ask {{firstName}} to fix.
- `PC-1d FAIL` → **HALT.** CLAUDE.md is the source of truth for tier-1 domains and vault deviations.
- `PC-1e MISSING` → Acceptable. Lookback falls back to asking {{firstName}} for email accounts inline (one extra prompt). Surface in panel.

## PC-2 — Vault-deviation parse

Read the first 200 lines of `~/{{vaultDir}}/CLAUDE.md`. If it contains `## ⚠️ Vault customized` (case-sensitive header), parse the deviations and surface in the panel: "Detected vault customization — using `<old-path>` → `<new-path>`. Adapting." Apply the substitution to all path references for the rest of this run. **Do not silently rewrite the prompt's path constants** — surface the substitution.

## PC-3 — gog availability + auth

Lookback's biggest dependency. Probe:

```bash
command -v gog >/dev/null 2>&1 && echo "PC-3a gog OK" || echo "PC-3a FAIL: gog not installed"
gog --help 2>&1 | grep -qi "gmail\|calendar" && echo "PC-3b correct binary" || echo "PC-3b FAIL: wrong gog binary on PATH"
gog auth list 2>&1 | grep -qE "(gmail|@)" && echo "PC-3c at least one account wired" || echo "PC-3c FAIL: no accounts authenticated"
gog auth list --check 2>&1 | grep -q "expired\|revoked" && echo "PC-3d WARN: at least one token expired" || echo "PC-3d OK"
```

**Failure modes:**

- `PC-3a FAIL` → **HALT.** "gog isn't installed. Run [[Foundry/Templates/integrations/gmail|the Gmail × gog setup prompt]] first, then re-run lookback."
- `PC-3b FAIL` → **HALT.** "There's a binary on PATH named `gog` that isn't the Foundry-library gog (it's missing the `gmail`/`calendar` subcommands). Likely the wrong project. Run `brew uninstall gog && brew install gogcli`."
- `PC-3c FAIL` → **HALT.** "No Google accounts authenticated. Run `gog auth manage --add <your-email>` for at least one account, then re-run lookback. See [[Foundry/Templates/integrations/gmail]] Phase 3."
- `PC-3d WARN` → **PROCEED but flag.** Lookback runs on the healthy accounts and reports the expired ones at end-of-run so {{firstName}} can re-auth them.

## PC-4 — Account inventory (read from answers.yaml or ask)

Lookback needs the list of email accounts to mine. Source priority:

1. **`~/{{vaultDir}}/answers.yaml`** under `tools.email_accounts[]` if present.
2. **`gog auth list`** intersected with anything {{firstName}} has flagged as `discovery: false` in their preferences (some users want personal-only mining, not work).
3. **Inline prompt** as a last resort.

```bash
# Read answers.yaml if it exists
if [ -f ~/{{vaultDir}}/answers.yaml ]; then
  yq '.tools.email_accounts[]' ~/{{vaultDir}}/answers.yaml 2>/dev/null
fi
# Cross-reference with gog auth list
gog auth list --json 2>/dev/null | jq -r '.[].email'
```

If the two lists disagree (account in answers.yaml but not authenticated, or vice versa), surface the diff in the panel and ask {{firstName}} which set is authoritative for THIS run. Default: intersection (accounts both declared AND authenticated).

**Edge case — single-account user:** If only one account is wired, skip the prompt and just use it. Surface "Mining 1 account: {{addr}}" in the panel.

## PC-5 — Granola MCP availability (informational)

Granola is the meeting-transcript surface. It's nice-to-have, not load-bearing.

```
# Probe — pseudo-code, runtime calls the MCP tool:
mcp.list_tools()
  → if "mcp__claude_ai_Granola__list_meetings" present → echo "PC-5 OK (Granola MCP wired)"
  → else → echo "PC-5 INFO (no Granola — meeting mining will skip)"
```

**Interpret:**

- Present → Phase 2 mines Granola. Phase 4 includes meeting-attendee candidates.
- Absent → Phase 2 skips Granola, Phase 4 only mines email + calendar attendee data. Surface in panel: "Granola MCP not present — meeting transcripts skipped. Install [Granola MCP](https://granola.ai) if you want meeting candidates folded in."

## PC-6 — Time window arg parse

Lookback's default is **90 days back**. Configurable via:

| Arg | Behavior |
|---|---|
| `--days 30` | Last 30 days |
| `--days 90` (default) | Last 90 days |
| `--days 180` | Last 6 months |
| `--days 365` | Last year |
| `--since 2025-01-01` | Explicit start date |

Validate the arg parses as a positive integer or ISO date. If the user passes `--days 0` or a negative number, halt with: "Time window must be positive."

If `--days >= 730`, surface a warning: "Mining 2+ years of email costs roughly N tokens for the LLM extraction phase. Consider `--days 365` unless you have a specific reason. Proceed?" (Wait for confirmation.)

## PC-7 — Output disk-space probe

Conservative estimate: **~5MB of analysis per 1000 emails mined**, plus ~50KB per Granola transcript, plus the JSON candidates file (~500KB for a healthy 90d window). Probe disk:

```bash
df -k ~/{{vaultDir}}/Memory/Daily/_lookback/ | awk 'NR==2 {print $4}'  # KB available
```

Halt if available KB < 50000 (50MB minimum buffer). Tell {{firstName}}: "Less than 50MB available on the volume hosting your vault. Make more disk space available and re-run."

## PC-8 — claude CLI availability (for Phase 5 LLM extraction)

The theme-mining phase calls out to the local `claude` CLI for batch LLM extraction. Probe:

```bash
command -v claude >/dev/null 2>&1 && echo "PC-8a OK" || echo "PC-8a WARN: claude CLI not on PATH"
test -n "$ANTHROPIC_API_KEY" || claude --help 2>&1 | grep -q "api_key" && echo "PC-8b OK" || echo "PC-8b WARN: no API key configured"
```

**Interpret:**

- Both OK → Phase 5 (theme mining) runs.
- Either WARN → Phase 5 falls back to **`--skip-llm-extraction` mode** automatically. Theme mining becomes "top 8 most-frequent thread subjects clustered by simple substring match" instead of LLM-classified domains. Surface in panel: "claude CLI not available — running with `--skip-llm-extraction` (themes will be subject-based clusters, not domain-classified). Install claude CLI to upgrade."

## PC-9 — `jq` and `yq` availability

Cheap probes; lookback does heavy JSON munging.

```bash
command -v jq >/dev/null 2>&1 && echo "PC-9a OK" || echo "PC-9a FAIL: jq required (brew install jq)"
command -v yq >/dev/null 2>&1 && echo "PC-9b OK" || echo "PC-9b WARN: yq missing — answers.yaml parse degrades to grep"
```

**Interpret:**

- `PC-9a FAIL` → **HALT.** jq is non-negotiable for the gog `--json` output processing.
- `PC-9b WARN` → **PROCEED.** answers.yaml parsing falls back to grep; surface in panel.

## Status panel

After all checks complete, emit ONE status panel like this (do not narrate further):

```
┌─ Lookback (Phase 2 — Discovery) — Pre-Check Panel ──────────────┐
│ PC-1 Canonical layout      ✓ Daily, _lookback/ writable         │
│ PC-2 Vault deviations      ✓ none detected                       │
│ PC-3 gog                   ✓ v0.9.2, 3 accounts wired           │
│ PC-4 Account inventory     ✓ stanford.edu, gmail.com, work.com  │
│ PC-5 Granola MCP           ✓ wired (will mine meetings)         │
│ PC-6 Time window           ✓ 90 days (default)                  │
│ PC-7 Disk space            ✓ 12GB available                          │
│ PC-8 claude CLI            ✓ available (LLM extraction enabled) │
│ PC-9 Tooling               ✓ jq, yq                             │
└─────────────────────────────────────────────────────────────────┘
Mining: 90d × 3 accounts → ~2,500 emails est. + ~400 events + ~60 meetings.
Estimated wall-clock: ~6 minutes (4 min mine, 2 min LLM extraction).
Proceeding to Phase 1 (pre-seed read).
```

Any FAIL line aborts the run. Print the panel + the remediation step + halt. Soft warnings (`⚠`) surface but proceed.

---

# CUSTOMIZATION

Knobs lookback honors. All optional; safe defaults are documented inline.

| Knob | Question | Default | Where stored |
|---|---|---|---|
| `--days N` | "How far back to mine?" | 90 | Arg only (per-run) |
| `--since YYYY-MM-DD` | "Explicit start date?" | (computed from `--days`) | Arg only |
| `--accounts a@x,b@y` | "Limit to specific accounts?" | All from answers.yaml | Arg only |
| `--skip-llm-extraction` | "Skip the theme-mining LLM pass?" | false (LLM enabled) | Arg only |
| `--sample-size N` | "How many emails to sample for theme mining?" | 50 | Arg only |
| `--candidate-threshold N` | "Minimum interaction count to be a candidate person?" | 3 | Arg only |
| `--include-promotions` | "Include promotional/marketing email in mining?" | false (excluded) | Arg only |
| `--no-meetings` | "Skip Granola entirely even if MCP is present?" | false | Arg only |
| `--top-people N` | "How many candidate people to surface in proposal.md?" | 30 | Arg only |
| `--top-themes N` | "How many themes/domains in proposal.md?" | 8 | Arg only |
| `--voice-samples N` | "How many sent-email voice samples to extract?" | 15 | Arg only |

**Rationale on defaults:**

- 90 days is enough to surface real patterns without making the LLM extraction phase prohibitively expensive (rough cost: ~$0.50 of Anthropic API on 90d × 3 accounts at default sample-size).
- `--candidate-threshold 3` means "at least 3 interactions in the window" — keeps one-off cold contacts off the People shortlist while admitting genuine collaborators.
- `--top-people 30` is the proposal's review budget. {{firstName}} can scan 30 names in 60 seconds; 100 would drown.

---

# WORK PHASES

Eight phases, in this order. Each phase declares Inputs → Outputs → Parallelism → Done-when. Phases halt on failure; surface the exact remediation rather than retrying silently.

## Phase 1 — Read pre-seed data (cheap, fast)

**Inputs:** `~/{{vaultDir}}/Memory/Daily/_seed/` if it exists.
**Outputs:** A pre-seed manifest at `~/{{vaultDir}}/Memory/Daily/_lookback/_phase1_seed.json` with parsed contacts, voice samples, and prior-context references.
**Parallelism:** All file reads fan out — one subagent per seed-file class.

Skip this phase entirely if `_seed/` doesn't exist (PC-1b reported INFO).

### 1.1 — Parse VCF contact dumps

If `_seed/contacts.vcf` or any `_seed/<role>-directory.vcf` exists, parse for contact records. Two strategies:

**Strategy A — proper VCF parser** (preferred if a parser is available):

```bash
# pseudo — actual implementation uses python vobject or a node vcf library
python3 -c "
import vobject
import json, sys
contacts = []
for vcf_path in sys.argv[1:]:
    with open(vcf_path) as f:
        for vcard in vobject.readComponents(f.read()):
            entry = {}
            if hasattr(vcard, 'fn'):
                entry['display_name'] = vcard.fn.value
            if hasattr(vcard, 'email_list'):
                entry['emails'] = [e.value for e in vcard.email_list]
            if hasattr(vcard, 'tel_list'):
                entry['phones'] = [t.value for t in vcard.tel_list]
            if hasattr(vcard, 'org'):
                entry['org'] = ' '.join(vcard.org.value)
            entry['source_file'] = vcf_path
            contacts.append(entry)
print(json.dumps(contacts, indent=2))
" ~/{{vaultDir}}/Memory/Daily/_seed/*.vcf
```

**Strategy B — grep fallback** (if no Python or no vobject):

```bash
# Cheap: grep FN: lines and EMAIL: lines, pair by ordering
for f in ~/{{vaultDir}}/Memory/Daily/_seed/*.vcf; do
  awk '
    /^BEGIN:VCARD/ { name=""; emails=""; org="" }
    /^FN:/ { sub(/^FN:/, ""); name=$0 }
    /^EMAIL.*:/ { sub(/^EMAIL.*:/, ""); emails = emails (emails ? "," : "") $0 }
    /^ORG:/ { sub(/^ORG:/, ""); org=$0 }
    /^END:VCARD/ { if (name || emails) print name "|" emails "|" org }
  ' "$f"
done | jq -R 'split("|") | {display_name: .[0], emails: (.[1] | split(",")), org: .[2], source_file: "'"$f"'"}' | jq -s .
```

Output: `_phase1_seed.json` § `contacts: [...]`.

### 1.2 — Parse voice-anchoring docs

If `_seed/*.md` or `_seed/*.pdf` files exist (essays, writing samples, prior context), inventory them:

```bash
find ~/{{vaultDir}}/Memory/Daily/_seed/ -maxdepth 2 \( -name "*.md" -o -name "*.pdf" \) | while read f; do
  echo "$f"
  if [[ "$f" == *.md ]]; then
    # Extract first 50 lines as voice-sample candidate
    head -50 "$f"
  elif [[ "$f" == *.pdf ]]; then
    # Use pdftotext if available
    command -v pdftotext >/dev/null 2>&1 && pdftotext "$f" - | head -100
  fi
done > ~/{{vaultDir}}/Memory/Daily/_lookback/_phase1_voice_drafts.txt
```

This is *raw* voice text — the curated voice-samples.md gets built later in Phase 6. Phase 1 just inventories what's available.

### 1.3 — Parse prior Claude/Codex exports

If `_seed/*.zip` or `_seed/*claude*export*` files exist, unzip and surface them:

```bash
for archive in ~/{{vaultDir}}/Memory/Daily/_seed/*.zip; do
  test -f "$archive" || continue
  unzip -l "$archive" | head -20  # inventory; don't auto-unzip large archives
done
```

If the user has a Claude export, ask once: "I see `~/{{vaultDir}}/Memory/Daily/_seed/claude-export.zip`. Want me to unzip it for theme-mining context (Phase 5)? (yes / no — defaults to yes if you don't answer in 30s)." On yes, `unzip -d ~/{{vaultDir}}/Memory/Daily/_seed/_unpacked/`.

### 1.4 — Phase 1 done-when

- `_phase1_seed.json` exists with `contacts` (possibly empty), `voice_drafts` (path list), `prior_exports` (path list).
- All read errors logged to `_phase1_errors.txt` (don't halt on individual file failures — just log and proceed).
- Surface a one-liner: "Pre-seed: N contacts parsed, M voice-draft files inventoried, K prior exports staged."

---

## Phase 2 — Mine connectors (gog, Granola, calendar)

**Inputs:** Account list from PC-4, time window from PC-6.
**Outputs:** Three raw JSON dumps — `_phase2_email.json`, `_phase2_calendar.json`, `_phase2_meetings.json` — under `_lookback/`.
**Parallelism:** One subagent per (surface × account). Email × 3 accounts → 3 subagents in parallel; calendar × 3 → another 3. Granola is one MCP call (single-shot).

### 2.1 — Mine email per account

For each account in the inventory:

```bash
ACCT="$1"
DAYS="${DAYS:-90}"
OUT=~/{{vaultDir}}/Memory/Daily/_lookback/_phase2_email_${ACCT//@/_at_}.json

# Search the time window — exclude promotions/spam by default
# Note: gog gmail search returns thread metadata; for full participant analysis we want messages.search (per-message granularity)
gog gmail messages search "after:${DAYS}d -category:promotions -category:updates -in:spam -in:trash" \
  --account "$ACCT" \
  --max 5000 \
  --json \
  > "$OUT" 2> "${OUT}.err"

# Sanity-check the response
RESPCOUNT=$(jq 'length' "$OUT" 2>/dev/null || echo 0)
echo "$ACCT: $RESPCOUNT messages mined"
```

**Per-message field harvest.** The output JSON should include, per message:

| Field | Source | Use |
|---|---|---|
| `id` | gog | dedupe |
| `threadId` | gog | thread clustering (Phase 4) |
| `from` | gog headers | candidate-person frequency (Phase 3) |
| `to[]`, `cc[]`, `bcc[]` | gog headers | participant graph |
| `subject` | gog | thread topic + theme mining |
| `date` | gog | last-interaction date |
| `snippet` | gog | LLM theme extraction sample |
| `labelIds[]` | gog | category bucketing |
| `internalDate` | gog | sort key |

If `gog gmail messages search` returns < 10 messages for a healthy-looking account (paid Gmail user, 90d window), something's wrong — surface a warning and ask {{firstName}} to verify the account is in active use.

**Pagination.** gog returns up to `--max` per call. For accounts with > 5000 messages in the window, paginate via `--page <pageToken>` until exhausted. Cap at 20000 messages per account total — beyond that, the LLM extraction cost gets prohibitive and the marginal information is low.

**Rate-limit handling.** Gmail API quota is generous but real (~1B quota units/day). If gog returns `HTTP 429`, sleep 60s and retry once; if it fails again, halt the account's mining and continue with others. Surface the partial in the final report.

### 2.2 — Mine calendar per account

```bash
ACCT="$1"
DAYS="${DAYS:-90}"
OUT=~/{{vaultDir}}/Memory/Daily/_lookback/_phase2_calendar_${ACCT//@/_at_}.json

START=$(date -v-${DAYS}d +%Y-%m-%d)  # macOS BSD date
# Or for GNU date: START=$(date -d "${DAYS} days ago" +%Y-%m-%d)
END=$(date +%Y-%m-%d)

gog calendar events \
  --account "$ACCT" \
  --after "$START" \
  --before "$END" \
  --max 2000 \
  --json \
  > "$OUT" 2> "${OUT}.err"

EVTCOUNT=$(jq 'length' "$OUT" 2>/dev/null || echo 0)
echo "$ACCT: $EVTCOUNT calendar events mined"
```

**Per-event field harvest.** Per event:

| Field | Source | Use |
|---|---|---|
| `id` | gog | dedupe |
| `summary` | gog | event topic |
| `start.dateTime`, `end.dateTime` | gog | duration, time-of-day patterns |
| `attendees[].email` | gog | candidate-person frequency |
| `attendees[].responseStatus` | gog | accepted vs declined (no-shows skew weight down) |
| `organizer.email` | gog | host frequency |
| `location` | gog | physical/virtual venue patterns |

**De-duplication note.** Recurring meetings show up as N event instances per recurrence. For frequency-counting, treat each instance as a separate interaction (you DO meet weekly; that's the signal). For "last interaction date", take the most recent instance.

### 2.3 — Mine Granola meetings

If PC-5 reported Granola MCP available:

```
# pseudo — runtime calls the MCP tool:
mcp.call("mcp__claude_ai_Granola__list_meetings", {
  "after": ISO_START_DATE,
  "before": ISO_END_DATE,
  "limit": 200
})
  → list of meeting metadata

# For each meeting, fetch the transcript (only the ones in window):
mcp.call("mcp__claude_ai_Granola__get_meeting_transcript", {
  "meeting_id": <id>
})
  → transcript text + speaker labels
```

**Per-meeting field harvest.** Save to `_phase2_meetings.json`:

| Field | Source | Use |
|---|---|---|
| `id` | Granola | dedupe, deeplink |
| `title` | Granola | topic |
| `start_time` | Granola | timeline alignment |
| `attendees[]` | Granola | candidate-person frequency (cross-checked against email/calendar) |
| `transcript_excerpt` | Granola, 2000-char truncation | theme mining (Phase 5) |
| `speakers_detected` | Granola | speaker attribution (note: known to be fuzzy — see [feedback memory: Granola speaker attribution]) |

**Caveat.** Granola transcripts mis-attribute speakers (per the feedback memory `feedback_granola_speaker_attribution.md`). Don't write speaker-specific quotes into proposals from Granola without flagging them as unverified.

**Skip if `--no-meetings` is set** OR PC-5 reported absent. Just write `_phase2_meetings.json: []` and move on.

### 2.4 — Phase 2 done-when

- One JSON file per `(surface × account)` pair under `_lookback/_phase2_*`.
- Aggregate counts logged to console: total emails, total events, total meetings.
- Per-surface error logs in `_phase2_*.err` (don't halt — partial data is recoverable).
- If ANY account returned zero data across all three surfaces, surface a warning: that account may not actually be in use, or auth might be quietly expired.

---

## Phase 3 — Mine candidate people

**Inputs:** Phase 1 + Phase 2 JSON dumps.
**Outputs:** `~/{{vaultDir}}/Memory/Daily/_lookback/_phase3_people.json` — ranked candidate list with evidence.
**Parallelism:** Single-pass aggregation; the heavy lifting is jq + sorting, not LLM. One process.

### 3.1 — Build the participant graph

For each email in `_phase2_email_*.json`:

```bash
# Pseudo-jq — actual implementation may need a small Python or Node script
jq -s '
  flatten
  | map(
      [.from] + (.to // []) + (.cc // []) + (.bcc // [])
      | map(select(. != null and . != ""))
      | .[]
      | { addr: ., subject: $subject, date: $date, source_id: $id, surface: "email" }
    )
  | flatten
' _phase2_email_*.json
```

Output: a flat list of `(addr, subject, date, source_id, surface)` rows — one row per (message × participant). Same shape from calendar (`(addr, event_summary, date, event_id, surface: "calendar")`) and meetings (`(addr, meeting_title, date, meeting_id, surface: "meeting")`).

### 3.2 — Aggregate per-address

```bash
# Group by address, compute aggregates
jq -s '
  group_by(.addr)
  | map({
      addr: .[0].addr,
      frequency_email: ([.[] | select(.surface == "email")] | length),
      frequency_calendar: ([.[] | select(.surface == "calendar")] | length),
      frequency_meeting: ([.[] | select(.surface == "meeting")] | length),
      total_frequency: length,
      last_interaction_date: ([.[] | .date] | max),
      first_interaction_date: ([.[] | .date] | min),
      sample_subjects: ([.[] | .subject] | unique | .[0:5]),
      source_evidence_ids: ([.[] | .source_id] | .[0:10])
    })
  | sort_by(-.total_frequency)
' all_participants.json > _phase3_people.json
```

### 3.3 — Cross-reference with VCF / pre-seed contacts

For each candidate address, look up the display_name in `_phase1_seed.json` § contacts. If found, attach `display_name` and `org` from the VCF. If not, try to extract a display_name from email headers (the `from` field often contains `"Name <email@host>"`).

```bash
# If display_name from VCF or header inference, attach
# Output: each candidate has {addr, display_name?, frequency_email, frequency_calendar, frequency_meeting, total_frequency, last_interaction_date, first_interaction_date, sample_subjects[], source_evidence_ids[], inferred_org?}
```

### 3.4 — Apply candidate threshold

Filter to `total_frequency >= --candidate-threshold` (default 3). Anyone below gets dropped from the candidates list, but is preserved in `_phase3_people_below_threshold.json` for {{firstName}} to opt-in later if needed.

### 3.5 — Filter automated senders

Apply the same noreply-pattern filter from extraction's Sem-2 eval:

| Pattern | Action |
|---|---|
| `^(noreply|no-reply|donotreply|notifications?)\b` | Drop |
| `^(team|support|admin|info|help|contact|hello|hi)\b` followed by domain | Drop |
| `\b(automated|automation|bot|alerts?)\b` in addr | Drop |
| `addr` length > 64 chars | Drop (likely list-mail blob) |

Surface counts: "Filtered N noreply / automated addresses from candidates."

### 3.6 — Phase 3 done-when

- `_phase3_people.json` ranked list with `total_frequency >= threshold` candidates.
- `_phase3_people_below_threshold.json` for the long tail.
- Console summary: "N candidate people, M dropped below threshold, K filtered as automated."
- Top-30 (or `--top-people N`) preview rendered to console for {{firstName}} to glance at.

---

## Phase 4 — Mine candidate threads

**Inputs:** `_phase2_email_*.json`.
**Outputs:** `~/{{vaultDir}}/Memory/Daily/_lookback/_phase4_threads.json` — ranked thread clusters.
**Parallelism:** Single-pass jq aggregation.

### 4.1 — Group by Gmail thread ID

```bash
jq -s '
  flatten
  | group_by(.threadId)
  | map({
      threadId: .[0].threadId,
      message_count: length,
      span_days: ((. | max_by(.internalDate) | .internalDate | tonumber) - (. | min_by(.internalDate) | .internalDate | tonumber)) / (86400 * 1000),
      first_subject: (sort_by(.internalDate) | .[0].subject),
      latest_subject: (sort_by(-(.internalDate | tonumber)) | .[0].subject),
      participants: ([.[] | [.from] + (.to // []) + (.cc // [])] | flatten | unique),
      participant_count: ([.[] | [.from] + (.to // []) + (.cc // [])] | flatten | unique | length),
      latest_date: ([.[] | .date] | max),
      account: .[0].account
    })
  | sort_by(-.message_count)
' _phase2_email_*.json > _phase4_threads.json
```

### 4.2 — Filter to "load-bearing" threads

A thread is a candidate IF:

- `message_count >= 3` AND `participant_count >= 2`, OR
- `message_count >= 2` AND `span_days >= 14` (long-running back-and-forth even if short), OR
- `message_count == 1` BUT `participant_count >= 5` (broadcast threads matter sometimes)

Drop everything else from the candidates list (preserve in `_phase4_threads_below_threshold.json`).

### 4.3 — Subject-prefix clustering (cross-thread)

Some users reply with new subjects (Gmail starts a new thread when subject changes — bug, feature, debate). Cluster by stripped-subject (`Re:`, `Fwd:` removed, lowercased):

```bash
jq '
  group_by(.first_subject | sub("^(Re|Fwd|RE|FWD):\\s*"; "") | ascii_downcase)
  | map(... aggregate the cluster ...)
' _phase4_threads.json > _phase4_thread_clusters.json
```

Each cluster has the same shape as a thread but spans potentially-multiple Gmail threadIds.

### 4.4 — Topic classification (LLM-light)

For the top 30 thread clusters by `message_count`, pass subjects to a small LLM call:

```bash
# Sample input — just subjects:
echo '[
  {"cluster_id": "abc", "subject": "Carrier RFP response", "message_count": 47},
  {"cluster_id": "def", "subject": "Mom — flight to Hawaii", "message_count": 12},
  ...
]' | claude -p "Read these subjects. For each, output {cluster_id, inferred_domain_class: one of [work, family, personal, school, finance, health, side-project, other], confidence: 0-1}. JSON array."
```

Output: each cluster gets an `inferred_domain_class` and confidence score.

**Skip this step if `--skip-llm-extraction` is set** — clusters get `inferred_domain_class: null`.

### 4.5 — Phase 4 done-when

- `_phase4_threads.json` and `_phase4_thread_clusters.json` written.
- Top-12 (or `--top-threads N`) preview rendered.
- Each top-12 has at least: `latest_subject`, `message_count`, `span_days`, `participants[0..3]`, `latest_date`, `inferred_domain_class?`.

---

## Phase 5 — Mine candidate themes (the LLM-heavy phase)

**Inputs:** `_phase2_email_*.json`, `_phase2_meetings.json`.
**Outputs:** `~/{{vaultDir}}/Memory/Daily/_lookback/_phase5_themes.json` — 5–10 inferred recurring topics with evidence and inferred domain class.
**Parallelism:** Single LLM call, one sampling pass. Skipped entirely if `--skip-llm-extraction`.

### 5.1 — Stratified sampling

Build a representative 50-message sample (or `--sample-size N`):

- 25 from `from:me` (sent — voice + outbound topics)
- 25 from `to:me` (received — inbound topics, weighted toward top-frequency senders from Phase 3)

```bash
# pseudo
SENT=$(jq '[.[] | select(.from == "{{me}}")] | sort_by(.internalDate) | .[-25:]' _phase2_email_*.json)
RECEIVED=$(jq '[.[] | select(.to | contains("{{me}}"))] | sort_by(.internalDate) | .[-25:]' _phase2_email_*.json)
SAMPLE=$(jq -s '. | flatten' <(echo "$SENT") <(echo "$RECEIVED"))
```

Plus all Granola meeting titles + top 10 calendar event summaries → ~75 documents total.

### 5.2 — LLM theme-extraction prompt

Send the sample to claude CLI with a tightly-scoped prompt:

```bash
echo "$SAMPLE" | claude -p '
You will read a sample of {{firstName}}'"'"'s recent emails, calendar events, and meeting titles.

Identify 5 to 10 recurring themes that span MULTIPLE messages — not one-offs. A theme is "recurring" if at least 3 messages or events touch it.

For each theme, output JSON:
{
  "theme_slug": "kebab-case-id",
  "name": "Plain English name (1-5 words)",
  "evidence_count": <int — how many messages mention this theme>,
  "sample_subjects": [<top 3 subjects>],
  "inferred_domain_class": <one of: work, family, personal, school, finance, health, side-project, civic, other>,
  "confidence": <0.0 to 1.0>,
  "rationale": "<one sentence — why I called this a theme>"
}

Return ONLY a JSON array. No prose preamble. No markdown fence.

Hard rules:
1. Themes must be SPECIFIC. "Email" or "Work" is not a theme. "Carrier RFP response" or "Foundry portal launch" or "Mom and Dad'"'"'s Hawaii trip" is.
2. Order by evidence_count descending.
3. If you can'"'"'t find 5 distinct recurring themes, return only what you found. Don'"'"'t pad.
4. inferred_domain_class is your best guess — confidence < 0.5 is fine, just be honest.
' > _phase5_themes.json
```

### 5.3 — Validate the LLM output

```bash
jq 'length' _phase5_themes.json  # Expect 5-10
jq '.[] | select(.evidence_count == null or .name == null or .theme_slug == null)' _phase5_themes.json  # Should be empty
```

If the LLM returned malformed JSON or too few themes, retry once with a clarifying prompt: "Your previous output was malformed. Please try again, returning ONLY a JSON array of theme objects."

If retry also fails, surface a warning: "Theme mining produced low-confidence output. Falling back to subject-cluster themes from Phase 4." Replace `_phase5_themes.json` with a derivation from `_phase4_thread_clusters.json` (top-N clusters mapped to themes).

### 5.4 — Cross-reference with `_phase4_thread_clusters.json`

Each theme should "anchor" to one or more thread clusters (by participant overlap, subject overlap, or LLM-asserted match). Add `anchor_cluster_ids[]` to each theme. This makes the proposal interactive: {{firstName}} clicks a theme, sees the underlying threads.

### 5.5 — Phase 5 done-when

- `_phase5_themes.json` exists with ≥ 3 themes (or fewer if data is genuinely sparse, with a recorded reason).
- Each theme has `evidence_count >= 3` AND `confidence >= 0` AND `anchor_cluster_ids` (possibly empty if cross-ref didn't land).
- Top-8 (or `--top-themes N`) preview rendered.

---

## Phase 6 — Voice samples

**Inputs:** `_phase2_email_*.json` filtered to `from:{{me}}`, plus `_phase1_voice_drafts.txt` if Phase 1 inventoried any.
**Outputs:** `~/{{vaultDir}}/Memory/Daily/_lookback/voice-samples.md` — 10-20 (or `--voice-samples N`) samples of {{firstName}}'s sent emails for voice anchoring.
**Parallelism:** Single-pass selection.

### 6.1 — Filter to sent emails by {{firstName}}

```bash
jq -s '
  flatten
  | map(select(.from | contains("{{me}}")))
  | sort_by(-(.internalDate | tonumber))
' _phase2_email_*.json > _sent.json
```

### 6.2 — Stratified sample selection

Don't just take the most recent 15 — diversify to surface voice range:

| Strata | Count |
|---|---|
| Recent personal correspondence (to known family/friend addresses from Phase 3) | 3 |
| Recent work correspondence (to top-3 frequency work contacts) | 5 |
| Reply emails (longer, more conversational) | 4 |
| New emails (cold opens, voice from scratch) | 3 |

If any stratum has fewer than its quota, redistribute to the next-highest-quota stratum.

### 6.3 — Body fetch (full text, not snippet)

Snippets from `gog gmail messages search` are truncated. For voice samples we need full bodies:

```bash
for MSG_ID in "${SAMPLE_IDS[@]}"; do
  gog gmail get "$MSG_ID" --account "$ACCT" --format full --json
done
```

Truncate at 2000 chars per body for the voice-samples.md file. {{firstName}}'s long emails get a `[truncated]` marker.

### 6.4 — Render voice-samples.md

```markdown
---
title: "Voice samples — {{firstName}}"
type: voice-anchoring
created: {{today}}
updated: {{today}}
tags: [voice, samples, lookback, {{slug}}]
sources: [{{wikilinksToSourceMessages}}]
---

# Voice samples — {{firstName}}

> 15 sent-email samples from {{firstName}}'s last {{days}} days, selected to span personal / work / replies / new-cold. Used by `Skills/draft-email/SKILL.md` as voice ground.

## Sample 1 — Personal, to family friend
**To:** [redacted]
**Subject:** Re: dinner Saturday
**Date:** {{date}}

> Yeah let's do it — 7:30 works. Bringing wine. See you then.

---

## Sample 2 — Work reply, to client
**To:** [redacted]
**Subject:** Re: contract draft v3
**Date:** {{date}}

> Looked at v3. Two notes:
>
> 1. Section 4.2 still has the old SLA — should be 99.5%, not 99.9%.
> 2. The change-of-control clause needs the carve-out we discussed.
>
> Otherwise this looks ready. Want me to send a redline?

---

[... 13 more samples ...]
```

**Privacy note in the file header:** "Recipient names redacted in this file. The full message data is stored in `_phase2_email_*.json` under `_lookback/`. Don't commit this file to a public repo."

### 6.5 — Phase 6 done-when

- `voice-samples.md` exists with N samples (default 15, configurable via `--voice-samples`).
- Each sample has at least: subject, date, body excerpt, stratum label.
- Recipient identities redacted by default.

---

## Phase 7 — Render proposal.md (the human-readable headline)

**Inputs:** All Phase 1–6 outputs.
**Outputs:** `~/{{vaultDir}}/Memory/Daily/_lookback/proposal.md` — the seminar wow-moment artifact.
**Parallelism:** Single rendering pass.

### 7.1 — Proposal structure

```markdown
---
title: "Lookback proposal — {{firstName}} — {{today}}"
type: lookback-proposal
created: {{today}}
updated: {{today}}
tags: [lookback, proposal, discovery, {{slug}}]
window_days: {{days}}
emails_mined: {{N_emails}}
events_mined: {{N_events}}
meetings_mined: {{N_meetings}}
---

# Lookback proposal — {{firstName}}

> {{agentName}} mined {{N_emails}} emails, {{N_events}} calendar events, and {{N_meetings}} meetings from the last {{days}} days across {{N_accounts}} accounts. Below is what {{agentName}} found. **Read it. Correct it. The accepted parts seed the vault on the next step.**

## TL;DR — what to confirm

- {{topPeopleCount}} candidate people (top {{N}} below)
- {{topThreadsCount}} candidate recurring threads
- {{topThemesCount}} candidate themes / domains
- {{voiceSamplesCount}} sent emails saved for voice anchoring

If any section is off, reply to {{agentName}} with corrections; otherwise type "looks good" and {{agentName}} will run extract on the accepted candidates.

---

## Candidate people (top {{N}})

> Ranked by total interactions (email + calendar + meeting) over the last {{days}} days. Threshold: ≥ {{threshold}} interactions to make this list.

| # | Name (or address if unnamed) | Interactions | Last seen | Sample subjects | Confidence |
|---|---|---|---|---|---|
| 1 | **{{display_name1}}** ({{addr1}}) | {{freq1}} (✉ {{e}}, 📅 {{c}}, 🎙 {{m}}) | {{last_seen1}} | {{sample_subj_1a}} ; {{sample_subj_1b}} | {{conf1}} |
| 2 | **{{display_name2}}** ({{addr2}}) | {{freq2}} | {{last_seen2}} | ... | {{conf2}} |
| ... | | | | | |

> **{{agentName}}'s read:** {{firstName}} has {{N_high_freq}} people they interact with weekly+, and {{N_med_freq}} they interact with at least monthly. The top-3 are {{topName1}}, {{topName2}}, {{topName3}}.

> **Where {{agentName}} is uncertain** ({{ambiguousCount}} of {{topPeopleCount}}):
> - Row {{n}}: {{addr}} — display name not in VCFs and unclear from headers. **Who is this?**
> - Row {{n}}: high frequency but only via mailing list — likely not a personal contact. **Confirm or drop?**

---

## Candidate threads (top {{N}})

> Recurring conversations spanning multiple messages or weeks.

### 1. {{thread1_subject}} ({{thread1_count}} messages, {{thread1_span_days}}d, {{thread1_participant_count}} people)

- **Latest:** {{thread1_latest_date}}
- **Participants:** {{thread1_participant_short_list}}
- **Inferred domain:** {{thread1_inferred_domain_class}} (confidence {{thread1_conf}})
- **What this looks like:** {{thread1_one_line_summary}}

### 2. {{thread2_subject}} ...

[... 10 more threads ...]

> **{{agentName}}'s read:** {{N_long_running_threads}} of these are long-running (>30 days), suggesting {{interpretation}}.

---

## Candidate themes / domains (top {{N}})

> The recurring topics {{firstName}}'s emails actually argue about. Each theme is anchored to threads + a domain class. **These become the seed for {{firstName}}'s tier-1 domains in CLAUDE.md.**

### 1. {{theme1_name}} ({{theme1_evidence}} mentions)
**Domain class:** {{theme1_domain_class}}  
**Sample subjects:** {{theme1_sample_subjects}}  
**Anchor threads:** {{wikilinks_to_anchor_clusters}}  
**Confidence:** {{theme1_confidence}}  
**{{agentName}}'s rationale:** {{theme1_rationale}}

### 2. ...

[... up to top-8 themes ...]

> **{{agentName}}'s read:** {{firstName}}'s last {{days}} days organize around {{N}} clear domains: {{theme1}}, {{theme2}}, {{theme3}}. Lower-confidence themes ({{lowConfNames}}) might be transient — confirm whether they belong on the tier-1 list or stay as project-level threads.

> **What I'm proposing for `~/{{vaultDir}}/CLAUDE.md` § Vault Structure:**
> ```
> Tier-1 domains:
> - {{theme1_domain_class}}/   ({{theme1_name}})
> - {{theme2_domain_class}}/   ({{theme2_name}})
> - ...
> ```
> {{firstName}} can override this when running extract.

---

## Voice samples ({{N}})

15 sent emails selected for voice anchoring. See [[Memory/Daily/_lookback/voice-samples|voice-samples.md]] for the full file. Sample preview:

- **Personal:** "Yeah let's do it — 7:30 works. Bringing wine. See you then."
- **Work-reply:** "Looked at v3. Two notes: ..."
- **Cold-new:** "Quick intro — I'm {{firstName}}, GSB '27. Wanted to circle on ..."

> **{{agentName}}'s read:** {{firstName}} writes short. Lots of em-dashes. Direct openers ("Yeah", "Looked at", "Quick intro"). Few greetings, few signoffs in casual mode. This anchors `Skills/draft-email/SKILL.md` § voice-ground.

---

## Things I'm flagging for review (confidence < 0.6)

- **{{ambiguousCount}}** candidate people without a display name — surface in chat for {{firstName}} to identify or drop.
- **{{lowConfThemeCount}}** themes with confidence < 0.6 — review whether they're real domains or transient threads.
- **{{lowConfThreadCount}}** threads with ambiguous domain class — review.

---

## Stats

- Window: {{startDate}} to {{endDate}} ({{days}} days)
- Accounts mined: {{accountList}}
- Email mined: {{N_emails}} messages across {{N_threads}} threads
- Calendar mined: {{N_events}} events
- Granola mined: {{N_meetings}} meetings ({{N_meetings_with_transcripts}} with full transcripts)
- Pre-seed: {{N_seeded_contacts}} VCF contacts; {{N_voice_drafts}} voice-draft files; {{N_prior_exports}} prior Claude/Codex exports.
- Phase 5 (LLM theme mining): {{phase5_status}} ({{phase5_token_estimate}})

## Next step

If this proposal looks right, type "looks good" or run:

```
/onboard --apply-lookback ~/{{vaultDir}}/Memory/Daily/_lookback/candidates.json
```

That extracts confirmed candidates into:

- `Memory/People/<slug>.md` — one stub per top-{{topPeopleCount}} candidate person
- `<Domain>/Logs/{{today}}_lookback-seed.md` — one log entry per inferred tier-1 domain
- `~/{{vaultDir}}/CLAUDE.md` § Vault Structure — tier-1 domain list updated
- Voice samples remain at `Memory/Daily/_lookback/voice-samples.md` for `Skills/draft-email/`

If parts are wrong, reply with corrections (e.g., "drop person 12", "rename theme 3 to 'WinGen RFPs'", "merge threads 4 and 7"). {{agentName}} edits `candidates.json` accordingly before extract.

---

Tags: #lookback #discovery-phase-2 #wow-moment #auto-memory
```

### 7.2 — Render principles (load-bearing)

- **Show evidence, not just claims.** Every candidate person has interaction counts. Every theme has evidence count + sample subjects. Every thread has message count + span. {{firstName}} should be able to AUDIT the proposal, not just trust it.
- **Mark uncertainty.** Anything below confidence 0.6 surfaces in the "Things I'm flagging" section. Don't bury low-confidence guesses in the main lists.
- **Use {{agentName}}'s voice.** "**{{agentName}}'s read:** ..." paragraphs frame the data with interpretation. Per the seminar moment — pure data tables are less wow than data + a thoughtful read.
- **Make the next step obvious.** "Type 'looks good' or run X" — reduce friction on the accept path.

### 7.3 — Phase 7 done-when

- `proposal.md` written.
- All five sections populated (people / threads / themes / voice / flags).
- Stats table accurate (counts match Phase 1–6 outputs).
- Next-step block points to the right candidates.json path.

---

## Phase 8 — Write structured candidates.json + console summary

**Inputs:** All prior phases.
**Outputs:** `~/{{vaultDir}}/Memory/Daily/_lookback/candidates.json` — the structured artifact downstream prompts and the portal UI consume.
**Parallelism:** Single write.

### 8.1 — Schema

```json
{
  "version": "1.0",
  "generated_at": "<ISO-8601>",
  "user_slug": "{{slug}}",
  "window_days": <int>,
  "window_start": "<YYYY-MM-DD>",
  "window_end": "<YYYY-MM-DD>",
  "accounts_mined": ["<addr1>", "<addr2>", ...],
  "stats": {
    "emails_mined": <int>,
    "events_mined": <int>,
    "meetings_mined": <int>,
    "seed_contacts": <int>,
    "candidate_people_total": <int>,
    "candidate_threads_total": <int>,
    "candidate_themes_total": <int>,
    "voice_samples_count": <int>
  },
  "people": [
    {
      "addr": "<email>",
      "display_name": "<string or null>",
      "frequency_email": <int>,
      "frequency_calendar": <int>,
      "frequency_meeting": <int>,
      "total_frequency": <int>,
      "first_interaction_date": "<ISO date>",
      "last_interaction_date": "<ISO date>",
      "sample_subjects": ["...", "..."],
      "source_evidence_ids": ["...", "..."],
      "inferred_org": "<string or null>",
      "from_vcf": <bool>,
      "confidence": <0.0-1.0>
    },
    ...
  ],
  "threads": [
    {
      "cluster_id": "<id>",
      "thread_ids": ["<gmail-thread-id>", ...],
      "first_subject": "<string>",
      "latest_subject": "<string>",
      "message_count": <int>,
      "span_days": <int>,
      "participant_count": <int>,
      "participants": ["<addr>", ...],
      "latest_date": "<ISO date>",
      "inferred_domain_class": "<string or null>",
      "confidence": <0.0-1.0>,
      "anchor_account": "<addr>"
    },
    ...
  ],
  "themes": [
    {
      "theme_slug": "<kebab-id>",
      "name": "<string>",
      "evidence_count": <int>,
      "sample_subjects": ["...", "..."],
      "anchor_cluster_ids": ["...", "..."],
      "inferred_domain_class": "<string>",
      "confidence": <0.0-1.0>,
      "rationale": "<string>"
    },
    ...
  ],
  "voice_samples_path": "Memory/Daily/_lookback/voice-samples.md",
  "voice_samples_count": <int>,
  "ambiguous_flags": [
    {"category": "person", "ref": "<addr>", "reason": "no display_name", "row": <int>},
    {"category": "theme", "ref": "<slug>", "reason": "confidence < 0.6", "row": <int>},
    ...
  ]
}
```

### 8.2 — Validate JSON parses

```bash
jq '.' ~/{{vaultDir}}/Memory/Daily/_lookback/candidates.json > /dev/null \
  && echo "candidates.json valid" \
  || echo "candidates.json malformed — re-render"
```

### 8.3 — Print the console summary

After all files are written, print this single block to chat:

```
✓ Lookback complete.

  Mined: {{emails_mined}} emails, {{events_mined}} calendar events, {{meetings_mined}} meetings.
  Found:
    {{candidate_people}} candidate people
    {{candidate_threads}} candidate threads
    {{candidate_themes}} candidate themes
    {{voice_samples}} voice samples

  Window: {{window_days}} days ({{window_start}} → {{window_end}})
  Accounts: {{accounts_csv}}
  Wall-clock: {{duration_seconds}}s

  Review the proposal at:
    ~/{{vaultDir}}/Memory/Daily/_lookback/proposal.md

  Next step: read it, then type "looks good" or run /onboard --apply-lookback.
```

### 8.4 — Phase 8 done-when

- `candidates.json` exists, parses with `jq`, has all top-level keys populated.
- Console summary printed.
- All Phase 1–7 intermediate `_phaseN_*.json` files preserved (they're audit trail; don't delete).

---

# EVALS

> Per [[Foundry/Templates/library-standard|Library Standard]] § The Prompt Contract § EVALS, this prompt declares ≥3 evals across structural / semantic / behavioral tiers, each with a numerical threshold per the drift-dashboard vision (`r_promptaudit`). Evals run after the work phases and produce a pass/fail summary. Failures print the exact thing that failed and how to fix it — never just "FAIL".
>
> Lookback's eval philosophy: **the proposal must be auditable, defensible, and useful.** Auditable = every claim has evidence in the JSON. Defensible = no automated/noreply addresses surfacing as candidate people. Useful = {{firstName}} can read it in 5 minutes and confirm or correct without going back to gog.

## Structural evals (deterministic, count-based)

### S-1 — All output files exist with valid format

**Check:** the three output files exist and parse correctly:

```bash
test -f ~/{{vaultDir}}/Memory/Daily/_lookback/proposal.md       && echo "S-1a OK" || echo "S-1a FAIL"
test -f ~/{{vaultDir}}/Memory/Daily/_lookback/candidates.json   && echo "S-1b OK" || echo "S-1b FAIL"
test -f ~/{{vaultDir}}/Memory/Daily/_lookback/voice-samples.md  && echo "S-1c OK" || echo "S-1c FAIL"

# JSON parse-check
jq '.' ~/{{vaultDir}}/Memory/Daily/_lookback/candidates.json >/dev/null 2>&1 && echo "S-1d OK" || echo "S-1d FAIL: candidates.json malformed"

# Required top-level keys in candidates.json
jq -e '.people and .threads and .themes and .stats and .accounts_mined' ~/{{vaultDir}}/Memory/Daily/_lookback/candidates.json >/dev/null 2>&1 \
  && echo "S-1e OK" \
  || echo "S-1e FAIL: candidates.json missing required keys"
```

**Threshold:** 100%. Any FAIL halts the run and surfaces which file is missing or malformed.
**Drift signal:** any S-1 failure surfaces in the drift dashboard as `output_artifact_missing`. Must always be 0.

### S-2 — Candidate counts above floor for an active user

**Check:** for any user with > 100 emails mined in the window, candidate counts must be non-trivial:

```bash
EMAILS=$(jq '.stats.emails_mined' candidates.json)
PEOPLE=$(jq '.people | length' candidates.json)
THREADS=$(jq '.threads | length' candidates.json)
THEMES=$(jq '.themes | length' candidates.json)

if [ "$EMAILS" -gt 100 ]; then
  [ "$PEOPLE" -ge 5 ] || echo "S-2a FAIL: $EMAILS emails but only $PEOPLE people surfaced — candidate-people pipeline likely broken"
  [ "$THREADS" -ge 3 ] || echo "S-2b FAIL: $EMAILS emails but only $THREADS threads — thread clustering pipeline likely broken"
  [ "$THEMES" -ge 3 ] || echo "S-2c WARN: $EMAILS emails but only $THEMES themes — LLM extraction may have under-performed"
fi
```

**Threshold:**

- `EMAILS > 100 AND people >= 5` → PASS.
- `EMAILS > 100 AND people < 5` → FAIL. Pipeline regression — the people aggregator dropped data somewhere.
- `EMAILS <= 100` → SKIP (sparse-data user; not enough signal to evaluate).

**Drift signal:** `candidates_per_email` ratio. Sudden drops over time = pipeline regression.

### S-3 — All `total_frequency` values match the per-surface sum

**Check:** for each candidate person, `total_frequency == frequency_email + frequency_calendar + frequency_meeting`:

```bash
jq '.people[] | select(.total_frequency != (.frequency_email + .frequency_calendar + .frequency_meeting)) | .addr' candidates.json
# Should output empty
```

**Threshold:** 100% match. Any mismatch is a Phase 3 aggregation bug.
**Drift signal:** `frequency_arithmetic_error` count. Should always be 0.

### S-4 — `proposal.md` size within sane bounds

**Check:** the proposal is comprehensive enough to be useful but not so bloated it's unreadable:

```bash
SIZE=$(wc -c < ~/{{vaultDir}}/Memory/Daily/_lookback/proposal.md)
LINES=$(wc -l < ~/{{vaultDir}}/Memory/Daily/_lookback/proposal.md)
[ "$SIZE" -ge 5000 ] || echo "S-4a WARN: proposal.md is < 5KB — likely too sparse to be useful"
[ "$SIZE" -le 200000 ] || echo "S-4b WARN: proposal.md is > 200KB — likely too dense to read"
[ "$LINES" -ge 100 ] && [ "$LINES" -le 2000 ] && echo "S-4 OK" || echo "S-4 WARN: $LINES lines"
```

**Threshold:** WARN-only (informational). The size band is a heuristic for readability; bias toward surfacing if proposal is unusually small or large but don't halt.

### S-5 — Drift-dashboard observation row appended

**Check:** `~/{{vaultDir}}/{{agentName}}/state/prompt_observations.jsonl` has a fresh row tagged `prompt_id: lookback` with today's date:

```bash
tail -1 ~/{{vaultDir}}/{{agentName}}/state/prompt_observations.jsonl 2>/dev/null \
  | jq -e '.prompt_id == "lookback" and (.run_date | startswith("'"$(date +%Y-%m-%d)"'"))' >/dev/null \
  && echo "S-5 OK" || echo "S-5 FAIL: drift observation row not found"
```

**Threshold:** binary — exists or not. If missing, AFTER YOU FINISH § A2 didn't fire; re-run that step.

## Semantic evals

### Sem-1 — No automated/noreply addresses in the candidate people list

**Check:** apply the noreply-pattern filter (Phase 3.5) as a post-write audit:

```bash
jq -r '.people[].addr' candidates.json | while read addr; do
  echo "$addr" | grep -qiE '^(noreply|no-reply|donotreply|notifications?|automated|bot|alerts?)' \
    && echo "Sem-1 FAIL: $addr is an automated address but landed in candidates"
done
```

**Threshold:** 0 violations. Any noreply / automated address in the candidates is a hard FAIL — the People graph must not become a no-reply junkyard.
**Drift signal:** `automated_addr_leak_count` per run. Persistent >0 = filter regression in Phase 3.5.

### Sem-2 — Theme classifications align with anchor thread participants

**Check:** for each theme, verify its `inferred_domain_class` is plausible given the participants on its anchor threads. E.g., a theme classified `family` whose anchor threads have all participants on `*.com` work domains is suspicious.

This is a soft heuristic — pass criterion is "≥ 80% of themes have at least one anchor thread whose participant majority matches the inferred domain class":

```bash
# pseudo — implementation needs lookup from candidates.threads[].participants
# For each theme:
#   For its anchor_cluster_ids, fetch the participant lists
#   Compute participant_class_majority via simple heuristic:
#     - >50% addresses ending in .edu → school
#     - >50% addresses on a single .com → work
#     - >50% addresses on @gmail.com / @yahoo / @icloud → personal
#   If theme.inferred_domain_class matches majority, eval passes for that theme
```

**Threshold:**

- ≥ 80% match → PASS.
- 60–79% → WARN (drift signal: `theme_anchor_misalignment`).
- < 60% → FAIL. The LLM theme classification is decoupled from evidence — re-run Phase 5 with a stronger anchor-aware prompt.

### Sem-3 — Voice samples actually contain {{firstName}}'s sent text

**Check:** voice-samples.md must reference messages where `from` matches {{firstName}}'s identity (not received emails accidentally tagged as voice samples):

```bash
# For each "Sample N" block in voice-samples.md, verify the source message's "from" is {{firstName}}'s address
# Implementation: extract source IDs from the file, look them up in _phase2_email_*.json, verify from
```

**Threshold:** 100%. Any received email landing in voice-samples.md poisons the voice ground for downstream draft skills.
**Failure mode:** Phase 6.1 filter bug. Re-run Phase 6.

### Sem-4 — Proposal sections cross-reference correctly

**Check:** the proposal.md "Anchor threads" links in themes section actually resolve to thread cluster IDs in candidates.json:

```bash
# Extract cluster_id references from proposal.md (look for theme blocks)
# For each, verify it appears in candidates.json .threads[].cluster_id or .threads[].thread_ids
```

**Threshold:** 100% resolution. Any dangling cluster ID is a render bug in Phase 7.

### Sem-5 — Display names from VCF cross-reference correctly

**Check:** for candidates with `from_vcf: true`, verify the display_name actually came from a VCF in `_phase1_seed.json` (not LLM-hallucinated):

```bash
# For each .people[] where from_vcf: true:
#   Verify .display_name appears in _phase1_seed.json contacts
```

**Threshold:** 100% match. Hallucinated display names = serious data integrity issue.

## Behavioral evals (confirmation-gated)

### B-1 — User confirmed top-5 candidate people are real

**Check:** after the proposal is rendered, {{firstName}} is asked to scan the top-5 candidate people and confirm they're real / not noise. Surface in chat:

```
Quick check on top-5 candidate people:
1. {{name1}} ({{addr1}}) — {{freq1}} interactions
2. {{name2}} ({{addr2}}) — {{freq2}} interactions
3. {{name3}} ({{addr3}}) — {{freq3}} interactions
4. {{name4}} ({{addr4}}) — {{freq4}} interactions
5. {{name5}} ({{addr5}}) — {{freq5}} interactions

Real people, real relationships? (yes / no / partial — drop which ones)
```

**Threshold:** 100% — gate the run "useful" only on explicit confirmation. Silence does NOT count.

| {{firstName}}'s answer | Eval result | Action |
|---|---|---|
| "yes" / "all real" | PASS | Continue to AFTER YOU FINISH |
| "drop X" | WARN | Edit candidates.json to remove X, log to lessons file |
| "this looks wrong" | FAIL | Halt. Surface what's wrong; offer re-run with stricter `--candidate-threshold`. |

**Drift signal:** correction-rate over time. If {{firstName}} is consistently dropping 2+ of the top-5, the candidate ranking heuristic needs work.

### B-2 — User accepted the proposal OR queued explicit corrections

**Check:** the run doesn't claim "done" until {{firstName}} either:

- types "looks good" / "accept" / approves explicitly, OR
- runs `/onboard --apply-lookback` (which itself signals acceptance), OR
- types corrections that get logged to `_lookback/corrections.md` for the extract pass to apply

**Threshold:** binary — acceptance signal received OR corrections queued. Without one of those two, the proposal is in limbo (which is fine — but the eval reflects that, doesn't claim PASS).

**Failure mode:** the agent silently moved on without confirmation. This is a Library Standard violation; the AFTER YOU FINISH log records the unresolved state.

### B-3 — User confirmed the inferred tier-1 domain list

**Check:** if Phase 5 produced themes that the proposal renders as a tier-1 domain proposal for `~/{{vaultDir}}/CLAUDE.md`, {{firstName}} explicitly confirms before extract acts on them:

```
Proposed tier-1 domains for CLAUDE.md:
  - work/      ({{theme1_name}})
  - school/    ({{theme2_name}})
  - personal/  ({{theme3_name}})
  - {{theme4_class}}/    ({{theme4_name}})

OK to use these as tier-1 domains? Or override?
```

**Threshold:** 100%. Domain structure is one of the most consequential decisions in the vault — never auto-apply without confirmation.

## Eval summary panel

After all 13 evals run, render:

```
EVAL SUITE — Lookback
=====================
Structural   5/5 ✓     (S-1 ✓, S-2 ✓, S-3 ✓, S-4 ⚠ informational, S-5 ✓)
Semantic     5/5 ✓     (Sem-1 ✓, Sem-2 ✓, Sem-3 ✓, Sem-4 ✓, Sem-5 ✓)
Behavioral   3/3 ✓     (B-1 confirmed, B-2 accepted, B-3 confirmed)
=====================
OVERALL      13/13 ✓ — proposal is auditable, defensible, and accepted.
```

Any FAIL or WARN: surface the exact item + remediation; let {{firstName}} decide whether to re-run the failing phase or accept the warning.

---

# DEFINITION OF DONE

The skill is DONE when every box below is `✓`. The orchestrator surfaces this checklist before saying "lookback complete."

```
Pre-checks
[ ] PC-1 Canonical layout green (or vault-deviation block present and parsed)
[ ] PC-2 Vault deviations parsed (or none)
[ ] PC-3 gog installed, correct binary, ≥1 account authenticated
[ ] PC-4 Account inventory resolved (intersection of answers.yaml and gog auth list)
[ ] PC-5 Granola MCP probed (mining mode chosen — full / no-meetings)
[ ] PC-6 Time window arg parsed
[ ] PC-7 Disk space sufficient
[ ] PC-8 claude CLI probed (LLM extraction enabled or skipped)
[ ] PC-9 jq + yq present (or yq fallback acknowledged)

Work phases
[ ] Phase 1: pre-seed read complete (or skipped per PC-1b)
[ ] Phase 2: gog email + calendar + Granola mined
[ ] Phase 3: candidate people aggregated and threshold-filtered
[ ] Phase 4: candidate threads clustered (raw + subject-prefix-stripped)
[ ] Phase 5: themes mined via LLM (or fallback per PC-8)
[ ] Phase 6: voice samples extracted, stratified, redacted
[ ] Phase 7: proposal.md rendered with all five sections
[ ] Phase 8: candidates.json written + console summary printed

Evals
[ ] S-1 All output files exist and valid
[ ] S-2 Candidate counts above floor for active users
[ ] S-3 Frequency arithmetic checks out
[ ] S-4 Proposal.md size within sane bounds (informational)
[ ] S-5 Drift observation row appended
[ ] Sem-1 No automated addresses in candidates
[ ] Sem-2 Themes align with anchor thread participants (≥ 80%)
[ ] Sem-3 Voice samples are actually {{firstName}}'s sent text
[ ] Sem-4 Proposal cross-references resolve in candidates.json
[ ] Sem-5 VCF display names cross-reference correctly
[ ] B-1 User confirmed top-5 candidate people
[ ] B-2 User accepted the proposal OR queued corrections
[ ] B-3 User confirmed the inferred tier-1 domain list (if any)

Capture
[ ] Lookback report written to ~/{{vaultDir}}/{{agentName}}/Logs/lookback/{{today}}.md
[ ] Daily-note Session block appended
[ ] Drift-dashboard observation row written to prompt_observations.jsonl
[ ] One-line close emitted: <emails> mined → <people> candidates / <threads> threads / <themes> themes / <samples> voice samples.
```

If any box is unchecked, the prompt is NOT DONE. Surface which boxes failed and why before declaring lookback complete.

---

# AFTER YOU FINISH

This is the **compounding** step. The next run of lookback — and adjacent prompts (`extract` on the accepted candidates, `spider` on the seeded vault, `health-check: discovery-completeness`) — benefit from what THIS run learned. Skipping this section means the proposal-and-accept loop forgets, drift goes untracked, and the discovery flow doesn't compound across re-runs.

## A1 — Write the lookback report

Append a dated report to `~/{{vaultDir}}/{{agentName}}/Logs/lookback/{{today}}.md` (create the directory if missing — `mkdir -p`):

```markdown
---
title: "Lookback Run — {{today}} {{HH:MM}}"
type: log
created: {{today}}
tags: [log, lookback, discovery, {{agentName}}]
sources: ["Memory/Daily/_lookback/proposal.md", "Memory/Daily/_lookback/candidates.json"]
---

## Lookback Run — {{today}} {{HH:MM}}

**Mode:** {{firstRun|refresh}}
**Window:** {{days}} days ({{startDate}} → {{endDate}})
**Accounts:** {{accountList}}
**Wall-clock:** {{durationMinutes}} min

### Mining results

- Emails mined: {{N_emails}}
- Calendar events mined: {{N_events}}
- Meetings mined: {{N_meetings}}
- Pre-seed contacts loaded: {{N_seeded_contacts}}

### Candidates surfaced

- People: {{candidate_people}} (top {{top_people}} surfaced in proposal)
- Threads: {{candidate_threads}}
- Themes: {{candidate_themes}}
- Voice samples: {{voice_samples}}

### {{firstName}}'s feedback

- Top-5 people confirmation: {{B1_outcome}}
- Proposal accepted: {{B2_outcome}}
- Tier-1 domain confirmation: {{B3_outcome}}
- Corrections logged: {{N_corrections}} (see `_lookback/corrections.md`)

### Eval summary

{{passFailTablePerEval}}

### Drift signals

- `automated_addr_leak_count`: {{Sem1Drift}} (target: 0)
- `theme_anchor_misalignment`: {{Sem2Drift}} (target: < 20%)
- `frequency_arithmetic_error`: {{S3Drift}} (target: 0)
- `candidates_per_email_ratio`: {{S2DriftRatio}}
- `correction_rate_top5`: {{B1CorrectionRate}}

### Notes

{{anythingNoteworthy — first run, deviation block applied, sparse-data user, large theme variance, etc.}}

Tags: #auto-memory #lookback #discovery
```

This file gets picked up by the librarian extraction skill on the next `/handoff` and propagated into Logs/.

## A2 — Append the drift-dashboard observation row

Append a structured observation row to `~/{{vaultDir}}/{{agentName}}/state/prompt_observations.jsonl`. Create the directory and file if absent (`mkdir -p` + `touch`).

```jsonl
{"prompt_id": "lookback", "user_slug": "{{slug}}", "run_date": "<ISO-8601 timestamp>", "tier_scores": {"structural": 0-100, "semantic": 0-100, "behavioral": 0-100}, "drift_score": 0-100, "evals": {"S-1": "pass|fail", "S-2": "pass|fail|skip", "S-3": "pass|fail", "S-4": "pass|warn", "S-5": "pass|fail", "Sem-1": "pass|fail", "Sem-2": "pass|warn|fail", "Sem-3": "pass|fail", "Sem-4": "pass|fail", "Sem-5": "pass|fail", "B-1": "pass|warn|fail", "B-2": "pass|fail", "B-3": "pass|fail|skip"}, "metadata": {"emails_mined": <int>, "calendar_events_mined": <int>, "granolas_mined": <int>, "candidate_people": <int>, "candidate_threads": <int>, "candidate_themes": <int>, "voice_samples": <int>, "lookback_window_days": <int>, "duration_seconds": <int>, "seed_contacts": <int>, "automated_filtered": <int>, "below_threshold_count": <int>, "user_corrections": <int>, "llm_extraction_used": <bool>, "accounts_count": <int>}}
```

**Tier-score computation:**

- `tier_scores.structural` = `100 * (count(S-* pass) / count(S-* total, excluding skip/informational))`
- `tier_scores.semantic` = `100 * (count(Sem-* pass) / count(Sem-* total))` — `warn` counts as `0.5 * pass`
- `tier_scores.behavioral` = `100 * (count(B-* pass) / count(B-* total, excluding skip))`

**Drift-score formula:**

```
drift_score = max(0, 100 - weighted_average(tier_scores))

where weights are:
  structural   = 0.3   (deterministic; should always be near 100)
  semantic     = 0.4   (heuristic; the meaningful drift signal — theme alignment + automated leak)
  behavioral   = 0.3   (the user-confirmation gates — failures rare but consequential)
```

Drift score 0 = clean run. Drift score ≥ 30 = degrading; investigate. Per `r_promptaudit`, the dashboard reads this JSONL and renders trend per `prompt_id` over time.

**Append, never overwrite.** Time-series matters.

## A3 — Daily-note Session block

If today's `~/{{vaultDir}}/Memory/Daily/{{today}}.md` exists, append:

```markdown
## Session: Lookback (Discovery Phase 2) — {{HH:MM}}

- Window: {{days}}d × {{N_accounts}} accounts; {{emails_mined}} emails, {{events_mined}} events, {{meetings_mined}} meetings.
- Surfaced: {{candidate_people}} people, {{candidate_threads}} threads, {{candidate_themes}} themes, {{voice_samples}} voice samples.
- Eval results: structural {{structPct}}%, semantic {{semPct}}%, behavioral {{behPct}}% (drift {{driftScore}}).
- {{firstName}} feedback: {{B1_outcome}} on top-5 people; {{B2_outcome}} on proposal; {{B3_outcome}} on tier-1 domains.
- Proposal: [[Memory/Daily/_lookback/proposal|today's lookback proposal]].
- Run report: [[{{agentName}}/Logs/lookback/{{today}}|{{today}} lookback run]].

Tags: #auto-memory #lookback #discovery
```

Skip this step if today's daily file is itself one of the source / sample inputs (avoid recursive trail).

## A4 — Radar entries (if accept/correct loops are open)

If {{firstName}} flagged corrections or open questions during B-1/B-2/B-3, append to `~/{{vaultDir}}/Radar.md` § Open Loops:

```markdown
- lookback: review {{N}} flagged candidates (proposal {{today}}). ✓ Done when: {{firstName}} runs `/onboard --apply-lookback` or types "drop those".
```

**Hard rule (per the [[Memory/Hippocampus|Hippocampus]] feedback "Never add-remove Radar lines"):** if a similar item already exists in Radar, edit in place. Don't add-remove.

## A5 — Lessons file (if a meta-pattern surfaced)

If during this lookback {{agentName}} noticed a recurring pattern worth remembering across future lookbacks, append to `~/{{vaultDir}}/Memory/Lessons/lookback.md` (create if missing):

```markdown
- {{today}}: <one-paragraph lesson, including the trigger run and the rule>
```

Examples that would qualify:

- "{{firstName}}'s `*.edu` calendar attendees frequently lack VCF entries because the GSB directory dump is from 2025 and the cohort grew. Lookback should fall back to extracting display names from email headers (the `From:` field's quoted-string portion) when VCF lookup fails."
- "Three lookback runs in a row have produced ≥ 5 noreply candidates pre-filter. The Phase 3.5 filter list needs another pattern (specifically: `^reply-` and `^do_not_reply`)."
- "Theme classification confidence is consistently lower for users with < 200 emails in the window. Either lower the default `--days` threshold for sparse users or expand the LLM prompt to handle low-evidence themes more gracefully."
- "The `frequency_meeting` count is consistently 0 for users on Outlook (Granola integration is Google-Calendar-only). Surface this in the proposal so Outlook users don't think their Granola is broken."

Threshold: only write here if the lesson would change how the lookback prompt itself works on the next run. Per-user rules go in their respective preference notes, not here.

## A6 — Pointers to next-step prompts

Surface in the closing chat block what {{firstName}} can run next:

```
What to do with this proposal:

  1. If it looks right → type "looks good" or run:
       /onboard --apply-lookback ~/{{vaultDir}}/Memory/Daily/_lookback/candidates.json
     This calls extract on the accepted candidates and seeds:
       - Memory/People/<slug>.md (one per top-{{topPeopleCount}} candidate)
       - <Domain>/Logs/{{today}}_lookback-seed.md (one per inferred tier-1 domain)
       - CLAUDE.md § Vault Structure (tier-1 domain list)

  2. If parts are wrong → reply with corrections:
       "drop person 12, rename theme 3 to 'X', merge threads 4 and 7"
     {{agentName}} edits candidates.json before extract.

  3. If nothing's right → run:
       /lookback --refresh --days 30 --candidate-threshold 5
     Tighter threshold, shorter window — re-mine and re-propose.

  4. To wire schedule for refresh:
       /loop monthly /lookback --refresh
     Re-mines monthly; surfaces drift in the dashboard.
```

This is the "what next" breadcrumb. Don't leave {{firstName}} guessing what to do with the proposal.

---

# Operating notes for the agent

These are reminders the orchestrator should re-read at session start (especially in fresh-context harnesses where the prompt may not have been internalized through prior conversation).

- **Read-only on every external surface.** gog reads. Granola reads. Filesystem reads on `_seed/`. Lookback never writes to Gmail / Calendar / Granola. Even labels are off-limits in this skill.
- **Never auto-create vault files outside `_lookback/`.** People stubs, domain logs, CLAUDE.md updates are all extract's job. Lookback proposes; extract files. Mixing the two collapses the review-and-confirm loop.
- **Show evidence, never just claims.** Every candidate has interaction counts. Every theme has evidence count + sample subjects. {{firstName}} should be able to AUDIT, not just trust.
- **Mark uncertainty visibly.** Confidence < 0.6 surfaces in the "Things I'm flagging" section. Don't bury low-confidence guesses in main lists.
- **Behavioral evals are non-negotiable.** B-1 (top-5 confirmation), B-2 (acceptance signal), B-3 (tier-1 domain confirmation) are hard contracts. Run silently fails if any is unresolved.
- **No emojis in proposal.md or report files** unless {{firstName}} requests them.
- **Idempotency matters for `--refresh`.** If `_lookback/proposal.md` already exists from a prior run, archive it to `_lookback/_archive/{{prior_date}}_proposal.md` before overwriting. Never silently nuke prior proposals — they're the user's audit trail.
- **Don't surface raw token estimates as a flex.** "Mined 2,500 emails" is fine. "Cost 47k input tokens" is engineering trivia and crosses a tone line.
- **Privacy in voice-samples.md.** Recipient names redacted by default. The full message data stays in `_phase2_email_*.json` (which is also under `_lookback/`, so still local — just not in the user-facing voice-samples file).

---

# How this composes with other library prompts

- **`/onboard` (Phase 2 of discovery-first flow)** — invokes `/lookback` as one of its dispatched steps. The proposal.md becomes the headline artifact in the seminar walkthrough; candidates.json is what `/onboard --apply-lookback` reads to seed the vault.
- **`extract` (Skills/extraction)** — runs after `/lookback` is accepted. Reads candidates.json, creates People stubs, writes domain Logs/ entries, updates CLAUDE.md. Lookback proposes; extract files.
- **`spider`** — runs after extract on the seeded vault. Tightens the new graph, links People stubs to themes' anchor threads, freshens index files. The graph audit closes the loop.
- **`health-check: discovery-completeness`** — periodic check that reads `_lookback/candidates.json`, compares to current vault state, and flags candidates not yet promoted to `Memory/People/` or `<Domain>/Logs/`. Surfaces "5 lookback candidates from 30 days ago haven't been seeded yet — re-run extract or drop them."
- **`/loop monthly /lookback --refresh`** — sets up scheduled re-mining. Each refresh produces a new proposal.md (archiving the prior). Drift dashboard tracks `correction_rate_top5` over months: rising = candidate ranking is degrading; falling = the heuristic is settling on real signal.
- **Drift dashboard (`r_promptaudit`)** — reads `prompt_observations.jsonl` rows tagged `prompt_id: lookback` and renders trends. Key metrics: `automated_addr_leak_count`, `theme_anchor_misalignment`, `correction_rate_top5`, `candidates_per_email_ratio`.
- **Health-check `r_hltchk`** — lookback's evals feed the canonical-arch + discovery health-check. A run with `B-1 = fail` or `Sem-1 > 0` surfaces in the health dashboard.

---

# Cross-links

- [[Foundry/Templates/library-standard|Foundry Library Standard]] — the contract this prompt conforms to
- [[Foundry/Templates/integrations/gmail|Gmail × gog setup]] — Phase 3 dependency (lookback can't mine without gog wired)
- [[Skills/extraction/SKILL|extract]] — downstream consumer of `candidates.json`
- [[Skills/spider/SKILL|spider]] — runs after extract closes the loop
- [[Workbench/foundry-prompt-audit/0-foundry-prompt-audit-index|Foundry Prompt Audit]] — drift-dashboard architecture (`r_promptaudit`)
- [[Workbench/paint/2026-05-06-foundry-evolved-vision/README|Foundry Evolved Vision]] — discovery-first onboarding spec; lookback is Phase 2

---

_Last updated: {{today}} — Initial Library-Standard build. The seminar's headline moment. Mines email + calendar + Granola + pre-seed → proposes people / threads / themes / voice samples. Read-only on every external surface; writes only to `~/{{vaultDir}}/Memory/Daily/_lookback/`. Eight work phases, 13 evals (5 structural / 5 semantic / 3 behavioral), drift-dashboard observation row per run. Composes with `/onboard --apply-lookback` (extract) and `/loop monthly /lookback --refresh` (scheduled drift)._
