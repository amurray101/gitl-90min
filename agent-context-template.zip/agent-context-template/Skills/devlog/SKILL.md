---
name: devlog
description: Append a dated entry to the current project repo's docs/DEVLOG.md — captures context, changes, why, tradeoffs, and open items from a coding session. Repo-local memory for the next session (human or AI). Scaffolds the file if missing. Does NOT touch the vault — use /handoff for that.
title: Devlog
type: skill
created: 2026-04-22
updated: 2026-04-22
tags: [skill, coding, devlog, repo]
trigger: "End of a coding session inside a project repo — invoked via /devlog. Writes to the repo's docs/DEVLOG.md, never the vault."
---

# Devlog

> Append a dated entry to the current repo's `docs/DEVLOG.md`. This is **repo knowledge** — thinking, decisions, tradeoffs from this coding session. Vault stays untouched (that's `/handoff`'s job, for personal/work state).
>
> **Why it's separate from handoff:** coding sessions produce repo-specific context (architectural choices, rejected approaches, open TODOs). That belongs with the code, read by the next Claude Code session opened in the same repo. Not in {{agent_name}}'s brain. If {{agent_name}} ever needs it, he can read the DEVLOG directly.

## When to invoke

- At the end of any coding session that made non-trivial changes (shipped a feature, refactored, debugged a gnarly issue, made an architectural decision).
- Not for trivial edits (typo fix, one-line config change).
- Can also be invoked mid-session to capture a decision that was just made, before context is lost.

## Procedure

### 1. Detect the current repo

- The repo is the current working directory. `git rev-parse --show-toplevel` confirms.
- Expected DEVLOG path: `<repo>/docs/DEVLOG.md`.
- If the repo doesn't have a `docs/` folder, create it.
- If `docs/DEVLOG.md` doesn't exist, scaffold it first using the **DEVLOG header template** below, then proceed.

### 2. Gather context for the entry

Before writing, collect:

- **Today's date** — `YYYY-MM-DD` format.
- **Recent git activity** — `git log --oneline -n 20` for commits since last DEVLOG entry. `git status` and `git diff --stat` for uncommitted work.
- **Recent files modified** — what actually changed this session. Don't just list files; understand what they do.
- **Decisions made** — especially ones that rejected alternatives. These are the highest-value part of the entry.
- **User feedback received** — corrections, clarifications, preference signals {{user_name}} gave mid-session. Capture these so the next session doesn't repeat mistakes.
- **Open items** — what's left undone, what's blocked, what needs human decision.

### 3. Write the entry

Append to `docs/DEVLOG.md` below any existing entries. Newest-first order (insert after the header, before the previous top entry). Use this template:

```markdown
## YYYY-MM-DD — Short, specific title

**Context**: Why this session happened. What triggered the work (user request, bug report, follow-up from prior entry).

**Changes**: What actually shipped. Be concrete — files, routes, schema, tables. Link file paths with line numbers where useful (`src/foo.ts:42`).

**Why**: The reasoning. Product motivation, architectural pressure, correctness concern, performance need. Don't repeat *what* changed — explain *why* this is the right change.

**Tradeoffs considered**: Alternatives that were rejected, and the reason. This is the highest-value section — it prevents the next Claude Code session (or a human) from re-relitigating the same decisions. Even one-liners help.

**AI session notes** *(optional, only when relevant)*: Prompting patterns that worked, corrections {{user_name}} gave, patterns future sessions should repeat or avoid. Skip this section if nothing notable happened at the meta-level.

**Open items**: Unfinished work, blockers, pending decisions, deploys not yet run, tests not yet added.

**Links**: PR URLs, issue numbers, vault file paths (`<your-vault>/...`), related DEVLOG entries from other repos if cross-referenced.
```

### 4. Quality bar

Each entry is its own **Architectural Decision Record** for the session. The two sections that make it worth keeping:

- **Why** — without this, the entry is just a changelog. Changelogs are for users; DEVLOG is for future dev sessions.
- **Tradeoffs considered** — the immutable record of rejected alternatives. Future sessions should be able to skim this and not repeat rejected paths.

If an entry has no **Why** or no **Tradeoffs** because the work was purely mechanical, consider whether the entry should exist at all. Trivial work doesn't earn a DEVLOG line.

### 5. One entry per session, not per commit

- A session can include multiple commits; they become one DEVLOG entry covering the session's arc.
- If a session spans multiple truly independent work threads, consider two entries — but err toward one, with sub-sections if needed.
- Entries are **append-only / immutable** after the session closes (ADR convention). If a decision is overturned later, write a new entry that references and supersedes the old one. Do not retroactively edit past entries.

### 6. Don't commit automatically

- After writing, `git add docs/DEVLOG.md` is fine but **do not `git commit` without explicit user approval**.
- Surface the diff and let {{user_name}} review.

### 7. Output

After writing, print a concise summary:

```
Devlog entry appended: docs/DEVLOG.md
- Title: YYYY-MM-DD — <title>
- Changes: <N files, M tradeoffs captured, K open items>
- Uncommitted: docs/DEVLOG.md (review and commit when ready)
```

---

## DEVLOG header template (used when scaffolding a new DEVLOG.md)

```markdown
# <Repo Name> — Developer Log

> **Purpose**: Chronological record of dev decisions — *what* changed, *why*, *what tradeoffs were considered*, and *what's left open*. Not a changelog. Not release notes. This is a journal of the thinking.
>
> **Who writes here**: Claude Code after every significant session, via the `/devlog` skill. {{user_name}} can annotate. The next Claude Code session opened in this repo reads this file first to pick up context.
>
> **Source of truth**: This file (repo). Mirrored to vault at `<path/to/vault/logs/arc.md>` when the repo has a paired domain log — otherwise repo-only.
>
> **Format per entry**:
> ```
> ## YYYY-MM-DD — Short title
>
> **Context**: Why this session happened.
> **Changes**: What actually shipped (files, tables, routes).
> **Why**: The reasoning — product motivation, architectural pressure, tradeoff chosen.
> **Tradeoffs considered**: Alternatives rejected and why.
> **Open items**: What's unfinished, what to pick up next session.
> **Links**: Related PRs, issues, vault files.
> ```
>
> **Entries are immutable.** If a past decision is overturned, write a new entry that supersedes it and links back. Do not retroactively edit history.

---
```

---

## Why this structure (the AI coding best-practice rationale)

This template is intentionally shaped by three current (2026) patterns for AI-assisted development:

1. **CLAUDE.md handles rules; DEVLOG handles history.** Anthropic's best practices separate *persistent rules* (live in CLAUDE.md, applied every session) from *decision history* (what happened and why). Conflating them bloats CLAUDE.md and loses session-level signal. DEVLOG is the append-only memory Claude Code reads back to understand *why things are the way they are*.

2. **ADR (Architectural Decision Record) conventions.** Each entry is single-focus, append-only, and captures **context + decision + tradeoffs + consequences**. This is the industry standard for documenting "why did we do it this way" and it's the part future readers (human or AI) cannot reconstruct from code alone.

3. **Tight feedback capture.** AI coding sessions generate mid-flight corrections — "no, not that pattern," "use X not Y," "this is actually a Crystal-specific constraint." The `AI session notes` section exists so those corrections don't evaporate when the session ends. This is how the DEVLOG compounds in value over time — the repo gets smarter session by session.

## See Also

- [[Skills/session-handoff/SKILL|Session Handoff]] — `/handoff` — vault-side close-out (Daily, Radar, Brain). Run separately when you want to capture the personal/work-state arc, not the repo arc.
- [[Skills/coding-protocol/SKILL|Coding Protocol]] — development workflow and standards
- Project repos that have a DEVLOG: `raci-staci`, `project-homer`, `wingen-wendy`, `wingen-warren`. Check for `docs/DEVLOG.md`.
