---
name: radar-verify
description: Walk every Radar item, scan recent comms from people tagged on each item across iMessage/WhatsApp/Gmail/Outlook, probe the Done-when criterion, then auto-apply UPDATE/URGENT-BUMP and (in apply mode) auto-clear HIGH-confidence items. Called by /handoff before the Radar rewrite, by the radar-pulse cron throughout the day, or invoked standalone.
title: "Radar Verify"
type: skill
created: 2026-04-27
updated: 2026-05-05
tags: [skill, radar, handoff, verification, cron, self-healing, composio, gog]
trigger: "Called by /handoff before the Radar rewrite, by com.9ton.radar-pulse cron throughout the day, or invoked standalone via /radar-verify [verify|apply]"
---

# Radar Verification

> Walk every Radar item, scan recent communications from people tagged on each item across iMessage / WhatsApp / Stanford Gmail / Swordpoint Outlook, probe the `✓ Done when:` criterion against the combined evidence, then act. In `apply` mode three classes auto-apply: **CLEAR** (HIGH-confidence only) deletes the line, **UPDATE** appends a dated evidence note in-place, **URGENT-BUMP** promotes the line from Active → Urgent. MEDIUM-confidence findings surface for Eitan to review. Designed to run on a 2-hour cron throughout the day so Radar reflects reality in near-real-time without /handoff being the only cleanup gate.

**Routing:** Stanford Gmail / Calendar probes follow [[Skills/connector-routing|connector-routing.md]] — wherever the tables below say `gog gmail search` or `gog calendar events`, run the equivalent Composio call first (`GMAIL_FETCH_EMAILS`, `GOOGLECALENDAR_LIST_EVENTS`) and fall back to gog if the Composio path is unavailable. Same query strings work on both transports. SwordPoint Outlook probes stay on Composio Outlook always.

## Why this exists

Radar items go stale when their work ships but nobody updates the line. The "Done when" line names *where the proof lives* (a sent email, a commit, a vault file, a daily-note mention). This skill turns that pointer into a check, so /handoff stops carrying ghost items forward.

## Inputs

- **Mode** (optional): `verify` (default — present evidence, do not write) or `apply` (auto-apply CLEAR/UPDATE/URGENT-BUMP per the rules in Step 5). Called from /handoff and from the `com.9ton.radar-pulse` cron in `apply` mode.
- **Scope** (optional): comma-separated item IDs to limit verification (e.g., `r_d9srq,r_jnatl`). Default: every Radar item.
- **Window** (optional): how far back to look for evidence. Default: read `last_run` from `9ton/state/radar-verify-cursor.json` (cron mode) or the `updated:` field of `Memory/Hippocampus.md` (handoff mode). Capped at 24h for cron, 7d for handoff. Bootstrap (no cursor) = 6h.

## The `Done when:` schema

Every Radar item should end with a `✓ Done when:` line *before* the `<!-- id:r_xxx -->` comment.

Format:

```markdown
- **<title>** — <body>. ✓ Done when: <criterion>. <!-- id:r_xxx -->
```

The criterion is open text English, but it should *name an artifact and a location*. The verifier reads the criterion and picks the right probe. Good criteria are concrete enough to verify without ambiguity.

Examples:

| Criterion | Probe |
|-----------|-------|
| `Stanford Sent has a message to dadkins@stanford.edu after Apr 27` | gog gmail search Stanford Sent |
| `Memory/Daily/2026-04-28.md or 2026-04-29.md mentions the Zan comp conversation` | grep recent daily notes |
| `iMessage thread with +14043725016 has an outgoing message after 2026-04-27` | mcp__jons-mcp-imessage__search_messages |
| `Academics/390-ai-search/Logs/2026-04-27_gerald-first-checkin.md exists` | filesystem check |
| `git log in ~/swordpoint-projects/wingen-warren shows a commit touching sync-map-coverage.js after 2026-04-27` | git log probe |
| `Canvas grade landed for STRAMGT 329 Assignment 1` | gog gmail search for Canvas notification |
| `Daily note mentions "ABR terminated" or "ABR offboarded"` | grep daily notes |

If an item has no plausible verification location (e.g., a habit, an open-ended "watch this space"), skip the `Done when:` line — the verifier ignores it.

## Procedure

### 1. Read Radar + Window

- Read `Radar.md`. Parse every line that starts with `- ` or `- **` and contains `<!-- id:r_xxx -->`. Capture each line's section (Urgent / Active / Watching / Open Loops / Summer Projects / Habits) — needed for URGENT-BUMP detection in Step 4.
- **Resolve window:** If `9ton/state/radar-verify-cursor.json` exists, read its `last_run` field; that's the start. Else fall back to `Memory/Hippocampus.md` frontmatter `updated:`. If both fail, default to `now - 6h` (bootstrap). Cap at 24h for cron mode, 7d for handoff mode.
- Build the work list: every parsed item. Items with a `✓ Done when:` line get the criterion probe in Step 3. Items without a criterion still get the people-comms scan in Step 2 — comms can yield UPDATE / URGENT-BUMP even without an explicit done-state. Items that have neither a criterion nor any tagged person are listed at the end of the report under "Items missing criteria" + "Items not pulse-able."

### 2. People-comms scan (always runs)

For each Radar item, parse tagged people from the line and scan recent messaging from those people across four surfaces. New comms become **additional evidence** for Step 3's criterion probe and the trigger for UPDATE / URGENT-BUMP classifications in Step 4.

**Per-item people resolution.** From each item line extract:
- `[[Memory/People/<slug>|...]]` wikilinks → slug directly.
- Bare email addresses in body → reverse-lookup against `Memory/People/*.md` frontmatter `emails:` field.
- First or last names that appear inside `[[...]]` group rosters or known People/ slugs (only when uniquely resolvable — `Carl` alone is ambiguous, `Carl Lowery` resolves).
- Phone numbers in body → use `9ton/scripts/resolve-phone.py` to map to a slug.

For each resolved slug, read `Memory/People/<slug>.md` once per run (cache for the rest of the sweep) and pull `phones`, `emails`, `aliases` from the frontmatter and body.

**Surfaces (run in parallel where the harness allows):**

| Surface | Tool | Filter pattern |
|---------|------|----------------|
| iMessage | `mcp__jons-mcp-imessage__search_messages` (also `get_recent_messages`) | counterparty phone ∈ resolved phones; messages where `date >= window_start`; capture `is_from_me` for direction |
| WhatsApp | `mcp__whatsapp__search_contacts` → `mcp__whatsapp__list_messages(chat_jid, after=window_start)` | resolve each phone → JID first; skip the contact if no JID match |
| Stanford Gmail | `gog gmail search` | `from:<email> OR to:<email> newer_than:24h --account edarwish@stanford.edu --json --max=10` (per email; merge on thread_id) |
| Swordpoint Outlook | Composio MCP (`COMPOSIO_SEARCH_TOOLS` use_case `"search outlook emails since {window} from <emails>"` → `COMPOSIO_GET_TOOL_SCHEMAS` → `COMPOSIO_MULTI_EXECUTE_TOOL`) | scope = SCOPE emails. Re-discover slug each run; do not hard-code. |

**Failure isolation:** if any one surface fails (MCP unreachable, auth expired, rate limit), record `{surface, status:"failed", error}` in the report header and continue. Do not advance the cursor for surfaces that failed; advance only for surfaces that completed cleanly.

**Yield per match:** `{item_id, surface, person_slug, timestamp, direction, snippet (≤200 chars), thread_or_chat_id}`. These flow into Step 3 as the comms evidence pool.

**Cap & dedupe:** at most 5 most recent matches per (item_id, person_slug) tuple. Dedupe across surfaces by `(person_slug, timestamp ±5min, snippet[:60])` to avoid double-counting auto-bridged messages (e.g., an SMS bridged to iMessage).

### 3. Probe each item

**CRITICAL: Before probing, re-read ONLY the `✓ Done when:` clause for each item.** Do not use the item title or body text to infer what to check — use only the criterion. Conflating probe types is how ghost items survive (e.g., an "email sent" criterion should never trigger a Canvas probe).

For each item, interpret the criterion and run the appropriate probe(s). One item may need multiple probes (e.g., "email sent AND daily note confirms" → run both, require both). The criterion language tells you what to do.

**Probe taxonomy:**

| Probe | Tool | Exact command pattern |
|-------|------|-------|
| **Sent email (Stanford Gmail)** | `gog gmail search` | `gog gmail search "in:sent to:<addr> newer_than:7d" --account edarwish@stanford.edu` |
| **Sent email (Swordpoint Outlook)** | Composio MCP | Microsoft 365 Outlook sent-items search via mcp__composio |
| **Draft → sent transition** | `gog gmail search` | If item body mentions a draft ID `XXXXX`: run `gog gmail search "in:drafts" --account <acct>` and check if `XXXXX` appears. Absent from drafts + present in Sent = sent. **Check this first when a draft ID appears anywhere in the item.** |
| **Sent iMessage** | iMessage MCP | `mcp__jons-mcp-imessage__search_messages(query=<keyword>, sender_is_me=true)` then filter by contact + date |
| **Sent WhatsApp** | WhatsApp MCP | `mcp__whatsapp__list_messages(chat_jid=<jid>)` filtered to `is_from_me=true` after the window start |
| **File exists** | `Read` | Read the path; error = does not exist |
| **Git commit** | Bash | `git -C <repo> log --oneline --since=<date> -- <path>` |
| **Daily note mention** | Bash/Grep | `grep -i "<keyword>" ~/9ton-brain/Memory/Daily/YYYY-MM-DD.md` for each daily note in the window |
| **Calendar event in past** | `gog calendar events` | `gog calendar events --from <date> --to <today> --account <acct>` filtered to matching title keywords |
| **Granola transcript** | Granola MCP | `mcp__claude_ai_Granola__query_granola_meetings` when criterion names a specific conversation |
| **External URL live** | Bash | `curl -sIL <url>` — accept any chain ending in 2xx |

**Always also grep daily notes** for keywords pulled from the item title — Eitan often writes "sent Danny email" or "shipped portal" in passing, and this is the cheapest corroborating signal.

**Draft-ID heuristic:** If the Radar item body (not just the criterion) mentions a Gmail draft ID (e.g., `19dd9da001f16627`), always run the draft→sent check automatically, even if the criterion only says "Stanford Sent has email to X." A missing draft = sent email = strong PASS signal.

### Probe-logic rules (learned the hard way)

Before running any gog/file/git/curl probe, read [[Skills/radar-verify/references/probe-logic|references/probe-logic.md]] — 7 non-obvious bugs that produced false-negatives on first runs (Gmail `after:` exclusivity, draft-404 as strong positive, loose-first/tighten-later, thread-head vs latest reply, auth-redirect chains, looser-retry-on-NO, OR/AND branch handling).

### 4. Classify each item — five buckets

Combine Step 2 comms evidence with Step 3 probe results, then place each item in one of:

- **PASS (HIGH confidence)** — primary probe found explicit evidence AND (corroborating signal in daily notes OR Step 2 comms confirmation OR single-source criterion like "file exists"). Auto-clears in `apply` mode.
- **CANDIDATE (MEDIUM)** — one positive signal, partial match, ambiguous criterion, or comms evidence that *might* satisfy the criterion but needs a human eye. Surfaces only — never auto-clears.
- **UPDATE** — comms evidence materially changes the body even though the criterion isn't met. Triggers: counterparty replied with a partial answer, a deadline shifted, a mentioned blocker resolved, an iMessage from the tagged person changed the state ("Renee sent template, in review"). Auto-applies in `apply` mode (in-place body edit).
- **URGENT-BUMP** — comms surfaced new urgency that warrants promoting Active → Urgent **and** the item is currently NOT in `## Urgent (next 48h)`. Strict trigger: an explicit deadline ≤48h appears in a counterparty message OR escalation language tied to a hard date ("need this today, can you respond before EOD Thursday"). Auto-applies in `apply` mode (line moves between sections). Soft escalation without a date ("kind of urgent") stays as UPDATE.
- **NO** — no evidence, or active evidence the work hasn't happened (unsent draft still in Drafts, file missing, no comms in window). Skipped.

When in doubt, downgrade. False-positive cost: CLEAR > URGENT-BUMP > UPDATE. Lost Radar item is more expensive than a noisy line; a noisy line is more expensive than a wrong section.

### 5. Apply (only if `Mode = apply`)

`verify` mode: write nothing. Print the report. Stop.

`apply` mode: execute writes in this order to keep the HQ diff animation clean. **Re-read `Radar.md` immediately before each write** — Eitan or another cron may have edited it during the run.

**5.a — UPDATEs (auto, in-place).** For each UPDATE item, Edit the line to append a dated evidence note before the `<!-- id:r_xxx -->` comment:

```
Original: - **Send Carrier framing to Billy** — Outlook draft saved Apr 30. ✓ Done when: ... <!-- id:r_billyg -->
Updated:  - **Send Carrier framing to Billy** — Outlook draft saved Apr 30. (May 5: Billy iMessage 09:14 "send it whenever — ready when you are"). ✓ Done when: ... <!-- id:r_billyg -->
```

If the line already has a `(May 5: …)` note from this calendar day, **replace** it instead of stacking — keeps lines from growing unbounded. Cap appended note at ~120 chars; truncate snippet if needed.

**5.b — URGENT-BUMPs (auto, section move).** For each URGENT-BUMP:
1. Edit out the line from its current section (`## Active`, `## Watching`, etc.).
2. Edit in the same line (with the new urgency note appended per 5.a) at the **bottom** of `## Urgent (next 48h)`, preserving the `<!-- id:r_xxx -->` comment.
3. Record the source/destination sections in the report.

If two URGENT-BUMPs land in the same run, do them one at a time (re-read between each).

**5.c — CLEARs (HIGH-confidence only, auto-delete).** For each PASS item:
1. Re-read `Radar.md`.
2. Use `Edit` to delete the entire item line (bullet, body, ID comment, trailing newline if applicable).
3. The HQ `checkRadarForXPRelease` watcher (in `9ton-hq/server.js`) picks up the diff into `pending_clears` so the Collect XP button gates the actual XP release.

**MEDIUM CLEAR-shaped findings degrade to UPDATE** — never auto-clear ambiguous items. Cost of a false-positive deletion is higher than the cost of one more day of carry-forward.

**5.d — Cursor write.** After all UPDATEs / URGENT-BUMPs / CLEARs succeed, write `9ton/state/radar-verify-cursor.json`:
```json
{ "schema": 1, "last_run": "2026-05-05T10:00:00-07:00", "surfaces": { "imessage": "ok", "whatsapp": "ok", "gmail": "ok", "outlook": "failed" } }
```
**Per-surface advancement:** if a surface failed in Step 2, omit it from the cursor's `surfaces` ok-list so the next run re-scans its window. The top-level `last_run` advances only if at least one surface succeeded; otherwise leave the cursor unchanged so we don't lose the window.

### 6. Report

Print at end (cron mode logs to stdout; handoff mode shows in chat):

```
RADAR VERIFY — 2026-05-05 10:00 PT
Window: 2026-05-05 08:00 → 10:00  ·  surfaces: imessage ✓ whatsapp ✓ gmail ✓ outlook ✗ (composio auth)
Mode: apply  ·  items scanned: 47  ·  with comms evidence: 12

✓ CLEARED (HIGH) — 1
  • r_d9srq — Send Foundry kit email to Danny
    Probe: Stanford Sent thread 19dd25bab9ae279b → dadkins@stanford.edu 2026-05-05 06:14
    Comms: Daily note 2026-05-05 L42 ("sent Danny the foundry pack")
    [DELETED from Radar.md]

⟳ UPDATED (auto) — 2
  • r_billyg — Send Carrier framing to Billy
    Comms: iMessage from +14043725016 2026-05-05 09:14 "send it whenever — ready when you are"
    Body now: "...(May 5: Billy iMessage — ready when you are)..."

⤴ PROMOTED to Urgent (auto) — 1
  • r_carrfp_resp — WinGen Carrier RFP response
    Comms: Outlook from rbrown@carrier.com 2026-05-05 09:30 "need draft by EOD Thursday"
    Moved: Active → Urgent

? CANDIDATES (MEDIUM — review) — 1
  • r_jnatl — Schedule hang with Jonathan Adelman
    Signal: outbound iMessage 2026-04-27 23:14 ("hey i'm in ATL tmrw") + no reply
    Suggested action: leave; reclassify if reply lands

✗ Still active — 42  (no evidence in window)
— Items missing criteria — 6
  r_carrcst, r_basjd, r_brainarch, r_kqissaq, r_galli, r_e5canarc
  (Add a ✓ Done when: line to enable criterion probing — comms scan still ran.)
```

## Confidence rules of thumb

- **HIGH = auto-clear:** criterion probe explicit + ≥1 corroborating signal (daily note mention, comms evidence from a tagged person, or single-source criterion like "file exists" with the file present).
- **MEDIUM = surface only:** one signal, ambiguous match, or partial completion. Examples: email drafted not sent, commit landed but item's done-state was "deployed", DM sent but criterion needed a confirmation reply.
- **LOW = don't surface as CLEAR:** no signal, or signal contradicts (draft still pending in `gog gmail drafts`, file missing, commit not present). UPDATE may still apply if comms evidence changed the state without satisfying the criterion.
- **UPDATE has no confidence gate.** Any comms-evidence material change to the line state auto-applies. The append is dated and quoted; if it's wrong, Eitan sees the source and corrects.
- **URGENT-BUMP requires a hard date.** "Soon", "ASAP", "kind of pressing" stay as UPDATE. Only an explicit ≤48h deadline or escalation tied to a date promotes.

When the criterion is itself ambiguous ("ship the thing"), report as MEDIUM with a note that the criterion needs a rewrite. Don't auto-clear vague items even if you find tangential evidence.

## Anti-patterns

- **Don't fabricate evidence.** If a probe fails or returns nothing, that's the answer — don't reach for "this seems likely done because X is on Radar."
- **Don't auto-clear MEDIUM items.** False-positive deletion is more expensive than carry-forward.
- **Don't run probes that aren't named in the criterion.** A criterion that names "Stanford Sent" should not trigger a Composio Outlook probe.
- **Don't conflate criterion types.** If the criterion says "Stanford Sent has email to X", probe Gmail Sent. Do not substitute a Canvas check, a daily-note inference, or a "probably done" guess.
- **Don't skip the daily-notes grep.** Cheapest probe; catches casual "I did this" mentions.
- **Don't miss draft IDs in item bodies.** Any draft ID anywhere in the item text → always run the draft→sent check.
- **Don't UPDATE on inbound noise.** Counterparty saying "ok" / "thanks" without state change is not an UPDATE — it's IDLE. UPDATE requires a fact about the item's state.
- **Don't URGENT-BUMP from your own outbound.** Eitan saying "this is urgent" in a sent message doesn't promote — only counterparty deadlines do. Avoids self-amplification loops.
- **Don't stack same-day notes.** If today's note already exists on a line, replace it. Lines can't grow unbounded.
- **Don't advance the cursor on partial failure.** Surfaces that errored stay un-advanced so the next run catches the missed window.

## See Also

- [[Skills/session-handoff/SKILL|Session Handoff]] — calls this skill in `apply` mode before the Radar rewrite
- [[Skills/swordpoint-sweep/SKILL|swordpoint-sweep]] — sibling pattern; same auto-apply UPDATE/ADD discipline, same gated CLEAR
- [[Skills/draft-email/SKILL|Draft Email]] / [[Skills/send-email/SKILL|Send Email]] — Sent-mail surfaces this verifier reads
- [[9ton/automations|Automations]] — `com.9ton.radar-pulse` runs this skill on a 2-hour daytime cron + 2am overnight in `apply` mode
- [[9ton/Logs/2026-04-27_radar-verify-shipped|Original build log]] — design notes from the day v1 shipped
- [[9ton/Logs/2026-05-05_radar-pulse-shipped|Pulse build log]] — design notes from the people-comms scan + cron extension
