---
title: "Probe-Logic Rules"
type: reference
created: 2026-04-28
updated: 2026-04-28
tags: [skill-reference, radar-verify, probe-logic, skill]
---

# Probe-Logic Rules (learned the hard way)

> Loaded by [[Skills/radar-verify/SKILL|Radar Verify]] when interpreting a `✓ Done when:` criterion. Each rule is a non-obvious bug that produced a real false-negative on first runs. Burn them in.

## 1. Use `newer_than:Nd`, not `after:YYYY/MM/DD`

Gmail's `after:` operator is **exclusive** — `after:2026/04/27` returns messages from Apr 28+, *excluding* anything sent on Apr 27.

This bit us on r_d9srq — the Danny email was sent Apr 27 21:32 PT, the probe was `after:2026/04/27`, returned zero. `newer_than:2d` catches it.

**Rule:** for any "sent after a deadline" probe, use `newer_than:` and pad the window 1d wider than the deadline.

## 2. Drafts → 404 is a strong positive

When a Gmail draft is sent, the draft ID **stops resolving** (gog returns `Google API error (404 notFound)`) and the draft falls off `in:drafts`.

If a criterion names a specific draft ID like `19dd25bab9ae279b`, **always probe the draft directly first**:

- `gog gmail get <draft_id>` → 404 = draft was sent (or deleted) → strong positive
- `gog gmail search "in:drafts"` → confirm draft_id absent → corroborates
- Then verify the corresponding Sent message exists with the expected recipient.

This is faster and more reliable than searching Sent first.

## 3. Probe loose first, tighten only if needed

Start with the broadest sensible query: `to:<addr> newer_than:Nd` or `from:<sender> newer_than:Nd`. If it returns >10 results and you can't pick out the relevant one, *then* add a subject keyword.

Adding subject filters upfront is how false negatives happen — {{user_name}} rarely matches the subject you'd guess.

## 4. For threads, the listed ID is the thread head — not the latest reply

When a search returns a thread with a recent date, `gog gmail get <id>` retrieves the **first** message in the thread, not the latest.

To check the most recent reply (e.g., for "did Gunther send red-lines yet"), use `gog gmail thread <id>` and read message N/N at the bottom.

## 5. External URL probes: accept auth-redirect chains

`curl -sIL <url>` follows redirects. A gated app like RACI returns 307 → Entra sign-in (308) → app sign-in page (200). The chain ending at 2xx + valid SSL is evidence the subdomain is provisioned and Entra callback URIs are configured.

Don't fail an item just because the *first* response is 3xx.

## 6. On NO result, retry with one looser query before declaring negative

If `from:vince water heater newer_than:5d` returns nothing, try `from:vince newer_than:7d` (drop the keyword) before classifying NO. The keyword may not match the actual subject. If both miss, then NO.

## 7. Trust the criterion's "OR" branches

A criterion like "Inbox reply OR daily-note mention" passes on either branch — don't require both. A criterion like "X exists AND Y" requires both — don't pass on one.
