---
name: bulk-extract
title: "Bulk Extraction"
type: skill
created: 2026-04-08
updated: 2026-04-08
tags: [skill, memory]
trigger: "After importing external content (claude.ai chats, OpenClaw logs), or periodic catch-up sweep"
---

# Bulk Extraction

## Purpose

Find all unprocessed files in the vault and run entity extraction on each.

## Procedure

1. Search the vault for all files with `extracted: false` in frontmatter. Use: `grep -rl 'extracted: false' <your-vault>/ --include="*.md"`
2. Sort results by date (oldest first) to preserve chronological extraction order.
3. For each file, run the extraction procedure from [[Skills/extraction/SKILL|Extraction (Librarian)]].
4. After all files are processed, do a final pass:
   - Check that no orphan files were created
   - Verify all new files are linked from their parent index file
   - Update Radar.md with any net-new open loops

## When to Use

- After importing claude.ai conversation exports
- After importing OpenClaw session logs
- After any bulk content migration
- As a periodic sweep (weekly or on-demand) to catch anything /handoff missed

## Cost Note

This skill can be token-intensive if many files are unprocessed. For large batches (20+ files), consider running with --model sonnet to manage cost.
