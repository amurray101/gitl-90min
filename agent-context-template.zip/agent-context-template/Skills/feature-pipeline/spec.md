---
title: Spec — Technical PRD
type: skill
created: 2026-04-12
updated: 2026-04-12
tags: [skill, development, pipeline]
trigger: "Called by /feature pipeline during SPEC stage"
---

# Spec

> Write the technical specification / PRD. This is the gate — {{user_name}} must approve before implementation begins.
> Third step in the [[Skills/feature-pipeline/pipeline-orchestrator|Feature Pipeline]].

## Inputs

- `idea.md` — original feature description
- `_pipeline/research.md` — gathered context
- `_pipeline/pipeline-state.json` — feature type, flags

## Outputs

- `prd.md` — technical specification in the project root
- Updated `pipeline-state.json` with refined flags

## Procedure

### 1. Read All Context

- Read `idea.md`
- Read `_pipeline/research.md`
- Read any existing code files referenced in research (skim, don't deep-read)

### 2. Write PRD

Write `prd.md` in the project root (not `_pipeline/` — PRDs are project-level docs per Workbench convention):

```markdown
---
title: "PRD: {Feature Name}"
type: prd
created: {today}
tags: [prd, workbench]
---

# PRD: {Feature Name}

## Problem
{What problem does this solve? Why does it matter?}

## Vision
{What does the finished feature look like? How will {{user_name}} use it?}

## Success Criteria
{Concrete, testable criteria. What must be true for this to be "done"?}
- [ ] Criterion 1
- [ ] Criterion 2
- [ ] ...

## Technical Architecture

### Overview
{High-level architecture: components, data flow, key decisions}

### Components
{For each component:}
#### {Component Name}
- **Purpose:** {what it does}
- **Tech:** {language, framework, key libraries}
- **Input:** {what it receives}
- **Output:** {what it produces}

### Data Flow
{How data moves through the system, from input to output}

## Implementation Plan

| Phase | What | Files |
|-------|------|-------|
| 1 | {first deliverable} | {files to create/modify} |
| 2 | {second deliverable} | {files to create/modify} |
| ... | ... | ... |

## Dependencies
- **Internal:** {vault code to reuse — with file paths}
- **External:** {libraries to install — with versions}
- **Infrastructure:** {services needed — Ollama, ChromaDB, etc.}

## Technical Decisions
{Key choices made and why. Reference research.md findings.}

| Decision | Choice | Why |
|----------|--------|-----|
| {decision} | {what we chose} | {rationale} |

## Risks
{What could go wrong and how to mitigate}

## Open Questions
{Anything that needs {{user_name}}'s input before proceeding}
```

### 3. Update Pipeline State

Update flags based on PRD analysis:
- `creates_skill`: true if the feature will produce a new vault skill
- `needs_external_deps`: true if external packages need to be installed
- `languages`: list of programming languages involved
- `promotion_target`: domain to promote to if applicable (e.g., "{{agent_name}}" for infrastructure)
- `estimated_complexity`: small (< 3 files), medium (3-10 files), large (10+ files)

### 4. Present for Approval

**This is the gate.** Present the PRD to {{user_name}} and wait for explicit approval before the pipeline continues to IMPLEMENT.

If {{user_name}} has feedback:
1. Revise the PRD
2. Re-present
3. Repeat until approved

If {{user_name}} wants to skip straight to implementation, note that in state and proceed.
