---
title: Implement — Build the Feature
type: skill
created: 2026-04-12
updated: 2026-04-12
tags: [skill, development, pipeline]
trigger: "Called by /feature pipeline during IMPLEMENT stage"
---

# Implement

> Build the feature: write code, create skills, or produce vault content.
> Fourth step in the [[Skills/feature-pipeline/pipeline-orchestrator|Feature Pipeline]].
> Follows [[Skills/coding-protocol/SKILL|Coding Protocol]].

## Inputs

- `prd.md` — approved technical spec
- `_pipeline/research.md` — gathered context (reusable code, libraries)
- `_pipeline/pipeline-state.json` — feature type, flags

## Outputs

- `src/` — source code (for code/hybrid features)
- `tests/` — test files
- Skill `.md` files (for skill/hybrid features)
- Config files (`pyproject.toml`, `package.json`, etc.)

## Procedure

### 1. Read the PRD

Read `prd.md` thoroughly. The Implementation Plan section defines the phases and files.

### 2. Set Up Project Infrastructure

Based on feature type and languages:

**Python projects:**
- Create `pyproject.toml` with project metadata, dependencies from PRD
- Create virtual environment: `uv venv`
- Install dependencies: `uv sync`

**JavaScript projects:**
- Create `package.json`
- Install: `npm install`

**Skill projects:**
- No infrastructure needed — just write the `.md` files

### 3. Implement Phase by Phase

Follow the PRD's Implementation Plan table. For each phase:

1. Read relevant existing code referenced in research.md (reuse, don't rewrite)
2. Write the code/skill/content for that phase
3. Run any tests or checks if applicable
4. Move to next phase

**For large features (10+ files):** Use the [[Skills/swarm/SKILL|Swarm]] protocol — delegate mechanical file creation to parallel haiku subagents while the main session handles architecture and integration logic.

### 4. Write Tests

For code features:
- Write tests in `tests/` that verify the PRD's success criteria
- Use the project's test framework (pytest for Python, vitest/jest for JS)
- Focus on: core logic, edge cases, integration with existing vault infrastructure

For skill features:
- No automated tests — verification happens in the VERIFY stage

### 5. Update Project Stage

Update `0-{slug}-index.md` frontmatter: `stage: tinkering`

### 6. Update Pipeline State

```json
"implement": {
  "status": "complete",
  "completed_at": "{ISO now}",
  "output": "src/"
}
```
