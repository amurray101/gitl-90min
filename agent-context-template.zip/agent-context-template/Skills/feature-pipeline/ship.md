---
title: Ship — Close and Announce
type: skill
created: 2026-04-12
updated: 2026-04-12
tags: [skill, development, pipeline]
trigger: "Called by /feature pipeline during SHIP stage"
---

# Ship

> Route the feature to its target, mark the project closed, update tracking, and announce.
> Final step in the [[Skills/feature-pipeline/pipeline-orchestrator|Feature Pipeline]].

## Inputs

- Integrated feature (all prior stages complete)
- `_pipeline/pipeline-state.json`
- `flags.promotion_target` (if set during Spec/Plan)

## Outputs

- Feature wired into its ship target (see routing table below)
- Updated project index with `stage: closed`
- Daily note entry
- Radar update (if tracked)

## Ship-Target Routing

Before closing the project, route the feature to its appropriate home. Use this table:

| Feature shape | Code lives | Skill/Config lives | Promotion target |
|---------------|-----------|--------------------|------------------|
| **Local Python/JS tool** (scripts, one-offs) | `Workbench/{slug}/src/` | Vault skill at `Skills/{name}.md` (if procedural) | Stays in Workbench |
| **Vault skill** (no code) | — | Both `<vault>/Skills/{name}.md` AND `~/.claude/skills/{name}/SKILL.md` (ALWAYS paired per standing rule) | Stays in Skills/ |
| **MCP server** (Claude-facing tool) | `Workbench/{slug}/` (or sibling repo if large) | Config entry in `~/.claude.json` under `mcpServers`, plus `Workbench/{slug}/0-{slug}-index.md` with setup notes | Promote to its own repo once stable |
| **Daemon / background service** | `Workbench/{slug}/` with launchd plist in `Workbench/{slug}/config/` | launchd plist installed to `~/Library/LaunchAgents/` | Promote when multi-project |
| **Swordpoint product surface** | `~/swordpoint-projects/{repo}/` (NOT vault — ship via git push) | Vault log + skill references under `Swordpoint/` | Already promoted |
| **Content / vault restructure** | — | Changes land directly in vault domain folders | N/A |
| **Hybrid (code + skill)** | Combine routing above — code to Workbench/sibling repo, skill files paired to vault + Claude Code | Both | Case-by-case |

**Rule of thumb:** if {{user_name}} will invoke it via `/command`, it needs a `~/.claude/skills/{name}/SKILL.md`. If Claude will invoke it as a tool, it needs an MCP config entry. If it's just code {{user_name}} runs manually, a Workbench project + README is enough.

## Procedure

### 0. Route to Ship Target

Look up the feature's shape in the routing table above. Execute the routing:

1. **Install the skill/config files** if applicable (vault skill + Claude Code SKILL.md, or MCP config entry, or launchd plist)
2. **Commit & push code** if the feature lives in a git-tracked repo
3. **Verify the integration works end-to-end** — run the slash command, trigger the MCP tool, restart the daemon, whatever applies
4. Capture in `pipeline-state.json`:
   ```json
   "ship_target": {
     "type": "local-tool|vault-skill|mcp-server|daemon|swordpoint-product|content|hybrid",
     "code_path": "absolute path",
     "skill_paths": ["vault path", "claude code path"],
     "mcp_config_entry": "name in ~/.claude.json if applicable",
     "promoted": false
   }
   ```

### 1. Close the Project

Update `0-{slug}-index.md`:
- Set frontmatter `stage: closed`
- Update Status section: `## Status: Closed (Shipped {today})`
- Add a brief summary of what shipped

### 2. Update Workbench Index

In `<your-vault>/Workbench/0-workbench-index.md`:
- Move the project wikilink from Tinkering to Closed section

### 3. Add Daily Note Entry

Append to today's daily note (`<your-vault>/Memory/Daily/{today}.md`):

```markdown
## Feature Shipped: {Feature Name}

- **What:** {one-line description}
- **Where:** [[Workbench/{slug}/0-{slug}-index|{Feature Name}]]
- **How to use:** {brief usage instructions}
```

### 4. Update Radar (if applicable)

If the feature was tracked on `<your-vault>/Radar.md`, remove or update the relevant item.

### 5. Announce

Present a summary to {{user_name}}:
- What shipped
- Where it lives
- How to use it
- Any follow-up items or known limitations

### 6. Consider Promotion

If `flags.promotion_target` is set, ask {{user_name}} whether to promote the project from Workbench to its target domain now. Do not promote unilaterally.

### 7. Update Pipeline State

```json
"ship": {
  "status": "complete",
  "completed_at": "{ISO now}"
}
```

Mark `updated_at` on the top-level state object.
