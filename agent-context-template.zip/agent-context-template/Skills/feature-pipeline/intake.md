---
title: Intake — Feature Project Setup
type: skill
created: 2026-04-12
updated: 2026-04-12
tags: [skill, development, pipeline]
trigger: "Called by /feature pipeline during INTAKE stage"
---

# Intake

> If a workbench item for this feature does not exist, create a Workbench project folder, capture the raw idea, classify the feature type, and initialize pipeline state.
> First step in the [[Skills/feature-pipeline/pipeline-orchestrator|Feature Pipeline]].

## Inputs

- Feature description (from user's `/feature` invocation)

## Outputs

- `<your-vault>/Workbench/{slug}/idea.md`
- `<your-vault>/Workbench/{slug}/0-{slug}-index.md`
- `<your-vault>/Workbench/{slug}/_pipeline/pipeline-state.json`
- Updated `<your-vault>/Workbench/0-workbench-index.md`

## Procedure

### 1. Derive Project Slug

From the feature description, create a kebab-case slug:
- "3D vault visualization" → `vault-3d-viz`
- "Telegram bot for daily standup" → `telegram-standup`
- Keep it short (2-4 words max)

Check `<your-vault>/Workbench/` — if a folder with this slug already exists, ask {{user_name}} whether to resume that project or create a new one.

### 2. Create Project Folder

```
<your-vault>/Workbench/{slug}/
  _pipeline/
  src/
  tests/
```

### 3. Write idea.md

```markdown
---
title: {Feature Name}
type: idea
created: {today}
tags: [idea, workbench]
---

# {Feature Name}

## Problem
{What problem does this solve? Extract from user's description.}

## Vision
{What does the solution look like? One paragraph.}

## Initial Thoughts
{Any constraints, preferences, or ideas mentioned by the user.}
```

### 4. Write Index File

```markdown
---
title: {Feature Name}
type: context
domain: workbench
stage: idea
created: {today}
updated: {today}
tags: [context, workbench]
---

# {Feature Name}

> {One-line description}

## Status: Idea

{Brief description of what this project will do.}

## Docs

- [[Workbench/{slug}/idea|Original Idea]]

## Key Links

- [[Workbench/0-workbench-index|Workbench]] (parent)
```

### 5. Classify Feature Type

Determine the type based on the description:

| Type | Signals |
|------|---------|
| `code` | Mentions programming languages, libraries, frameworks, APIs, "build", "tool", "app" |
| `skill` | Describes a procedure, workflow, repeatable process, "pipeline", "protocol" |
| `content` | Reorganizing, linking, structuring vault content, "restructure", "migrate" |
| `hybrid` | Multiple of the above, or code that produces a new skill |

If unclear, default to `code` and adjust later.

### 6. Initialize Pipeline State

Write `_pipeline/pipeline-state.json`:

```json
{
  "feature_id": "{slug}",
  "feature_name": "{name}",
  "feature_type": "{classified type}",
  "working_dir": "<your-vault>/Workbench/{slug}/",
  "created_at": "{ISO now}",
  "updated_at": "{ISO now}",
  "steps": {
    "intake": { "status": "complete", "started_at": "{ISO}", "completed_at": "{ISO}", "output": "idea.md" },
    "research": { "status": "pending" },
    "spec": { "status": "pending" },
    "implement": { "status": "pending" },
    "verify": { "status": "pending" },
    "integrate": { "status": "pending" },
    "ship": { "status": "pending" }
  },
  "flags": {
    "creates_skill": false,
    "needs_external_deps": false,
    "languages": [],
    "promotion_target": null,
    "estimated_complexity": "medium"
  },
  "recommended_pipeline": []
}
```

Set `recommended_pipeline` based on type routing from the orchestrator.

### 7. Update Workbench Index

Add a wikilink to `<your-vault>/Workbench/0-workbench-index.md` under the appropriate section (Tinkering, since we just started it).
