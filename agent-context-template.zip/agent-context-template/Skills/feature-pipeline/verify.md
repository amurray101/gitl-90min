---
title: Verify — End-to-End Testing
type: skill
created: 2026-04-12
updated: 2026-04-12
tags: [skill, development, pipeline]
trigger: "Called by /feature pipeline during VERIFY stage"
---

# Verify

> Test the feature end-to-end against the PRD's success criteria.
> Fifth step in the [[Skills/feature-pipeline/pipeline-orchestrator|Feature Pipeline]].

## Inputs

- `prd.md` — success criteria to verify against
- `src/`, `tests/` — implementation to test
- `_pipeline/pipeline-state.json`

## Outputs

- `_pipeline/verify-report.md`

## Procedure

### 1. Run Automated Tests

If tests exist in `tests/`:
- Run the test suite (`pytest`, `npm test`, etc.)
- Capture results

### 2. Verify Success Criteria

Walk through each success criterion from the PRD:

```markdown
# Verification Report: {Feature Name}

Verified: {timestamp}

## Success Criteria

| # | Criterion | Status | Notes |
|---|-----------|--------|-------|
| 1 | {from PRD} | PASS/FAIL | {what happened} |
| 2 | {from PRD} | PASS/FAIL | {what happened} |
```

For each criterion:
- **Code features:** Execute the code, check output matches expected behavior
- **Skill features:** Dry-run the skill procedure, confirm it triggers correctly and produces expected output
- **Content features:** Check wikilinks resolve, frontmatter is valid, no orphans created

### 3. Check for Regressions

- If the feature modifies existing vault infrastructure, verify existing functionality still works
- If it adds new files, confirm they follow vault conventions (frontmatter, wikilinks)

### 4. Handle Failures

If any criterion fails:
1. Document the failure in the verification report
2. Present to {{user_name}}
3. Ask: fix and re-verify, accept as-is, or abort

If fixing: return to IMPLEMENT for targeted fixes, then re-run VERIFY.

### 5. Update Pipeline State

```json
"verify": {
  "status": "complete",
  "completed_at": "{ISO now}",
  "output": "_pipeline/verify-report.md",
  "passed": true,
  "criteria_met": 5,
  "criteria_total": 5
}
```

## Skipped For

- `content` type features (no code to test — integration handles validation)
