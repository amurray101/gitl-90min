---
title: Feature Pipeline Orchestrator
type: skill
created: 2026-04-12
updated: 2026-04-12
tags: [skill, development, pipeline, orchestrator]
trigger: "Called via /feature slash command"
---

# Feature Pipeline Orchestrator

> Master orchestrator that chains atomic skills into a complete feature development workflow.
> Invoked via `/feature` slash command.

## Invocation Modes

```
/feature "3D vault visualization"                  # New feature from description
/feature --resume vault-3d-viz                      # Resume interrupted pipeline
/feature --step implement vault-3d-viz              # Run single step
/feature --existing vault-embeddings                # Wrap existing Workbench project
```

## Full Pipeline Sequence

```
1. INTAKE     → Create Workbench project, classify type, init state
2. PR-FAQ     → Working-backwards press release + FAQ ← KILL GATE
3. RESEARCH   → Gather context (vault, external, deps) — parallel sub-agents
4. SPEC       → Write PRD, present to {{user_name}} for approval ← PRD GATE
5. PLAN       → File-by-file execution sequence, risk, rollback ← EXECUTION GATE
6. IMPLEMENT  → Build code/skills/content per coding-protocol.md
7. VERIFY     → Test against PRD success criteria
8. INTEGRATE  → Wire into vault (indexes, wikilinks, embeddings, SKILL.md)
9. SHIP       → Route to ship target, close project, announce
```

## Type-Specific Routing

After INTAKE classifies the feature, route accordingly:

| Type | Pipeline Steps |
|------|---------------|
| `code` | intake → pr-faq → research (3 sub-agents) → spec → plan → implement → verify → integrate → ship |
| `skill` | intake → pr-faq → research (vault-only) → spec → plan (light) → implement → verify (dry-run) → integrate → ship |
| `content` | intake → pr-faq → research (vault-only) → spec → plan (file-move manifest) → implement → integrate → ship |
| `hybrid` | intake → pr-faq → research (3 sub-agents) → spec → plan → implement → verify → integrate → ship |

## The Three Gates

The pipeline has three explicit approval gates. Each is a distinct question:

1. **PR-FAQ (kill gate):** *Is this idea worth building?* Read-out: the press release + FAQ. Verdicts: GO / REFINE / KILL.
2. **SPEC (PRD gate):** *Is the architecture sound?* Read-out: the PRD. Approve or iterate.
3. **PLAN (execution gate):** *Is this how we should build it?* Read-out: the file-by-file sequence. Approve or iterate.

Do not proceed past any gate without explicit {{user_name}} approval. Everything else runs end-to-end without pausing.

## Orchestration Logic

### Step 1: Parse Invocation

Parse the invocation arguments:
- If a description string: start new pipeline from INTAKE
- If `--resume`: load existing `pipeline-state.json` from `<your-vault>/Workbench/{slug}/_pipeline/`
- If `--step`: load existing pipeline, run only the specified step
- If `--existing`: find existing Workbench project, infer completed stages from existing files, init state, continue

If `--existing` is used:
1. Check for `idea.md` → mark intake complete
2. Check for `pr-faq.md` → mark pr-faq complete
3. Check for `_pipeline/research.md` → mark research complete
4. Check for `prd.md` → mark spec complete
5. Check for `plan.md` → mark plan complete
6. Check for `src/` with code files → mark implement complete
7. Continue from first incomplete stage

### Step 2: Execute Pipeline

For each step in the routing table:

```
for step in pipeline_steps:
    # Check if already complete (enables resume)
    if pipeline_state.steps[step].status == "complete":
        print(f"  ✓ {step} — already complete")
        continue
    
    # Read the skill procedure
    read("<your-vault>/Skills/feature-pipeline/{step}.md")
    
    # Mark as in-progress
    pipeline_state.steps[step].status = "in-progress"
    pipeline_state.steps[step].started_at = now()
    save(pipeline_state)
    
    # Execute the skill
    run_skill(step)
    
    # Mark complete
    pipeline_state.steps[step].status = "complete"
    pipeline_state.steps[step].completed_at = now()
    save(pipeline_state)
```

**Important:** Three gates require explicit {{user_name}} approval before proceeding:
- After **PR-FAQ**, present the press release + FAQ. Wait for GO / REFINE / KILL verdict. On KILL, stop the pipeline.
- After **SPEC**, present the PRD. Wait for explicit approval.
- After **PLAN**, present the execution sequence. Wait for explicit approval.

Do NOT proceed past any of these gates without {{user_name}}'s approval. Everything else runs end-to-end without pausing.

### Step 3: Handle Interruptions

If execution is interrupted:
- `pipeline-state.json` persists the last completed step
- `/feature --resume {slug}` picks up from where it left off
- Each step is idempotent — re-running a completed step reads existing output

### Step 4: Handle Errors

If a step fails:
1. Mark step as `"failed"` with error message in pipeline state
2. Present the error to {{user_name}}
3. Ask: retry this step, skip it, or abort the pipeline
4. If retry: re-run the step
5. If skip: mark as skipped, proceed to next step
6. If abort: stop pipeline, leave state for future resume

## Resume Protocol

When `--resume` is used:

1. Read `pipeline-state.json` from `<your-vault>/Workbench/{slug}/_pipeline/`
2. Find the first step with status != "complete"
3. Print summary of completed steps
4. Ask {{user_name}}: "Resume from {step}?" or "Start fresh?"
5. Continue pipeline from the resumed step

## Single Step Mode

When `--step {step_name}` is used:

1. Load existing pipeline state
2. Run only the specified step
3. If the step has dependencies that haven't run, warn and ask whether to run dependencies first

## Pipeline State Schema

```json
{
  "feature_id": "string (slug)",
  "feature_name": "string",
  "feature_type": "code|skill|content|hybrid",
  "working_dir": "absolute path to Workbench/{slug}/",
  "created_at": "ISO datetime",
  "updated_at": "ISO datetime",
  "steps": {
    "intake": {
      "status": "pending|in-progress|complete|failed|skipped",
      "started_at": "ISO datetime",
      "completed_at": "ISO datetime",
      "error": "string (if failed)",
      "output": "string (output file path)"
    },
    "pr_faq": { "status": "...", "verdict": "go|refine|kill" },
    "research": { },
    "spec": { },
    "plan": { },
    "implement": { },
    "verify": { },
    "integrate": { },
    "ship": { }
  },
  "flags": {
    "creates_skill": false,
    "needs_external_deps": false,
    "languages": [],
    "promotion_target": null,
    "estimated_complexity": "small|medium|large"
  },
  "recommended_pipeline": ["step names in order"]
}
```
