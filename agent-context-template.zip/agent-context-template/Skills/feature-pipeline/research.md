---
title: Research — Feature Context Gathering
type: skill
created: 2026-04-12
updated: 2026-04-12
tags: [skill, development, pipeline]
trigger: "Called by /feature pipeline during RESEARCH stage"
---

# Research

> Gather prior art, existing vault code, external references, and dependency information.
> Second step in the [[Skills/feature-pipeline/pipeline-orchestrator|Feature Pipeline]].

## Inputs

- `idea.md` — the feature description
- `_pipeline/pipeline-state.json` — feature type, flags

## Outputs

- `_pipeline/research.md` — unified research document

## Sub-tasks

1. **Research Vault** — Search vault for existing code, patterns, related projects
2. **Research External** — Web search for libraries, prior art, approaches
3. **Research Deps** — Check what tools/infra already exist locally

## Procedure

### 1. Determine Which Sub-tasks to Run

- **research-vault** — Always run
- **research-external** — Run for `code` and `hybrid` types
- **research-deps** — Run for `code` and `hybrid` types (skip for `skill` and `content`)

### 2. Run Sub-tasks in Parallel

Spawn applicable agents in a **single message** for parallelism:

#### research-vault (always)

Search the vault for related files and patterns:
1. If `vsearch` exists, run `vsearch search "{feature description}"` to find semantically related vault files; otherwise skip embeddings and rely on graph/keyword search
2. Check `<your-vault>/Workbench/` for related projects
3. Check `<your-vault>/Skills/` for related skills
4. Read any relevant source code found (especially in `Workbench/*/src/`)
5. Document: existing code that can be reused, patterns to follow, files to reference

Write output to `_pipeline/_research-vault.md`.

#### research-external (code/hybrid only)

Search the web for prior art and libraries:
1. Search for relevant libraries, frameworks, and tools
2. Find example implementations or tutorials
3. Check GitHub for similar projects
4. Document: recommended libraries with versions, architecture patterns, trade-offs

Write output to `_pipeline/_research-external.md`.

#### research-deps (code/hybrid only)

Check local infrastructure and dependencies:
1. Check what's installed: Python version, Node version, key tools
2. Verify required services are available (Ollama, ChromaDB, etc.)
3. Check existing virtual environments and package managers
4. Document: available tools, version constraints, infrastructure notes

Write output to `_pipeline/_research-deps.md`.

### 3. Merge Results

After all agents complete, merge temp files into `_pipeline/research.md`:

```markdown
# Research: {Feature Name}

Gathered: {timestamp}

## Vault Context
{contents of _research-vault.md}

## External Research
{contents of _research-external.md, or "N/A — skill/content feature" if skipped}

## Dependencies & Infrastructure
{contents of _research-deps.md, or "N/A" if skipped}

## Summary
- **Reusable code:** {list of existing code/patterns to leverage}
- **Key libraries:** {recommended external dependencies}
- **Infrastructure:** {what's available vs. what needs setup}
- **Risks:** {any concerns or constraints discovered}
```

Delete the temp `_pipeline/_research-*.md` files.

### 4. Update Pipeline State

```json
"research": {
  "status": "complete",
  "completed_at": "{ISO now}",
  "output": "_pipeline/research.md"
}
```
