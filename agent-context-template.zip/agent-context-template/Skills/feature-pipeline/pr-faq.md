---
title: PR FAQ — Working Backwards Kill Gate
type: skill
created: 2026-04-23
updated: 2026-04-23
tags: [skill, development, pipeline]
trigger: "Called by /feature pipeline during PR-FAQ stage"
---

# PR FAQ

> Amazon-style "working backwards" artifact. Write the press release + FAQ as if the feature already shipped, **before** any research is done.
> Second step in the [[Skills/feature-pipeline/pipeline-orchestrator|Feature Pipeline]], between Intake and Research.
> This is the **idea-kill gate**: if the PR doesn't read as compelling, don't build.

## Why This Exists

Research, specs, plans, and code all cost real time. A PR FAQ costs 15 minutes and forces you to answer the hardest question first: *if this shipped tomorrow, would I actually want it?*

Kills vague ideas early. Sharpens good ideas by making the "who cares" explicit. For {{agent_name}}'s context, {{user_name}} is usually the customer — so the PR is written to him, not to a generic market.

## Inputs

- `idea.md` — original feature description (from Intake)
- `_pipeline/pipeline-state.json`

## Outputs

- `pr-faq.md` — press release + FAQ in the project root (first-class artifact, not tucked in `_pipeline/`)
- Updated `pipeline-state.json`

## Procedure

### 1. Read the Idea

- Read `idea.md`
- Read the existing `0-{slug}-index.md`

### 2. Write the PR FAQ

Write `pr-faq.md` in the project root:

```markdown
---
title: "PR FAQ: {Feature Name}"
type: pr-faq
created: {today}
tags: [pr-faq, workbench]
---

# PR FAQ: {Feature Name}

## Press Release

**Headline:** {One line, benefit-led, no jargon. Should make {{user_name}} nod.}

**Subhead:** {One sentence elaborating who it's for and what changes.}

**Summary paragraph:** {3-4 sentences. The feature, the user, the change it causes. As if it shipped today.}

**Problem paragraph:** {What was broken/missing before. Concrete, with an example.}

**Solution paragraph:** {How this feature solves the problem. Keep it simple — no architecture yet.}

**{{user_name}}'s quote:** {What {{user_name}} would say about using this, in first person. This is the honesty check — if you can't write a believable quote, the feature probably isn't worth building.}

**How to get started:** {One or two sentences. The simplest path to using it.}

## FAQ

### Customer FAQ ({{user_name}}-facing)

**What does this do for me day-to-day?**
{Concrete scenarios.}

**How is this different from what I have now?**
{Compare honestly. If the delta is small, say so.}

**What's the first thing I'll notice?**
{The felt difference.}

**What could go wrong that would make me regret this?**
{Real failure modes — not mealy-mouthed "risks.""}

### Why Build This?

**Why now, not later?**
{What changes if this ships in 3 months vs. today? If the answer is "not much," deprioritize.}

**What position does this strengthen or create?**
{Does it deepen lock-in, expand scope, or remove a switching cost? If it's purely additive and anyone could copy it tomorrow, say so.}

**What are we not building, and why?**
{The features or alternatives we explicitly ruled out. Constraints are decisions.}

### Internal FAQ (Build-facing)

**What's the minimum viable version?**
{Cut list. What's in v1, what's deferred.}

**What could kill this during the build?**
{Technical, relational, dependency-level risks.}

**What's the scariest assumption we're making?**
{The one that, if wrong, collapses the idea.}

**What existing vault/Swordpoint code does this reuse?**
{Reference known files. Don't deep-research yet — surface-level only.}

**What's the shape of "done"?**
{One paragraph. What {{user_name}} can do that he couldn't before.}

## Verdict

- [ ] **GO** — the PR reads compelling, the risks are known, proceed to Research
- [ ] **REFINE** — the idea is there but the framing is off; revise the idea.md and re-run
- [ ] **KILL** — the PR reveals this isn't worth building; archive the Workbench project
```

### 3. Tone Guidance

- Write the PR in {{agent_name}}'s voice ([[agent/Soul|Soul.md]]), not corporate SaaS voice
- {{user_name}}'s quote must sound like {{user_name}} — direct, mildly sardonic, no "I'm excited to announce" slop
- If you can't write a sharp {{user_name}} quote, that's a signal the feature isn't landing — flag it in the Verdict section
- Prefer concrete scenarios over abstract benefits ("I can search my WhatsApp for the Carl thread" beats "improved messaging observability")

### 4. Present for Approval — THE KILL GATE

Present the PR FAQ to {{user_name}} and ask for the verdict:
- **GO:** mark the step complete, proceed to Research
- **REFINE:** capture the feedback, update `idea.md` and `pr-faq.md`, re-present
- **KILL:** update the project index with `stage: closed`, move to Workbench "Closed" section with a note about why it was killed, halt pipeline

Do not proceed to Research until {{user_name}} gives an explicit GO.

### 5. Update Pipeline State

```json
"pr_faq": {
  "status": "complete",
  "started_at": "{ISO}",
  "completed_at": "{ISO}",
  "output": "pr-faq.md",
  "verdict": "go|refine|kill"
}
```

If verdict is `kill`, set the top-level `pipeline_state.status = "killed"` and stop.
