---
title: Feature Pipeline Skills
type: context
created: 2026-04-12
tags: [context, skills, development, pipeline, skill]
---

# Feature Pipeline — Skill Index

> Modular skills for the vault feature development pipeline. Orchestrated by [[Skills/feature-pipeline/pipeline-orchestrator|Pipeline Orchestrator]].

## Pipeline Steps

1. [[Skills/feature-pipeline/intake|Intake]] — If workbench for this feature does not exist, Create Workbench project, classify feature type
2. [[Skills/feature-pipeline/pr-faq|PR FAQ]] — Write the working-backwards press release + FAQ (**kill gate**)
3. [[Skills/feature-pipeline/research|Research]] — Gather prior art, existing code, dependencies
4. [[Skills/feature-pipeline/spec|Spec]] — Write technical PRD, present for approval (**PRD gate**)
5. [[Skills/feature-pipeline/plan|Plan]] — Write file-by-file execution sequence (**execution gate**)
6. [[Skills/feature-pipeline/implement|Implement]] — Build the feature
7. [[Skills/feature-pipeline/verify|Verify]] — Test end-to-end against PRD success criteria
8. [[Skills/feature-pipeline/integrate|Integrate]] — Wire into vault (indexes, skills, embeddings)
9. [[Skills/feature-pipeline/ship|Ship]] — Route to ship target, close project, announce

## See Also

- [[Skills/coding-protocol/SKILL|Coding Protocol]] — Development standards
- [[Skills/swarm/SKILL|Swarm]] — Parallel subagent coordination
- [[Workbench/0-workbench-index|Workbench]] — Project pipeline
