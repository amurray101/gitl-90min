---
title: Plan — Execution Sequence
type: skill
created: 2026-04-23
updated: 2026-04-23
tags: [skill, development, pipeline]
trigger: "Called by /feature pipeline during PLAN stage"
---

# Plan

> Translate the approved PRD into a file-by-file, commit-by-commit execution sequence.
> Fifth step in the [[Skills/feature-pipeline/pipeline-orchestrator|Feature Pipeline]], between Spec and Implement.
> This is the **execution gate**: approval here is the green light to start writing code.

## Why This Exists

The PRD answers *what* and *why* at the architecture level. The Plan answers *how* at the keystroke level. Separating them matters because:

- PRD review catches conceptual errors ("we shouldn't store tokens that way")
- Plan review catches execution errors ("this commit sequence leaves the app broken between step 3 and step 5")
- A plan that's approved up-front means Implement runs cleanly without mid-stream course correction

This is also where we can invoke Claude Code's native **Plan Mode** (`EnterPlanMode`) for code-heavy features — plan-only for a pass, approve, then execute.

## Inputs

- `prd.md` — approved PRD (Spec gate passed)
- `_pipeline/research.md` — existing code to reuse, dependencies
- `_pipeline/pipeline-state.json`

## Outputs

- `plan.md` — execution sequence in the project root
- Updated `pipeline-state.json`

## Procedure

### 1. Read the PRD and Research

- Read `prd.md` thoroughly, focusing on the Implementation Plan table
- Read `_pipeline/research.md` for file paths and reusable code
- Skim any code files referenced — enough to know what you're touching

### 2. Write the Plan

Write `plan.md` in the project root:

```markdown
---
title: "Plan: {Feature Name}"
type: plan
created: {today}
tags: [plan, workbench]
---

# Plan: {Feature Name}

## Execution Sequence

Step-by-step, ordered. Each step is a single commit (or a single reviewable unit for skill features). Steps should be chosen so the project stays in a working state between each one where possible.

### Step 1: {Short name}
- **Goal:** {what this step accomplishes}
- **Files:**
  - `path/to/file.ext` — {what changes}
  - `path/to/test.ext` — {test added}
- **How to verify:** {command or behavior check}
- **Commit message:** `{conventional-style commit msg}`
- **Rollback:** {how to undo if broken}

### Step 2: ...
(same shape)

### Step N: Final integration
- **Goal:** wire into vault (or MCP config, or whatever the Ship target requires)
- **Files:** ...

## Test Coverage Plan

What tests exist at the end:
- {test file 1} — covers {behavior}
- {test file 2} — covers {behavior}

Gaps accepted (with reasoning):
- {gap 1} — {why deferring is fine}

## Risk Register

| Risk | Likelihood | Mitigation |
|------|-----------|-----------|
| {specific failure mode} | Low/Med/High | {what we do} |

## Rollback Plan

If the feature needs to be pulled after partial implementation:
- {exactly what to revert, in what order}
- {any state/data that needs cleanup}

## Dependencies To Install

| Package | Version | Purpose |
|---------|---------|---------|
| {pkg} | {ver} | {why} |

## Environment / Secrets Needed

- `{ENV_VAR}` — {what it is, how to get it}
- {OS permission} — {System Settings path if applicable}

## External Steps {{user_name}} Must Do

List anything that can't be automated — QR pairing, OAuth approvals, DNS records, etc.
Mark which steps block the pipeline.

- [ ] {step} — blocking? yes/no
```

### 3. Feature-Type Adaptations

**For `code` and `hybrid` features:**
- Full plan as above
- Consider invoking Plan Mode (`EnterPlanMode`) for complex features — plan-only pass, then approved execution
- Each Step should map to one commit

**For `skill` features:**
- Lighter plan — no commits, no rollback needed
- "Execution Sequence" becomes the order of file writes
- Skip Dependencies / Environment sections unless relevant

**For `content` features (vault restructure):**
- Plan becomes a file-move manifest: from → to, with redirect wikilinks
- Rollback is mandatory — content moves are the most disruptive kind of change

### 4. Present for Approval — EXECUTION GATE

Present the plan to {{user_name}}. The question is narrower than the PRD gate:

> "This is how I'll build it. Any change to the sequence, rollback, or external steps before I start?"

If {{user_name}} approves, proceed to Implement.
If he requests changes, revise and re-present.

### 5. Update Pipeline State

```json
"plan": {
  "status": "complete",
  "started_at": "{ISO}",
  "completed_at": "{ISO}",
  "output": "plan.md"
}
```

Also update `flags.estimated_complexity` based on the final step count:
- ≤3 steps: `small`
- 4-8 steps: `medium`
- 9+ steps: `large`

## Notes on Plan Mode

Claude Code has a native Plan Mode (`EnterPlanMode` / `ExitPlanMode`) that constrains the agent to read-only planning. For large features, consider:

1. After the PRD is approved, invoke Plan Mode
2. Draft the plan while unable to modify files
3. `ExitPlanMode` to present the plan for approval
4. On approval, execute Implement normally

This is a *harness-level* tool — the skill can suggest it, but {{user_name}} (or the orchestrator running in Claude Code) decides whether to engage it. For skill-only or content-only features, Plan Mode is overkill.
