---
title: Integrate — Vault Wiring
type: skill
created: 2026-04-12
updated: 2026-04-12
tags: [skill, development, pipeline]
trigger: "Called by /feature pipeline during INTEGRATE stage"
---

# Integrate

> Wire the feature into the vault ecosystem: update indexes, register skills, add wikilinks, re-embed.
> Sixth step in the [[Skills/feature-pipeline/pipeline-orchestrator|Feature Pipeline]].

## Inputs

- Verified/implemented feature
- `prd.md` — for documentation
- `_pipeline/pipeline-state.json` — flags (creates_skill, promotion_target)

## Outputs

- Updated `0-{slug}-index.md` with full documentation
- New SKILL.md registration (if `creates_skill` flag is set)
- Updated `Workbench/0-workbench-index.md`
- Cross-domain wikilinks
- Re-embedded vault files

## Procedure

### 1. Update Project Index

Rewrite `0-{slug}-index.md` to match the shipped-project format (see [[Workbench/vault-embeddings/0-vault-embeddings-index|vault-embeddings]] as reference):

```markdown
---
title: {Feature Name}
type: context
domain: workbench
stage: tinkering
leans-toward: {domain if applicable}
created: {original date}
updated: {today}
tags: [context, workbench, ...]
---

# {Feature Name}

> {One-line description}

## Status: In Progress

{What was built, how to use it.}

## Docs

- [[Workbench/{slug}/idea|Original Idea]]
- [[Workbench/{slug}/prd|PRD]]

## Source Code

{Table of source files and their purposes, if code feature}

## Key Links

- [[Workbench/0-workbench-index|Workbench]] (parent)
- {Links to related projects, skills, domains}
```

### 2. Register Skills (if applicable)

If `flags.creates_skill` is true:

1. Write the skill procedure to `<your-vault>/Skills/{skill-name}.md` (or `Skills/feature-pipeline/` if it's a pipeline sub-skill)
2. Create `~/.claude/skills/{skill-name}/SKILL.md` with proper frontmatter
3. Add the skill to `<your-vault>/Skills/0-skills-index.md`

### 3. Add Cross-Domain Wikilinks

Add wikilinks from related files back to this project:
- If it consumes another project's output (e.g., vault-embeddings), add a link from that project's index
- If it belongs to a domain, add a link from the domain's index file

### 4. Re-Embed

If `vsearch` exists, run embedding sync to index new/changed files. If it is missing, skip this step and note `embed_mode: skipped`; do not fail integration.

```bash
test -x <your-vault>/Workbench/vault-embeddings/.venv/bin/vsearch && cd <your-vault>/Workbench/vault-embeddings && uv run vsearch index --diff
```

### 5. Update Pipeline State

```json
"integrate": {
  "status": "complete",
  "completed_at": "{ISO now}"
}
```
