---
name: granola-sync
description: Sync Granola meeting transcripts into the vault as structured meeting notes with domain routing and people linking.
title: "Granola Sync"
type: skill
created: 2026-04-09
updated: 2026-04-09
tags: [skill, granola, meetings]
trigger: "User runs /granola-sync, or as part of /handoff if meetings occurred that day"
---

# Granola Sync Skill

> Pull meeting transcripts from Granola and route them into the vault as structured meeting notes.

## Inputs

- **Time range** (optional): defaults to today. Accepts `today`, `this_week`, `last_week`, `last_30_days`, or a custom date range.
- **Meeting ID** (optional): sync a specific meeting by Granola UUID.

## Procedure

### 1. Fetch Meetings

Use `mcp__claude_ai_Granola__list_meetings` with the requested time range to get meeting metadata.

If a specific meeting ID was given, use `mcp__claude_ai_Granola__get_meetings` directly.

### 2. Check for Duplicates

For each meeting, check if a file already exists in `Memory/Meetings/` with a matching `granola_id` in frontmatter. Skip any that already exist (idempotent).

### 3. Fetch Meeting Details

Use `mcp__claude_ai_Granola__get_meetings` (batch up to 10) to get the full summary, attendees, and metadata for each new meeting.

### 4. Determine Domains

For each meeting, assign one or more domain tags based on:

| Signal | Domain |
|--------|--------|
| Attendee email `@swordpointservices.com` | `swordpoint` |
| Attendee email `@stanford.edu` or meeting title contains course codes | `academics` |
| Known personal contacts or no org pattern | `personal` |
| SlideBitch-related keywords | `slidebitch` |
| Multiple signals | Tag all applicable domains |

If domain is ambiguous, tag as `unrouted` and flag in Radar.md under Open Loops.

### 5. Create Meeting File

Write to `Memory/Meetings/YYYY-MM-DD_slug.md` where slug is a kebab-case summary of the meeting title (max 50 chars).

#### Meeting File Template

```yaml
---
title: "Meeting title from Granola"
type: meeting
date: YYYY-MM-DD
time: "HH:MM"
created: YYYY-MM-DD
updated: YYYY-MM-DD
granola_id: "uuid"
domains: [swordpoint, academics, ...]
attendees: [firstname-lastname, ...]
tags: [meeting, domain-tags...]
extracted: false
---
```

Content structure:
```markdown
# Meeting Title

**Date:** YYYY-MM-DD HH:MM
**Attendees:** [[Memory/People/firstname-lastname|Name]], ...
**Domains:** Swordpoint, Academics, etc.

## Summary

[Granola's AI summary — reformatted into clean markdown. Preserve all substance.]

## Decisions

- [Key decisions made, if any]

## Action Items

- [ ] Action item 1 — owner
- [ ] Action item 2 — owner

## Links

- Granola source: [link if available]
- Related: [[wikilinks to relevant domain files, projects, people]]
```

### 6. Update People

For each attendee:
- If a `Memory/People/firstname-lastname.md` exists, do NOT modify it (extraction handles that)
- If no People/ file exists, create a **stub** with:
  ```yaml
  ---
  title: "Firstname Lastname"
  type: person
  created: YYYY-MM-DD
  updated: YYYY-MM-DD
  tags: [person]
  relation: ""
  ---

  # Firstname Lastname

  - **Email:** their@email.com
  - **Organization:** [from email domain]
  - **First seen:** [[Memory/Meetings/YYYY-MM-DD_slug|Meeting Title]]
  ```
- Add the new person to the appropriate group roster at `Memory/People/groups/<group>.md`

### 7. Update Context Files

- If the meeting maps to a specific domain, consider adding a cross-reference in that domain's index file (only for significant meetings, not routine syncs)
- Note: there is no `Memory/Meetings/0-meetings-index.md` — meetings are discovered via the folder, attendee wikilinks, and Spider's meeting back-link pass. Do not create one.

### 7.5. Surface {{user_name}}'s Action Items to Radar

**This step is mandatory.** After creating each meeting file, scan the Action Items section and add any items that belong to {{user_name}} to `Radar.md`. This ensures nothing falls through the cracks.

#### Which items belong to {{user_name}}?

- Explicitly assigned to "{{user_name}}" (or no owner specified — {{user_name}} is implicit in all his meetings)
- Items assigned to other people are **excluded** — those stay in the meeting file only

#### Where to place them in Radar?

- If the item has a deadline within 48 hours → **Urgent (next 48h)** — but only if it's **SMART** (specific artifact + measurable done-state + concrete deadline). Vague action items ("review X", "follow up with Y") go in Active even if soon. See [[Skills/session-handoff/SKILL|session-handoff § 2]] for the template + examples.
- If the item has a deadline this week or is clearly active work → **Active (this week)**
- If the item is more of a "follow up eventually" or "look into" → **Watching**
- If unclear, default to **Active (this week)**

#### Format

```markdown
- **[Action description]** — from [[Memory/Meetings/YYYY-MM-DD_slug|Meeting Title]]. [Due date if known.]
```

#### Rules

- **Deduplicate.** If a similar item already exists in Radar, don't add a duplicate — update the existing one with the meeting link if useful.
- **Preserve context.** Include enough detail that {{user_name}} knows what to do without re-reading the meeting note.
- **Don't over-add.** Skip generic items like "think about X" unless they have a clear deliverable or deadline. Use judgment — the goal is actionable items, not noise.

### 8. Report

Print a concise summary:
```
Synced X meetings:
- YYYY-MM-DD Meeting Title [domains] (N attendees)
- ...
Created N new people stubs.
```

## Rules

- **Idempotent.** Never create duplicate meeting files. Check `granola_id` frontmatter.
- **Don't extract yet — except action items.** Meeting files are created with `extracted: false`. The extraction subagent handles routing knowledge into domain Logs/, Lessons/, People/, etc. **But {{user_name}}'s action items go to Radar immediately during sync** (step 7.5) — they're too time-sensitive to wait for extraction.
- **Summaries, not transcripts.** Use Granola's AI summary by default. Only pull full transcripts (`get_meeting_transcript`) if {{user_name}} specifically requests it.
- **Attendee matching is fuzzy.** Match people by email first, then by name. Granola attendee names may not exactly match People/ filenames.
- **Skip {{user_name}}.** Don't create a person stub or list {{user_name}} as an attendee wikilink — he's always implicit.

## Integration with Other Skills

- **Extraction:** Meeting files feed into the extraction pipeline like Daily notes. The extraction subagent routes knowledge from meetings into People/, domain Logs/, Lessons/, and Radar.
- **Handoff:** `/handoff` can optionally trigger a granola-sync for today before writing the daily summary.
- **Morning briefing:** Can reference recent meetings synced overnight.

## Key Links

- [[Memory/People/0-people-index|People]] — where person stubs are created
- [[Skills/extraction/SKILL|Extraction]] — downstream consumer of meeting files
- [[Skills/session-handoff/SKILL|Session Handoff]] — upstream trigger

## Future: Scheduled Sync

Once proven manually, wire up as a daily cron trigger that:
1. Syncs yesterday's meetings
2. Creates stubs
3. Flags anything interesting in Radar

This avoids manual invocation while keeping the vault fresh.
