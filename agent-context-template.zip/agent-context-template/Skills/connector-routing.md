---
title: "Connector Routing — Composio → gog → STOP waterfall"
type: reference
created: 2026-05-08
updated: 2026-05-08
tags: [skill, reference, composio, gog, mcp, routing, email, calendar]
---

# Connector Routing

> Single canonical pattern for picking which external-service connector a skill should use. Every skill that touches Gmail, Calendar, Drive, or any other Google Workspace surface cites this doc instead of duplicating the routing prose.

## Why this exists

Until 2026-05-08, skills hard-coded `gog gmail send` etc. directly. Foundry classmates who don't have gog installed (the common case — gog needs Homebrew + a per-user Google Cloud project) couldn't run those skills. The fix is a 3-tier waterfall: try the lower-friction connector first, fall back to the richer one, stop with a clear error if neither is available.

The pattern below is **Eitan's own default too** — not just for guinea pigs. His vault and the foundry-template ship the same skills; same routing logic; same code paths. Walking the walk before talking the talk.

## The waterfall (3 tiers)

**Tier 1 — Composio (default).** Hosted OAuth, one-click connect via `https://foundry.9ton.io`, no Google Cloud project required, works on Stanford-managed Google accounts (verified 2026-05-08), cross-platform (Mac + Windows). Composio's MCP exposes the toolkit as `mcp__composio__*` tools.

**Tier 2 — gog CLI (fallback).** Richer surface (12 Google services vs Composio's primary five), nicer ergonomics for power users, runs entirely locally with no third-party broker. Required when:
- Composio doesn't cover the requested service (Slides, Chat, Classroom, Keep — verify before assuming a gap).
- Composio is unavailable (rate-limited, down, account paused).
- The user explicitly opted out of Composio for privacy reasons (Foundry portal supports a friction-y opt-out path).

**Tier 3 — STOP and surface the gap.** Don't try to discover other MCPs heuristically. The wrong-connector-fired case is worse than failing loud. Tell the user: *"Neither Composio Gmail nor gog is available. Add Composio via the Foundry portal, or run `gog auth login` if you've got it installed."*

## Detection sequence

Run at the top of any email/calendar/drive-touching skill:

1. **Check Composio:** if `mcp__composio__COMPOSIO_MANAGE_CONNECTIONS` is loaded AND the relevant toolkit has at least one `ACTIVE` connection (matching the alias the caller wants, if specified), use Composio. Skip to Tier 1 execution.
2. **Check gog:** if Tier 1 doesn't apply, run `which gog`. If it returns a path AND the user wants the requested service (Slides/Chat/Classroom/Keep falls here even when Composio is active), use gog. Skip to Tier 2 execution.
3. **STOP:** surface the message above and let the user pick the path.

## Alias-as-routing-key principle

Both connectors support multiple accounts per service. The **alias** is the routing key — same mental model on both paths, different surface syntax.

| Alias | Composio | gog |
|---|---|---|
| `stanford` | connected account, alias=`stanford` | `--account stanford` |
| `personal` | connected account, alias=`personal` | `--account personal` |
| `swordpoint` | connected account, alias=`swordpoint` (Outlook, not Gmail) | not configured |

Always pass the alias the caller specifies. If unspecified, default to `stanford` for Eitan, or the first ACTIVE connection for guinea pigs (their setup is single-account at first).

## Service coverage matrix (calibrated, 2026-05-08)

| Service | Composio | gog | Notes |
|---|---|---|---|
| Gmail | ✅ Full (fetch, send, reply, attach, batch, drafts) | ✅ Full | Composio attachments use `file_uploadable: true` mechanism — local-file flow not yet end-to-end-tested in this vault. |
| Calendar | ✅ Likely full (verify before claiming parity) | ✅ Full | |
| Drive | ✅ Likely full | ✅ Full | |
| Docs | ✅ Likely | ✅ Full | |
| Sheets | ✅ Likely | ✅ Full | |
| Slides | ⚠️ Unverified | ✅ Full | Tier 2 (gog) is the safe path for now. |
| Chat | ⚠️ Unverified | ✅ Full | Tier 2 (gog) is the safe path. |
| Classroom | ⚠️ Unverified | ✅ Full | Tier 2 (gog) is the safe path. |
| Contacts/People | ✅ via Gmail people endpoints | ✅ Full | |
| Tasks | ⚠️ Unverified | ✅ Full | |
| Keep | ⚠️ Probably no | ⚠️ Limited (Google's API is thin) | If you need Keep, talk about it. |

Update this matrix as services get verified.

## Which Composio tools to use (Gmail surface)

| Action | Composio tool |
|---|---|
| List/search emails | `GMAIL_FETCH_EMAILS` |
| Fetch one message by ID | `GMAIL_FETCH_MESSAGE_BY_MESSAGE_ID` |
| Batch label/archive/etc. | `GMAIL_BATCH_MODIFY_MESSAGES` |
| Create draft | `GMAIL_CREATE_EMAIL_DRAFT` |
| Get a saved draft | `GMAIL_GET_DRAFT` |
| Send a draft | `GMAIL_SEND_DRAFT` |
| Send fresh email | `GMAIL_SEND_EMAIL` |
| Reply in a thread | `GMAIL_REPLY_TO_THREAD` (omit `subject` to stay in-thread) |

For Calendar, Drive, etc., use the Composio tool-search pattern: `mcp__composio__COMPOSIO_SEARCH_TOOLS` with a clear `use_case` string. Tools follow the convention `<TOOLKIT>_<ACTION>` (e.g., `GOOGLECALENDAR_LIST_EVENTS`).

## When skills should cite this doc

Any skill that previously hard-coded `gog gmail`, `gog calendar`, `gog drive`, etc. should now have a routing block at the top that reads:

> **Routing:** see [[Skills/connector-routing|connector-routing.md]]. Default Composio, fall back to gog, STOP if neither is active.

Then split the procedure into ROUTE A (Composio) and ROUTE B (gog) sections with the actual call signatures. See `Skills/send-email/SKILL.md` for the prototype.

## Pointers

- Foundry portal Composio connect page: https://foundry.9ton.io/[slug] — Phase 1 connectors
- Composio dashboard: https://platform.composio.dev
- gog install: `brew install gogcli`; auth: `gog auth login`
- Setup-prompt routing precedent (where this pattern was first written): [[Workbench/foundry-onboarding-site/prompts/integrations/gmail-gog]] (will be renamed to `gmail.md` per Task #7)
