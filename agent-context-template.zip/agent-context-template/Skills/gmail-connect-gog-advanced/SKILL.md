
# Gmail (gog) — Library-Standard Setup Prompt (v2)

> Paste everything below the next `---` into Claude Code (or your active agent) running inside `~/{{vaultDir}}/`. This is the **integration prompt** that wires Gmail into {{firstName}}'s vault via the `gog` CLI — the only Google Workspace surface the Foundry library uses for email. It is eval-first, pre-checked, canonical-architecture-aware, and Stanford-fallback-aware. The first phase walks {{firstName}} through `console.cloud.google.com` end-to-end, including the path that managed accounts (Stanford / corporate / university) MUST take when their IT policy blocks project creation.


# MISSION

You ({{agentName}}) are about to give yourself **email superpowers** for {{preferredName}}. This is a **one-shot integration setup**, not an everyday applet. Once it succeeds, {{firstName}}'s agent — across every future session, every machine — can:

- Search any of {{firstName}}'s Gmail accounts via Gmail's native query syntax.
- Read full threads with every message (no "latest message only" blind spots).
- Create drafts grounded in {{firstName}}'s voice files.
- Send drafts only after explicit approval — never autonomously.
- Apply labels, archive, mark-read/unread, route across multiple accounts.
- Fan out work in parallel — `gog` exposes `--json` and per-account flags suitable for subagent orchestration.

**The artifact this prompt produces:**

1. A working `gog` binary on `$PATH` (`gog --version` ≥ v0.9.0).
2. A `~/.gog/credentials.json` (the OAuth client) — sourced from a Google Cloud project that **{{firstName}} owns and can administer**, regardless of which account the project lives under.
3. One refresh-token entry in `~/.config/gog/` per Gmail account {{firstName}} wants to wire up (Stanford, personal, work, etc.).
4. A canonical entry in `~/{{vaultDir}}/Memory/Preferences/email-routing.md` describing which account is used for which context, including a note when a Stanford / managed account is being authenticated against a personal Cloud project.
5. A daily-note entry in `~/{{vaultDir}}/Memory/Daily/<YYYY-MM-DD>.md` capturing what was wired, what was deferred, and any error fingerprints encountered.
6. ≥3 evals (structural / semantic / behavioral) all green before declaring done.

**What success looks like in {{firstName}}'s words.** A real triage smoke-test runs (`gog gmail search "is:unread" --max 1 --account <addr>`) and returns a result without auth errors, AND {{firstName}} sees a sample triage of three actual threads from their inbox and confirms the categorization reads accurate.


# PRE-CHECKS (load-bearing)

> Run all of these before asking {{firstName}} a single setup question. Pre-checks are how the Library Standard prevents silent degradation — they're not friction, they're the contract. Show {{firstName}} the status panel. Halt on red.

Pre-checks fan out in parallel. Use one tool call per probe; the orchestrator joins. None of these probes should take more than 5s.

## P1. Canonical-architecture probe

Verify the load-bearing paths this prompt depends on actually exist.

```bash
test -d "$HOME/{{vaultDir}}" && echo "vault: OK" || echo "vault: MISSING"
test -d "$HOME/{{vaultDir}}/Skills" && echo "Skills: OK" || echo "Skills: MISSING"
test -d "$HOME/{{vaultDir}}/Memory/Preferences" && echo "Memory/Preferences: OK" || echo "Memory/Preferences: MISSING"
test -d "$HOME/{{vaultDir}}/Memory/Daily" && echo "Memory/Daily: OK" || echo "Memory/Daily: MISSING"
test -d "$HOME/{{vaultDir}}/Reference" && echo "Reference: OK" || echo "Reference: MISSING"
test -f "$HOME/{{vaultDir}}/CLAUDE.md" && echo "CLAUDE.md: OK" || echo "CLAUDE.md: MISSING"
```

**On any MISSING:** halt and surface the remediation:

> "I can't find `{path}` — this prompt assumes the Foundry canonical architecture. Run the onboarding setup prompt from `agent-foundry.vercel.app` first, OR (if you intentionally deviated) add a `## ⚠️ Vault customized` block at the top of `~/{{vaultDir}}/CLAUDE.md` documenting the deviation. I'll then re-run pre-checks and adapt to your custom path."

## P2. Vault-deviation check

If `~/{{vaultDir}}/CLAUDE.md` already contains `## ⚠️ Vault customized`, parse it and show {{firstName}} which paths have been remapped, so this prompt can adapt:

```bash
grep -A 20 '## ⚠️ Vault customized' "$HOME/{{vaultDir}}/CLAUDE.md" 2>/dev/null
```

If nothing is found, that's expected (most users never deviate). Continue.

## P3. `gog` CLI availability

```bash
which gog && gog --version
```

| Outcome | Action |
|---|---|
| `gog --version` prints ≥ `v0.9.0` | OK — proceed. Skip Phase 0 below. |
| `gog: command not found` | NOT-INSTALLED — Phase 0 will install. |
| `gog --version` prints `< v0.9.0` | OUTDATED — Phase 0 will upgrade. |
| `gog --version` prints something but errors with "permission denied" | Binary exists but isn't executable. `chmod +x` it, then re-probe. |

**Gotcha (load-bearing).** The Homebrew formula is **`gogcli`**, not `gog`. `brew install gog` resolves to a different (unrelated) project. If a user has a wrong `gog` binary on PATH, it will print version output for the wrong tool and confuse later probes. To disambiguate:

```bash
gog --help 2>&1 | grep -qi "gmail\|calendar\|drive" && echo "gog: correct binary" || echo "gog: WRONG BINARY — likely the unrelated 'gog' project; uninstall and run 'brew install gogcli'"
```

## P4. Browser availability for OAuth

`gog auth manage` opens a browser to consent. Probe for at least one default browser on the platform:

```bash
# macOS
open -Ra "Google Chrome" 2>/dev/null && echo "Chrome: OK" || \
open -Ra "Safari" 2>/dev/null && echo "Safari: OK" || \
echo "browser: NONE FOUND"
```

If no browser is installed on this machine, halt and tell {{firstName}}: *"OAuth consent requires a browser. Install Chrome / Safari / Firefox first, then re-run."*

## P5. Account intent

This is the **only legitimate pre-check bypass per the Library Standard** — we need follow-up answers before we know which probes to run. Bundle the questions (≤3):

1. **Which Google accounts do you want to wire up?** Read `~/{{vaultDir}}/answers.yaml` if it exists (look for `identity.emails`) — pre-populate the candidate list. Otherwise ask: *"List every Gmail or Workspace email you'd like {{agentName}} to read and write through (one per line)."*
2. **Of those, which is your daily-driver / personal account?** This will be the default account if a routing rule isn't matched.
3. **Which scopes should I request?** Default: read + draft + send + label management (`gmail.modify`). Conservative: read + draft only (no send). Aggressive: all of the above plus Calendar / Drive / Contacts (full Workspace, recommended if you'll add Calendar later).

Wait for the answers, then continue.

## P6. Per-account class probe (after P5 returns)

For each email {{firstName}} listed, classify it as **personal** (gmail.com) or **managed** (anything else — most commonly `*.edu`, corporate domains, or a custom Workspace domain). The class determines whether the account can host its own Cloud project:

```bash
# pseudo: for each email in {{firstName}}.emails:
#   if email ends in @gmail.com → class: personal
#   else → class: managed (cannot reliably create Cloud projects)
```

Surface the classification in the status panel. **At least one personal account must be present** in the list to host the OAuth client. If {{firstName}} listed only managed accounts, ask one follow-up:

> "All the accounts you listed are managed (Stanford, work, etc.). Stanford / managed Workspaces typically forbid non-IT users from creating Google Cloud projects, which is what gog needs to host an OAuth client. Do you have a personal `@gmail.com` account I can use as the OAuth host? The host account doesn't have to be the account you actually email from — it's just an admin container. (Verbatim from a real Stanford-account error: *'You do not have the required permission to create projects.'*)"

If {{firstName}} doesn't have a personal Gmail account, halt and tell them: *"You'll need to either (a) create a personal `@gmail.com` account to host the OAuth client, or (b) get IT to create a managed Cloud project for you. Option (a) is usually faster — five minutes at https://accounts.google.com/signup. Re-run this prompt once you have one."*

## P7. Status panel (the join)

Render a one-screen summary before proceeding:

```
GMAIL × gog SETUP — PRE-CHECK STATUS
====================================
Vault path           ~/{{vaultDir}}             [✓ OK | ✗ MISSING]
CLAUDE.md            present                    [✓ OK | ✗ MISSING]
Customization block  not detected (canonical)   [✓ OK | ⚠ DEVIATED]
gog binary           {version OR "not installed"}  [✓ INSTALLED | ✗ INSTALL NEEDED | ⚠ OUTDATED]
Browser              {Chrome | Safari | Firefox}   [✓ OK | ✗ NONE]

Accounts to wire ({n}):
  1. {addr1}  class={personal|managed}  default-driver=Y/N
  2. {addr2}  class={personal|managed}  default-driver=Y/N
  ...

OAuth host candidate: {personal@gmail.com}
Scope set: {modify | readonly | full-workspace}
Estimated phases: {0 if gog already installed, else 0–5}; {n} auth ceremonies (one per account).

Proceed? (yes / change something)
```

Wait for {{firstName}} to confirm. If they want to change something, loop back to P5 and re-render.


# CUSTOMIZATION

Knobs the user is asked once and the answers persist. Subsequent runs of this prompt or sibling skills (`Skills/email-triage/`, `Skills/draft-email/`) read these answers from `~/{{vaultDir}}/Memory/Preferences/email-routing.md` and don't re-ask.

| Knob | Question | Default | Stored where |
|---|---|---|---|
| **Accounts** | "Which accounts should I wire?" (asked in P5.1) | All accounts in `answers.yaml.identity.emails` | `email-routing.md` § Accounts |
| **OAuth host** | "Which personal account hosts the Cloud project?" (asked in P5/P6) | First `@gmail.com` in the list | `email-routing.md` § OAuth-host |
| **Scope set** | "How aggressive should the OAuth scope set be?" (asked in P5.3) | `gmail.modify` + `calendar` + `drive.readonly` + `contacts.readonly` | `email-routing.md` § Scopes |
| **Default account** | "If a draft doesn't match a routing rule, which account sends?" (asked in P5.2) | Personal Gmail | `email-routing.md` § Default-account |
| **Routing rules** | "When I draft to a Stanford / classmate / professor address, which account?" | Stanford → Stanford. Personal → Personal. Work → Work. Ambiguous → ASK. | `email-routing.md` § Routing-rules |
| **Send protocol** | "Should I always create drafts first, or are some recipients trusted to send-immediately?" | ALWAYS draft-first (no exceptions out of the box). | `email-routing.md` § Send-protocol |

These six knobs become the **Memory/Preferences/email-routing.md** file the AFTER-YOU-FINISH phase writes (or updates).


# WORK PHASES

Five phases, in this order. Each phase declares Inputs → Outputs → Parallelism → Done-when. Phases halt on failure; surface the exact remediation rather than retrying silently.

## Phase 1 — `console.cloud.google.com` setup (FIRST-CLASS, CORE)

> Eitan's note: *"the console dot cloud, that should be a core part of the setup."* This phase is not optional, not a side-step, not a footnote. It is the load-bearing first move. Every later phase fails if Phase 1 didn't land cleanly.

**Inputs:** OAuth host account from P5/P6 (a personal `@gmail.com` confirmed by {{firstName}}).
**Outputs:** A new Google Cloud project owned by the host account, with Gmail API + (per scope set) Calendar / Drive / Contacts APIs enabled, an OAuth consent screen configured (External, with every account from P5.1 listed as a test user), and an OAuth Desktop-app client created — `credentials.json` saved to `~/.gog/credentials.json`.
**Parallelism:** None — this is a guided browser walkthrough; the user is in the loop step-by-step.

### 1.1 Walk {{firstName}} through Cloud Console verbatim

Surface this script in chat. Use the actual URL — `https://console.cloud.google.com/apis/credentials` — not "the OAuth thing" or "Google's developer console". The exact URL matters because it's how {{firstName}} verifies they didn't drift to the wrong console (e.g., Workspace Admin Console).

**Step-by-step (read these aloud / surface in chat one block at a time so {{firstName}} doesn't rabbit-hole):**

> **1.** Open `https://console.cloud.google.com/` in your browser.
> **2.** Look at the **account picker in the top-right corner.** It must show your **personal `@gmail.com` account**, NOT your Stanford / work / university account. If it's showing the wrong one, click it and switch.
>   - **Why this matters:** Stanford / managed accounts will fail in step 3 with the verbatim error: *"You do not have the required permission to create projects."* This is Stanford IT policy, not a Google bug. The OAuth client we create here can authenticate ANY Google account afterward (Stanford, work, personal, all of them) — the project is just an admin container. So it has to live in a personal account.
> **3.** Click the **project dropdown** (next to the "Google Cloud" logo, top-left). Click **"New Project"**.
> **4.** Name the project `{{agentName}}-gog` (or whatever — name doesn't matter for behavior). For "Organization", select **"No organization"** (this is the only option when you're in your personal account, which is what we want). Click **Create**.
> **5.** Wait ~10 seconds for the project to provision. The dropdown will switch to the new project; if it doesn't, click the dropdown and select it manually.

### 1.2 Enable APIs

> **6.** Open `https://console.cloud.google.com/apis/library` in the same browser tab (with your new project selected). Search for and **Enable** each of:
>   - **Gmail API** (required)
>   - **Google Calendar API** (recommended — enables the Calendar sibling integration without re-doing OAuth)
>   - **Google Drive API** (recommended — enables Drive sibling integration)
>   - **People API** (recommended — enables Contacts integration)
> **7.** Each "Enable" click takes ~5 seconds. Wait for the green confirmation before moving on.

### 1.3 OAuth consent screen

> **8.** Open `https://console.cloud.google.com/apis/credentials/consent`. If it asks "User Type", choose **External** → **Create**.
> **9.** Fill the required fields:
>   - **App name:** `{{agentName}}` (or any string — only you will see it).
>   - **User support email:** your personal Gmail (the one hosting this project).
>   - **Developer contact email:** same.
> **10.** Skip the optional fields; click **Save and Continue**.
> **11.** **Scopes screen.** Click **Add or Remove Scopes**. Add at minimum (depending on the scope set chosen in P5.3):
>   - `https://www.googleapis.com/auth/gmail.modify` — read, send, draft, label.
>   - `https://www.googleapis.com/auth/calendar` — read/write Calendar (recommended).
>   - `https://www.googleapis.com/auth/drive.readonly` — Drive read (recommended).
>   - `https://www.googleapis.com/auth/contacts.readonly` — Contacts read (recommended).
>   - If the scope set is "readonly": substitute `gmail.readonly` for `gmail.modify`.
>   - If the scope set is "full-workspace": add `gmail.send` and `drive` (full Drive) explicitly.
>   - **Save and Continue.**
> **12.** **Test users — load-bearing step.** Click **Add Users** and add **EVERY** email address from P5.1 — Stanford, work, personal, all of them. Each test user must be listed explicitly, or its OAuth flow will return `error 403 access_denied: This app is blocked` in Phase 3.
>   - Add: `{{firstName}}` Gmail
>   - Add: `{{firstName}}` Stanford / work / etc.
>   - Save and Continue.
> **13.** Skim the summary screen and click **Back to Dashboard**.

### 1.4 Create the OAuth client (Desktop app)

> **14.** Open `https://console.cloud.google.com/apis/credentials`.
> **15.** Click **+ Create Credentials** → **OAuth client ID**.
> **16.** Application type: **Desktop app**.
> **17.** Name: `{{agentName}}-gog-desktop` (or anything).
> **18.** Click **Create**. A modal appears with the client ID + secret.
> **19.** Click **Download JSON**. Save the file as `~/.gog/credentials.json` (Mac/Linux) or `%USERPROFILE%\.gog\credentials.json` (Windows). Create the `.gog` folder first if it doesn't exist:

```bash
mkdir -p "$HOME/.gog"
mv "$HOME/Downloads/client_secret_*.apps.googleusercontent.com.json" "$HOME/.gog/credentials.json"
```

```powershell
# Windows PowerShell
New-Item -ItemType Directory -Force "$env:USERPROFILE\.gog" | Out-Null
Move-Item "$env:USERPROFILE\Downloads\client_secret_*.apps.googleusercontent.com.json" `
          "$env:USERPROFILE\.gog\credentials.json"
```

### 1.5 Verify Phase 1 produced the expected artifact

```bash
test -f "$HOME/.gog/credentials.json" && \
  jq -r '.installed.client_id' "$HOME/.gog/credentials.json" 2>/dev/null | grep -q "apps.googleusercontent.com" && \
  echo "Phase 1: ✓ credentials.json present and valid" || \
  echo "Phase 1: ✗ credentials.json missing or malformed"
```

**On failure remediation:** *"`credentials.json` isn't where I expected at `~/.gog/credentials.json`, OR it isn't a valid OAuth client JSON. Re-run steps 14–19 and confirm the saved path."*

### 1.6 The Stanford / managed-account branch (mandatory, not a footnote)

This branch is the load-bearing fix the v1 prompt missed. If during step 4 above {{firstName}} sees:

> *"You do not have the required permission to create projects."*

…they are in the wrong account. **The fix is not "switch IT" or "ask Stanford" or "wait."** The fix is:

1. **Click the account picker (top-right) and switch to a personal `@gmail.com` account.** If they don't have one, send them to `https://accounts.google.com/signup` to create one (this takes ~5 minutes; verification by phone).
2. **Re-do steps 3–5 in the personal account.** The project lives in the personal account; that's the entire point.
3. **In step 12 (test users), they STILL add their Stanford / work address as a test user.** This is what allows the OAuth flow in Phase 3 to authenticate the Stanford account against the personal-account-owned project.

Reframe for {{firstName}} explicitly when this branch fires:

> "Stanford IT blocks non-IT users from creating Cloud projects. The fix is a personal Google account hosts the project, but you can still authenticate your Stanford account against it. The project is an admin shell; the auth is per-account. Switching to your personal account in the picker now."

If {{firstName}} pushes back ("can't I just use my Stanford account?"), do NOT relent. The Library Standard's job is to fail loudly with a remediation pointer, not silently degrade. Show them the verbatim error and the verbatim fix. Once they're in the personal account, project creation works.

### 1.7 Phase 1 done-when

- `~/.gog/credentials.json` exists and parses as JSON containing `installed.client_id` ending in `apps.googleusercontent.com`.
- The Cloud project owning that client is owned by a personal `@gmail.com` (not a managed account).
- The OAuth consent screen lists every account from P5.1 as a test user.
- {{firstName}} has confirmed they completed steps 1–19 in chat.

If any of the four are red, halt and remediate before Phase 2.


## Phase 2 — Install / upgrade the `gog` CLI

> If P3 reported `gog ≥ v0.9.0`, skip this phase. Otherwise install or upgrade.

**Inputs:** Platform from `uname -s` / OS detection.
**Outputs:** `gog --version` prints ≥ v0.9.0 on PATH.
**Parallelism:** None — single binary, single platform.

### 2.1 macOS / Linux (Homebrew)

```bash
brew install gogcli
# NOT 'brew install gog' — that resolves to an unrelated project.
```

After install, restart the shell so the PATH refreshes (or `hash -r`):

```bash
hash -r
which gog && gog --version
```

If Homebrew isn't installed, link {{firstName}} to `https://brew.sh` and halt until they install it.

### 2.2 Linux without Homebrew

Download a release binary:

```bash
curl -L "https://github.com/gogcli/gog/releases/latest/download/gog_linux_amd64" -o "$HOME/.local/bin/gog"
chmod +x "$HOME/.local/bin/gog"
```

Ensure `~/.local/bin` is on PATH (`echo $PATH | grep .local/bin`); if not, append `export PATH="$HOME/.local/bin:$PATH"` to `~/.zshrc` / `~/.bashrc`.

### 2.3 Windows

Two paths — **Scoop is preferred** because it manages PATH for you:

```powershell
# Scoop (preferred)
scoop install gog
```

Or manual:

```powershell
# 1. Download the Windows binary from https://github.com/gogcli/gog/releases/latest
# 2. Save to %USERPROFILE%\bin\gog.exe (create the folder if needed)
# 3. Add %USERPROFILE%\bin to PATH:
[Environment]::SetEnvironmentVariable("Path", "$env:Path;$env:USERPROFILE\bin", [EnvironmentVariableTarget]::User)
# 4. Restart the terminal so the PATH updates.
```

### 2.4 Verify

```bash
gog --version
```

Expected: `Build: v0.9.0 (...)` or newer. On any other output, halt with:

> "`gog --version` returned `<actual output>`. I expected `v0.9.0` or newer. Try `brew upgrade gogcli` (or re-download the release binary). If you got `command not found`, the install didn't reach PATH — restart your terminal."

### 2.5 Phase 2 done-when

- `which gog` prints a path.
- `gog --version` prints `v0.9.0` or newer.
- `gog --help` mentions `gmail`, `calendar`, `drive` (correct binary disambiguation per P3).


## Phase 3 — `gog auth` ceremony per account

**Inputs:** `~/.gog/credentials.json` (from Phase 1), the list of accounts from P5.1.
**Outputs:** One refresh-token entry per account in `~/.config/gog/<account>.json` (or system keyring on macOS, depending on `gog` build).
**Parallelism:** **Sequential, NOT parallel.** Each `gog auth manage` invocation opens a browser window; running multiple in parallel would race for the browser. One account at a time, in order: personal first (validates the project), then managed accounts.

### 3.1 First account — the personal Gmail

```bash
gog auth manage --add {{firstName}}-personal@gmail.com
```

`gog` opens `https://accounts.google.com/o/oauth2/v2/auth?...` in the default browser. Walk {{firstName}} through:

> **1.** Sign in (if not already) to the **personal account** (`{{firstName}}-personal@gmail.com`).
> **2.** A warning screen appears: **"Google hasn't verified this app."** This is expected — it's your own app, you just created it. Click **Advanced** → **"Continue (unsafe)"**. The "(unsafe)" label is misleading — it's referring to apps from third parties, but this is YOUR app you minted in Phase 1, and it can only do what the scopes you set allow.
> **3.** Approve the requested scopes (Gmail / Calendar / Drive / Contacts depending on the scope set chosen). Click **Continue**.
> **4.** The browser window will say "Authentication complete — you can close this window." Close it.

Back in the terminal, `gog auth manage` prints:

```
✓ Authenticated {{firstName}}-personal@gmail.com
  Token saved to ~/.config/gog/{{firstName}}-personal-at-gmail.com.json
```

### 3.2 Subsequent accounts — managed (Stanford, work, etc.)

For each remaining account from P5.1:

```bash
gog auth manage --add {{firstName}}@stanford.edu
# repeat for {{firstName}}@workdomain.com, etc.
```

Same browser flow — but **on the sign-in screen, sign in to the MANAGED account this time**, not the personal one. The OAuth client was created in the personal account's project, but Google permits you to authenticate any account against any project that has you listed as a test user (which we did in Phase 1.3 step 12).

**If a managed account auth fails with `403 access_denied: This app is blocked`:**

This means the account isn't listed as a test user on the consent screen. Remediation:
1. Go back to `https://console.cloud.google.com/apis/credentials/consent` (in the personal account).
2. Click **Edit App** → **Test users** → **Add Users**.
3. Add the failing managed address. **Save.**
4. Re-run `gog auth manage --add <managed-addr>`.

**If a managed account auth fails with `403 admin policy denied` or similar IT-policy error:**

This means {{firstName}}'s IT department has DISABLED OAuth from third-party apps for the entire managed Workspace. This is rarer but real (some corporate policies forbid it; Stanford GSuite typically allows it for individuals). Halt this account and tell {{firstName}}:

> "Your IT policy is blocking OAuth from third-party apps on `{addr}`. Options: (a) ask IT to allowlist the app (give them the client ID from `~/.gog/credentials.json`), or (b) skip this account and only use accounts where OAuth works. The personal account already works — most of the value is there."

Continue with remaining accounts; surface the skipped one in the final status.

### 3.3 Verify all accounts authenticated

```bash
gog auth list
```

Expected output: one row per account from P5.1 (minus any that failed IT-policy in 3.2).

```bash
gog auth list --check
```

This actively probes each refresh token. Any `expired` / `revoked` rows must be re-auth'd (re-run `gog auth manage --add <addr>` for that account).

### 3.4 Phase 3 done-when

- `gog auth list` returns N rows where N ≥ 1 (at least the personal account is wired).
- `gog auth list --check` reports every wired account as healthy.
- For each wired account, `~/.config/gog/<sanitized-account>.json` exists and is non-empty.


## Phase 4 — Wire into vault Skills/

**Inputs:** Phase 3 output, the customization answers from CUSTOMIZATION.
**Outputs:** A small set of skill files under `~/{{vaultDir}}/Skills/` that wrap gog patterns so future agent sessions invoke them by name. Plus `~/{{vaultDir}}/Memory/Preferences/email-routing.md` capturing the routing rules.
**Parallelism:** All file writes can fan out — one subagent per file. Join when all return ✓.

### 4.1 Write `~/{{vaultDir}}/Memory/Preferences/email-routing.md`

```markdown
title: Email routing
type: preferences
created: <today YYYY-MM-DD>
updated: <today YYYY-MM-DD>
tags: [preferences, email, gog, routing]

# Email routing — {{firstName}}

> Read me before drafting any email. Updated by `gmail-gog` integration setup and refined as {{firstName}} corrects routing decisions.

## Accounts (wired via gog)

| Account | Class | Use for |
|---|---|---|
| {{firstName}}-personal@gmail.com | personal | Personal correspondence, OAuth host |
| {{firstName}}@stanford.edu | managed (Stanford) | Coursework, classmates, professors, GSB |
| {{firstName}}@workdomain.com | managed (work) | Work / clients / vendors |
| ... | ... | ... |

## OAuth host

The OAuth client (`~/.gog/credentials.json`) is owned by `{{firstName}}-personal@gmail.com`. Stanford / managed accounts authenticate against this personal-account-owned project because Stanford IT does not permit users to create their own Cloud projects. **This is intentional and load-bearing — do not "fix" it by trying to recreate the project under Stanford.**

## Scopes

`gmail.modify` (read + send + draft + label), `calendar`, `drive.readonly`, `contacts.readonly`. Aggressive enough for typical agentic email flows; conservative enough that the OAuth consent screen on first auth doesn't scare {{firstName}}.

## Default account

`{{firstName}}-personal@gmail.com`. If a routing rule below doesn't match, this is the account used.

## Routing rules

In priority order — first match wins.

1. Recipient is on `*.stanford.edu` OR is in `Memory/People/` with affiliation `Stanford` → **Stanford account.**
2. Recipient is on `{{firstName}}`'s work domain OR a known client/vendor → **Work account.**
3. Recipient is family / personal friend (per `Memory/People/` affiliation) → **Personal account.**
4. Recipient is on multiple lists or affiliation is ambiguous → **ASK {{firstName}}** before drafting; do not guess.
5. Default → **Personal account.**

## Send protocol

- **ALWAYS create draft first** via `gog gmail drafts create`. Show {{firstName}} the rendered body in chat. Wait for explicit "send it" / "ship" / "fire" before running `gog gmail drafts send`.
- **Never** send to external recipients (anyone outside {{firstName}}'s known address book) without confirming the address one more time.
- **Never** forward sensitive content. Summarize in a fresh email instead, with explicit consent.
- **Never** permanently delete with `gog gmail batch delete` — archive (remove INBOX label) instead.

## Voice files (read before drafting)

- `~/{{vaultDir}}/Memory/User/{{firstName}}-essay.md` — verbatim voice ground (or `# not provided` placeholder).
- `~/{{vaultDir}}/Reference/email-writing-style.md` — opener / closer / tone reference.

## Last updated

<today YYYY-MM-DD> by `gmail-gog` integration setup, run via {{agentName}}.
```

### 4.2 Write `~/{{vaultDir}}/Skills/email-triage/SKILL.md`

A thin skill that wraps the triage pattern — categorize last-24h unread, surface Urgent + Needs-response, archive the rest after confirmation. Stub:

```markdown
title: Email triage
type: skill
created: <today>
tags: [skill, email, gmail, gog, triage]

# /email-triage

Pull last-24h unread on the default account (or `--account <addr>`); categorize Urgent / Needs-response / FYI / Can-wait; surface Urgent + Needs-response to {{firstName}}; offer to archive the rest after explicit confirmation.

## Pattern

```bash
gog gmail search "is:unread newer_than:1d -category:promotions -category:updates" \
  --account "$(grep 'Default account' "$HOME/{{vaultDir}}/Memory/Preferences/email-routing.md" | head -1 | sed 's/.*`\(.*\)`.*/\1/')" \
  --max 30 --json
```

(Escape the sed if the account format breaks; alternatively read the routing file's structured "Default account" block.)

## Categories

- **Urgent** — explicit deadline in subject, "URGENT", "ACTION REQUIRED", from known critical senders (per Radar).
- **Needs response** — direct asks, questions, "let me know", "thoughts?".
- **FYI** — newsletters, confirmations, no action implied.
- **Can wait** — soft asks with no deadline.

Save the categorization to `~/{{vaultDir}}/Memory/Daily/<today>.md` under `## Email triage`.
```

### 4.3 Write `~/{{vaultDir}}/Skills/draft-email/SKILL.md`

```markdown
title: Draft email
type: skill
created: <today>
tags: [skill, email, gmail, gog, draft]

# /draft-email

Draft an email grounded in {{firstName}}'s voice files. Always `gog gmail drafts create`, never `gog gmail send`.

## Steps

1. Read `~/{{vaultDir}}/Memory/User/{{firstName}}-essay.md` and `~/{{vaultDir}}/Reference/email-writing-style.md`.
2. Apply routing rules from `~/{{vaultDir}}/Memory/Preferences/email-routing.md` to choose the account.
3. Compose body to a temp file (multi-line, em dashes preserved).
4. `gog gmail drafts create --account <addr> --to "..." --subject "..." --body-file /tmp/draft.txt --json`.
5. Show {{firstName}} the rendered body in chat. Wait for "send" before `gog gmail drafts send`.
```

### 4.4 Write `~/{{vaultDir}}/Skills/reply-in-thread/SKILL.md`

```markdown
title: Reply in thread
type: skill
created: <today>
tags: [skill, email, gmail, gog, reply]

# /reply-in-thread

Reply to an existing thread with correct threading headers (In-Reply-To / References).

## Steps

1. `gog gmail thread get <threadId> --account <addr> --json` — read full thread.
2. Find the latest message ID (highest internalDate).
3. Compose reply body to temp file.
4. `gog gmail drafts create --reply-to-message-id <id> --account <addr> --body-file /tmp/reply.txt --json`.
5. Confirm threading rendered correctly (`drafts get <draftId>` shows In-Reply-To header set).
6. Show body to {{firstName}}, wait for approval, then send.
```

### 4.5 Phase 4 done-when

- `~/{{vaultDir}}/Memory/Preferences/email-routing.md` exists with all six knob sections populated.
- `~/{{vaultDir}}/Skills/email-triage/SKILL.md` exists.
- `~/{{vaultDir}}/Skills/draft-email/SKILL.md` exists.
- `~/{{vaultDir}}/Skills/reply-in-thread/SKILL.md` exists.
- All four files have valid frontmatter (parseable YAML).


## Phase 5 — First triage smoke-test

**Inputs:** Phase 3 + Phase 4 outputs; default account from email-routing.md.
**Outputs:** A real triage of three actual unread threads from {{firstName}}'s default account, displayed in chat for {{firstName}}'s acceptance.
**Parallelism:** The three thread fetches fan out in parallel (one subagent per thread).

### 5.1 Pull three real threads

```bash
gog gmail search "is:unread newer_than:7d -category:promotions" \
  --account <default-addr> \
  --max 3 --json
```

If fewer than three unread threads exist in the last 7 days, expand to 30 days. If still fewer than three, use what's there (1 or 2 is fine for smoke-test purposes).

### 5.2 Fan out to subagents (one per thread)

For each thread ID returned, dispatch a subagent with this brief:

> "Read thread `{threadId}` via `gog gmail thread get {threadId} --account <addr> --json`. Categorize as Urgent / Needs-response / FYI / Can-wait. Return JSON: `{threadId, subject, from, category, one_sentence_why}`. Keep your response under 100 words."

The orchestrator joins the three subagent responses.

### 5.3 Show {{firstName}} the result

Render in chat:

```
TRIAGE SMOKE-TEST (3 threads)
=============================
1. [Urgent]      Subject: "Project deadline Friday"
   From: <sender>
   Why: Explicit Friday deadline + direct ask.

2. [Needs reply] Subject: "Coffee Tuesday?"
   From: <sender>
   Why: Direct question, no deadline.

3. [FYI]         Subject: "Stanford GSB newsletter"
   From: <sender>
   Why: No action implied.

Does this categorization read accurate? (yes / no — and which one's wrong)
```

Wait for {{firstName}}'s confirmation. **This is the behavioral eval — done is gated on their "yes."**

### 5.4 Phase 5 done-when

- Three (or fewer if inbox is sparse) categorizations displayed in chat.
- {{firstName}} has explicitly confirmed the categorization reads accurate, OR has corrected one and {{agentName}} has logged the correction to `~/{{vaultDir}}/Memory/Preferences/email-routing.md` § Categorization-corrections for future-skill calibration.


# EVALS

> ≥3 evals, multi-tier (structural / semantic / behavioral). All must run after work phases complete and pass before DEFINITION OF DONE checks all green.

## Structural evals (5)

### S1. `gog --version` prints ≥ v0.9.0

```bash
gog --version | grep -qE 'v(0\.9|0\.[1-9][0-9]|[1-9])' && echo "S1: ✓" || echo "S1: ✗ — gog binary missing or outdated"
```

### S2. `~/.gog/credentials.json` exists and is valid JSON with `installed.client_id`

```bash
test -f "$HOME/.gog/credentials.json" && \
  jq -e '.installed.client_id | endswith("apps.googleusercontent.com")' "$HOME/.gog/credentials.json" >/dev/null && \
  echo "S2: ✓" || echo "S2: ✗ — credentials.json missing or malformed; re-run Phase 1"
```

### S3. At least one `~/.config/gog/<addr>.json` exists and is non-empty

```bash
ls -1 "$HOME/.config/gog/" 2>/dev/null | grep -E '\.json$' | head -1 | \
  xargs -I{} test -s "$HOME/.config/gog/{}" && echo "S3: ✓" || echo "S3: ✗ — no auth tokens found; re-run Phase 3"
```

### S4. `gog gmail search "is:unread" --max 1 --account <default>` returns 200-class response without auth error

```bash
gog gmail search "is:unread" --max 1 --account "<default-addr>" --json 2>&1 | \
  grep -q -v "401\|403\|unauthenticated\|expired" && echo "S4: ✓" || echo "S4: ✗ — auth error on smoke-search; re-run Phase 3 for the failing account"
```

(The search itself succeeds even if zero unread threads exist — the eval is "no auth error", not "results returned".)

### S5. The four vault files Phase 4 promised exist with parseable frontmatter

```bash
for f in \
  "$HOME/{{vaultDir}}/Memory/Preferences/email-routing.md" \
  "$HOME/{{vaultDir}}/Skills/email-triage/SKILL.md" \
  "$HOME/{{vaultDir}}/Skills/draft-email/SKILL.md" \
  "$HOME/{{vaultDir}}/Skills/reply-in-thread/SKILL.md"; do
  test -f "$f" && head -1 "$f" | grep -q '^---' && echo "  ✓ $f" || echo "  ✗ $f MISSING OR NO FRONTMATTER"
done
```

## Semantic evals (3)

### Sem1. `email-routing.md` references the correct OAuth host class

The file's § OAuth-host MUST mention that the project lives in a **personal `@gmail.com`** account (NOT a managed account), AND if any managed accounts are wired, MUST acknowledge the personal-host-managed-auth pattern explicitly.

```bash
grep -q "personal @gmail.com\|personal Gmail\|@gmail.com" "$HOME/{{vaultDir}}/Memory/Preferences/email-routing.md" && \
  grep -q "managed\|Stanford\|IT\|policy" "$HOME/{{vaultDir}}/Memory/Preferences/email-routing.md" && \
  echo "Sem1: ✓" || echo "Sem1: ✗ — email-routing.md missing OAuth-host explanation"
```

### Sem2. Routing rules in `email-routing.md` cover every wired account class

Verify that for each account in `gog auth list`, `email-routing.md` has at least one routing rule that could match it (Stanford rule for Stanford account, work rule for work account, personal default for personal account).

This is best run as a small sub-agent: read both files, return JSON `{coverage: pass|fail, missing: [classes]}`. The orchestrator surfaces the result.

### Sem3. `Skills/draft-email/SKILL.md` references both voice files

```bash
grep -q "{{firstName}}-essay\|firstName.*essay" "$HOME/{{vaultDir}}/Skills/draft-email/SKILL.md" && \
  grep -q "email-writing-style" "$HOME/{{vaultDir}}/Skills/draft-email/SKILL.md" && \
  echo "Sem3: ✓" || echo "Sem3: ✗ — draft-email skill missing voice-file references"
```

## Behavioral evals (3)

### B1. {{firstName}} accepts the triage smoke-test (Phase 5)

Surface the three categorizations. Wait for explicit "yes, accurate" or a correction. **Do not** mark eval green on silence.

```
B1: ✓  ({{firstName}} confirmed all 3 categorizations correct)
B1: ⚠  ({{firstName}} corrected 1; logged to email-routing.md § Categorization-corrections)
B1: ✗  ({{firstName}} flagged the categorization as broadly wrong; halt and revisit Phase 4 routing rules)
```

### B2. {{firstName}} confirms the OAuth-host architecture is what they want

Show {{firstName}} the OAuth-host paragraph from `email-routing.md` and ask:

> "Confirming: the OAuth client lives in your personal Gmail's Cloud project. Your Stanford / managed account auths against it. This is intentional because Stanford blocks Cloud-project creation. If you'd ever leave the personal Gmail (e.g. delete the account), the whole gog setup breaks. OK with this?"

### B3. {{firstName}} confirms the send protocol is "draft-first, no exceptions"

> "By default I'll always create a draft first and wait for your explicit 'send' before sending — even for messages to yourself. Want any exceptions to that? (My recommendation: no exceptions out of the box; we can carve outs later.)"

If {{firstName}} requests exceptions, log them to `email-routing.md` § Send-protocol § Exceptions.

## Eval summary panel

After all 11 evals run, show:

```
EVAL SUITE — Gmail × gog setup
==============================
Structural   5/5 ✓
Semantic     3/3 ✓
Behavioral   3/3 ✓
==============================
OVERALL      11/11 ✓ — ready to declare done.
```

If any eval is ✗ or ⚠, do NOT declare done. Surface the exact failure + remediation; let {{firstName}} decide whether to re-run the failing phase or accept the warning.


# DEFINITION OF DONE

A checkbox list mirroring the evals. Tick each as it goes green. **All must be ✓ before declaring done.**

- [ ] **DOD1.** `gog --version` ≥ v0.9.0 (S1).
- [ ] **DOD2.** `~/.gog/credentials.json` exists, is valid JSON, owned by a personal `@gmail.com` Cloud project (S2 + Sem1).
- [ ] **DOD3.** At least one account authenticated; `~/.config/gog/<addr>.json` non-empty (S3).
- [ ] **DOD4.** Smoke-search runs without auth error on default account (S4).
- [ ] **DOD5.** All four vault files written with valid frontmatter (S5).
- [ ] **DOD6.** `email-routing.md` documents OAuth-host architecture and managed-auth pattern (Sem1).
- [ ] **DOD7.** Routing rules cover every wired account class (Sem2).
- [ ] **DOD8.** Skills reference voice files (Sem3).
- [ ] **DOD9.** {{firstName}} accepted triage smoke-test (B1).
- [ ] **DOD10.** {{firstName}} confirmed OAuth-host architecture (B2).
- [ ] **DOD11.** {{firstName}} confirmed send protocol (B3).


# AFTER YOU FINISH

What {{agentName}} writes back to the vault so the next session compounds rather than re-litigates.

## A1. Daily-note entry

Append to `~/{{vaultDir}}/Memory/Daily/<today>.md` under a `## Session: Gmail × gog wired` block:

```markdown
## Session: Gmail × gog wired

**Source prompt:** Foundry library — `gmail-gog.md` (v2 retrofit).
**Outcome:** ✓ — all 11 evals green.

**Accounts wired:**
- {{firstName}}-personal@gmail.com (personal — OAuth host)
- {{firstName}}@stanford.edu (managed — Stanford)
- ... (per actual list)

**OAuth-host class note:** Cloud project lives in {{firstName}}'s personal Gmail because Stanford blocks Cloud-project creation. Verbatim error encountered (or expected if Phase 1.6 fired): *"You do not have the required permission to create projects."*

**Smoke-test:** triage on 3 threads from default account, {{firstName}} confirmed accurate categorization.

**Skills wired (slash commands installed under `~/{{vaultDir}}/Skills/`):**
- `email-triage`
- `draft-email`
- `reply-in-thread`

**Pointer to canonical routing:** `Memory/Preferences/email-routing.md`.

**#auto-memory** Gmail × gog setup landed cleanly. Future sessions invoke skills, not raw `gog` commands. Routing rules + send protocol live in `Memory/Preferences/email-routing.md` — read that file before drafting.

**Open loops (if any):**
- {{firstName}}@workdomain.com auth deferred — IT-policy 403; ticket filed with IT.
- {{firstName}} flagged 1 of 3 triage categorizations as wrong; correction logged to `email-routing.md` § Categorization-corrections.
```

## A2. Update `~/{{vaultDir}}/Memory/Preferences/email-routing.md`

Already written in Phase 4.1 as the primary artifact. After AFTER-YOU-FINISH runs, ensure:

- The "Last updated" line matches today's date.
- The accounts table reflects what `gog auth list` actually returned (drop any failed accounts; leave a `### Deferred` subsection for them).
- Any behavioral-eval corrections (B1 / B3 exceptions) are appended to the relevant section.

## A3. Account-class note (managed-account pattern, if applicable)

If any managed account was wired, append to `~/{{vaultDir}}/Memory/Lessons/managed-account-oauth.md` (create if missing):

```markdown
title: Managed-account OAuth (Stanford / corporate / university)
type: lesson
created: <today>
tags: [lesson, oauth, gmail, gog, managed-account, stanford]

# Lesson — managed-account OAuth pattern

Managed Workspace accounts (Stanford, corporate, university) typically forbid non-IT users from creating Google Cloud projects. Verbatim error: *"You do not have the required permission to create projects."*

**The pattern that works:** create the Cloud project under a personal `@gmail.com` account, list every managed address as a Test User on the OAuth consent screen, then run `gog auth manage` with the managed address. The managed account auths against the personal-account-owned project. Auth is per-account; the project is just an admin shell.

**The pattern that does NOT work:** trying to create the Cloud project under the managed account. Requires IT involvement (rare, slow); not worth the effort when the personal-host pattern is 5 minutes.

**Re-onboarding implication:** if {{firstName}} ever loses access to the personal Gmail hosting the project (deletes the account, locked out, etc.), the whole gog setup breaks for ALL wired accounts. Mitigation: use a long-lived personal Gmail (not a throwaway), and document the specific Gmail in `Memory/Preferences/email-routing.md` § OAuth-host so a future agent or future {{firstName}} can recover it.
```

## A4. Radar entry (if any deferrals)

If any account was deferred (IT policy, or {{firstName}} chose to wire only a subset), add a Radar item:

```
- {{firstName}}@workdomain.com gog auth deferred — IT-policy 403. ✓ Done when: IT allowlists the OAuth client OR {{firstName}} confirms "skip permanently".
```

## A5. One-line breadcrumb

Add a single line to the top of today's Daily note (above the Session block) so the librarian can see this session existed at a glance:

```markdown
- Wired Gmail × gog: {N} accounts authenticated, all evals green. → `Memory/Preferences/email-routing.md`.
```


# COMMON WORKFLOWS (carried forward from v1)

> The following sections preserve the gog cheat-sheet, error handling, query syntax, and workflow patterns from v1. They are reference material for the skill files Phase 4 wrote — included here so the integration prompt is self-contained.

## Read

| Command | Purpose |
|---|---|
| `gog gmail search "<query>"` | Search threads by Gmail query syntax. Returns thread metadata. |
| `gog gmail messages search "<query>"` | Search messages (not threads). Same query syntax. |
| `gog gmail get <messageId>` | Get a single message. `--format=full|metadata|raw`. |
| `gog gmail thread get <threadId>` | Get a full thread with every message. `--download-attachments` saves files. |
| `gog gmail thread attachments <threadId>` | List attachments without downloading. |
| `gog gmail url <threadId>` | Print the Gmail web URL — useful for pointing {{firstName}} at a thread to read. |

**Common flags on every read command:**
- `--account=EMAIL` (always pass this)
- `--max=N` (default 10 for search; bump to 50 for inbox sweeps)
- `--json` (structured output — always use this when piping into agent reasoning)
- `--page=TOKEN` (pagination)
- `-z/--timezone` (force a specific timezone for date display)

## Gmail query syntax

The `<query>` for `search` is identical to what {{firstName}} types into the Gmail search bar.

| Query | Matches |
|---|---|
| `is:unread` | Unread |
| `is:starred` | Starred |
| `from:<addr>` | From a specific sender |
| `to:me` | Addressed directly to {{firstName}} |
| `subject:"<text>"` | Subject contains text |
| `has:attachment` | Has an attachment |
| `filename:pdf` | Has a PDF attachment |
| `newer_than:7d` | Last 7 days |
| `older_than:30d` | Older than 30 days |
| `after:2026/04/01 before:2026/04/30` | Date range |
| `label:<name>` | Has the named label |
| `category:primary` / `category:updates` / `category:promotions` | Gmail tab |
| `in:inbox` / `in:sent` / `in:trash` / `in:spam` / `in:anywhere` | Folder |
| `-from:<addr>` | Negation |
| `(from:a@x.com OR from:b@x.com) is:unread` | Boolean ops with parens |

**Stack queries.** Examples:
- Unread, last 24h, addressed to me, not promotions: `is:unread newer_than:1d to:me -category:promotions`
- Stale threads from a sender: `from:bob@x.com -in:sent newer_than:90d` then check thread for last reply.
- Urgent + needs response: `is:unread (label:Urgent OR subject:URGENT OR subject:"action required")`.

## Write

| Command | Purpose |
|---|---|
| `gog gmail send` | Send a new email. Required: `--to`, `--subject`, `--body` (or `--body-file`). |
| `gog gmail send --reply-to-message-id <id>` | Reply that threads correctly (sets In-Reply-To/References + thread ID). |
| `gog gmail send --thread-id <id>` | Reply within a thread (uses latest message for reply headers). |
| `gog gmail send --reply-all` | Auto-populate To/Cc from the original message. |
| `gog gmail drafts create` | Create a draft (does NOT send). Same flags as `send`. |
| `gog gmail drafts update <draftId>` | Edit an existing draft. |
| `gog gmail drafts send <draftId>` | Send an existing draft. |
| `gog gmail drafts list` | List all drafts. |
| `gog gmail drafts get <draftId>` | Show a draft (verify before sending). |
| `gog gmail drafts delete <draftId>` | Delete a draft. |

**Body input — three ways:**
1. `--body "Hello"` — short single-line bodies. Avoid for anything multi-paragraph.
2. `--body-file path/to/body.txt` — multi-line plain text. **Preferred for any real email.**
3. `--body-html "<p>Hello</p>"` — HTML body. Use sparingly; {{firstName}}'s voice is plain text by default.

**Attachments:** `--attach path/to/file.pdf` (repeatable).

**From alias:** `--from "alias@example.com"` only works for verified send-as aliases.

## Organize

| Command | Purpose |
|---|---|
| `gog gmail labels list` | List all labels. |
| `gog gmail labels create <name>` | Create a new label. |
| `gog gmail thread modify <threadId> --add-label X --remove-label Y` | Apply / remove labels on a thread. |
| `gog gmail batch modify <messageId> ...` | Same op across many messages. |
| `gog gmail batch delete <messageId> ...` | Permanent delete (rare — prefer "remove INBOX" archive). |

**Archive a thread** (= remove from inbox without deleting):

```bash
gog gmail thread modify <threadId> --remove-label INBOX --account <addr>
```

**Caveat (load-bearing):** prefer `gog gmail thread modify` over `gog gmail batch modify` for inbox triage on multi-message threads. `batch modify` only hits the latest message — multi-message threads zombie back to UNREAD because the older messages still carry the label. `thread modify` operates on every message in the thread.

## Auth

| Command | Purpose |
|---|---|
| `gog auth manage` | Open browser to add/remove accounts. |
| `gog auth list` | List authenticated accounts. |
| `gog auth list --check` | Verify each refresh token still works. |
| `gog auth remove <addr>` | Revoke an account locally. |
| `gog auth alias` | Manage friendly aliases. |


# ERROR HANDLING

| Error | Diagnosis | Fix |
|---|---|---|
| `account 'X' not authenticated` | Account not in keyring | `gog auth manage --add X`, sign in to that account |
| `HTTP 401 Unauthorized` | Refresh token expired or revoked | `gog auth manage --add <addr>` to re-auth |
| `HTTP 403 access_denied: This app is blocked` | Account not on consent-screen test users | Add the account at `https://console.cloud.google.com/apis/credentials/consent` → Test users → Save. Re-auth. |
| `HTTP 403 admin policy denied` | Workspace IT policy blocks third-party OAuth | Ask IT to allowlist the OAuth client ID, OR skip this account |
| `HTTP 403 insufficient permissions` | Scope wasn't granted at auth time | `gog auth remove <addr>` then `gog auth manage --add <addr>` — accept all requested scopes |
| `HTTP 429 rate limited` | Hit Gmail API quota | Back off; reduce `--max`; add delays between calls |
| `body required` | Sent without `--body` or `--body-file` | Always use `--body-file` for multi-line — write to temp file first |
| `recipient parse error` | Malformed `--to` address | Use plain `name@domain.com` (no quoted display names; for display name, format as `"Name <name@domain.com>"` and shell-escape) |
| `credentials.json not found` | Phase 1 didn't land | Re-run Phase 1; verify `~/.gog/credentials.json` after step 19 |
| `permission to create projects denied` (Cloud Console) | Trying to create project in managed account | Switch account picker to personal `@gmail.com`; re-do Phase 1 step 4 |
| `multi-message thread didn't get archived` | Used `batch modify` on a thread | Use `gog gmail thread modify <threadId> --remove-label INBOX` instead |

When in doubt, add `--verbose` to any command for debug logging.


# BOUNDARIES (load-bearing)

These are hard rules. Encode into behavior — never relax without explicit per-instance permission from {{firstName}}.

### NEVER without explicit approval

- **Send any email.** Default is always `gog gmail drafts create` then show {{firstName}} the body. Send only after explicit "send it" / "ship it" / "fire" / "yes do it".
- **Send to external recipients** (anyone outside {{firstName}}'s known address book) without confirming the address one more time.
- **Forward sensitive content.** Summarize in a fresh email instead, with explicit consent.
- **Apply decisional labels** (e.g., "Don't Reply", "Spam") without confirming.
- **Permanently delete** anything (`batch delete`). Use archive (remove INBOX label) instead.

### YOU CAN do freely

- Search and read any of {{firstName}}'s emails on wired accounts.
- Apply non-decisional labels already discussed (e.g., "Triaged", "Read-Later").
- Mark messages read / unread.
- Archive threads after surfacing them and {{firstName}} confirming.
- Create drafts (always, never gated).
- Update existing drafts.
- Pull thread URLs for {{firstName}} to open in browser.

### Draft-first protocol (the rhythm)

For every "reply to X" or "send X to Y" request:

1. Read the source thread (if reply) or the requesting message (if new).
2. Pull voice ground from `~/{{vaultDir}}/Memory/User/{{firstName}}-essay.md` + `~/{{vaultDir}}/Reference/email-writing-style.md`.
3. Compose the body, write to a temp file.
4. `gog gmail drafts create` (with `--reply-to-message-id` or `--thread-id` if reply, so threading is correct).
5. Show {{firstName}} the rendered body in chat — don't make them open Gmail to review.
6. Wait for explicit "send" before running `gog gmail drafts send <draftId>`.
7. After sending, confirm with the message ID and a one-line "sent ✓" — don't dump the whole email back.


# CALENDAR — see sibling integration prompt

This prompt covers Gmail. For Calendar (event creation, availability, meeting prep), gog has a parallel surface (`gog calendar events|create|update|freebusy|respond`). The OAuth client + scopes from Phase 1.3 already cover Calendar; running `calendar-gog.md` next is incremental — no new Cloud-Console work, just more `gog auth manage` ceremonies if any account needs Calendar specifically.


# CROSS-LINKS

- [[Foundry/Templates/library-standard|Foundry Library Standard]] — the contract this prompt conforms to.
- [[Reference/email-writing-style|Email-writing-style reference]] — voice ground.
- [[Skills/email-triage/SKILL|email-triage skill]] (written by Phase 4.2).
- [[Skills/draft-email/SKILL|draft-email skill]] (written by Phase 4.3).
- [[Skills/reply-in-thread/SKILL|reply-in-thread skill]] (written by Phase 4.4).
- [[Memory/Preferences/email-routing|email-routing preferences]] (written by Phase 4.1).
- [[Memory/Lessons/managed-account-oauth|Managed-account OAuth lesson]] (written by AFTER-YOU-FINISH A3, if any managed account wired).
- [[Foundry/0-foundry-index|Foundry]] — Library section.
- [[Workbench/foundry-onboarding-site/0-foundry-onboarding-site-index|Onboarding site]] — portal that surfaces this prompt.


# CHANGELOG

- **v2 (2026-05-05) — Library-Standard retrofit.** Restructured around PRE-CHECKS / WORK-PHASES / EVALS / DEFINITION-OF-DONE / AFTER-YOU-FINISH. Made `console.cloud.google.com` setup a first-class core phase (Phase 1) instead of a side-step. Built in the Stanford / managed-account fallback as a mandatory branch (Phase 1.6) with the verbatim error and verbatim fix. Added 11 evals across 3 tiers. Added Memory/Preferences/email-routing.md as canonical routing artifact. Added Memory/Lessons/managed-account-oauth.md as the carry-forward lesson. Eitan's feedback that triggered the retrofit: *"this Gmail prompt was was horrible, actually... it's supposed to be a head start, not built from scratch"* + *"the console dot cloud, that should be a core part of the setup"*. Supersedes `foundry-onboarding-site/prompts/integrations/gmail-gog.md`.
- **v1 (2026-05-03) — Original.** Single-file paste-in prompt. 511 lines. Library-Standard partially compliant (had MISSION, BOUNDARIES, WORKFLOWS) but missing PRE-CHECKS, EVALS, DEFINITION OF DONE, AFTER-YOU-FINISH. Stanford fallback was buried in §2a as one paragraph; Cloud Console setup was a sub-step rather than a core phase.


*If `gog`'s CLI surface changes (new flags, renamed subcommands), update the Read / Write / Organize / Auth tables first — every Foundry user's Gmail behavior depends on those tables being correct.*
