---
name: gmail-connect
description: Connect Gmail (and Calendar via the same OAuth) via Composio — hosted OAuth, no Google Cloud Console project required. Default path; supports multiple aliases (stanford, personal, work). The legacy gog path is preserved as the gmail-connect-gog-advanced skill for users who explicitly opt out of third-party brokers.
---

# Gmail (Composio) — Library-Standard Setup Prompt

> Paste everything below the next `---` into Claude Code (or your active agent) running inside `~/{{vaultDir}}/`. This is the **default Gmail integration prompt** for {{firstName}}'s vault. It wires Gmail through **Composio** — a hosted OAuth integration provider — which means no Google Cloud Console project, no `credentials.json`, no per-user OAuth client setup. {{firstName}} clicks one consent screen and is done.

> **Why Composio is the default:** the older gog-CLI path takes 40+ minutes for first-time users (creating a Google Cloud project, enabling APIs, configuring OAuth consent, downloading credentials). Composio takes 2–3 minutes and works on Stanford-managed Google accounts that block third-party OAuth at the org level. If {{firstName}} prefers gog (richer surface, runs locally, no third-party broker), see `gmail-gog-advanced.md` in this same folder — but expect to spend an afternoon and ping Eitan when stuck.

---

# MISSION

You ({{agentName}}) are giving yourself **email superpowers** for {{preferredName}} via Composio. This is a **one-shot integration setup**, not an everyday applet. Once it succeeds, {{firstName}}'s agent — across every future session, every machine — can:

- Search any of {{firstName}}'s Gmail accounts via Gmail's native query syntax (`from:`, `subject:`, `newer_than:`, `is:unread`, etc.).
- Read full threads with every message (no "latest message only" blind spots).
- Create drafts grounded in {{firstName}}'s voice files.
- Send drafts only after explicit approval — never autonomously.
- Apply labels, archive, mark-read/unread, route across multiple accounts via Composio aliases.
- Run multiple connected accounts (Stanford + personal + work) with a single mental model.

**The artifact this prompt produces:**

1. ≥1 active Composio Gmail connection (verified via `COMPOSIO_MANAGE_CONNECTIONS list`).
2. A canonical entry in `~/{{vaultDir}}/Memory/Preferences/email-routing.md` describing which alias maps to which Gmail account and which contexts each one should be used for.
3. A daily-note entry in `~/{{vaultDir}}/Memory/Daily/<YYYY-MM-DD>.md` capturing what was wired, what was deferred, and any connection issues hit.
4. ≥3 evals (structural / semantic / behavioral) all green before declaring done.

**What success looks like in {{firstName}}'s words.** A real triage smoke-test runs (`GMAIL_FETCH_EMAILS({ query: "is:unread", max_results: 1 })`) and returns a result without auth errors, AND {{firstName}} sees a sample triage of three actual threads from their inbox and confirms the categorization reads accurate.


# WHAT IS COMPOSIO? (one paragraph for {{firstName}})

> Composio is an integration platform — think of it like Stripe for connecting AI agents to apps. Instead of {{firstName}} creating their own Google Cloud project and managing OAuth credentials, Composio runs a verified Google OAuth app and brokers the connection. The consent screen {{firstName}} sees during setup is the same Google "Sign in with Google" page they see for Slack or Notion. Trust signals: Composio is a YC-backed company with SOC 2 Type II compliance; their site is at https://composio.dev and the privacy/security details are at https://composio.dev/privacy. Composio sees the connection metadata (scopes, refresh tokens) but doesn't store {{firstName}}'s email contents — those flow through their API as ephemeral request bodies.


# PRE-CHECKS (load-bearing)

> Run all of these before asking {{firstName}} a single setup question. Pre-checks are how the Library Standard prevents silent degradation. Show {{firstName}} the status panel. Halt on red.

## P1. Canonical-architecture probe

Verify the load-bearing paths this prompt depends on actually exist.

```bash
test -d "$HOME/{{vaultDir}}" && echo "vault: OK" || echo "vault: MISSING"
test -d "$HOME/{{vaultDir}}/Skills" && echo "Skills: OK" || echo "Skills: MISSING"
test -d "$HOME/{{vaultDir}}/Memory/Preferences" && echo "Memory/Preferences: OK" || echo "Memory/Preferences: MISSING"
test -d "$HOME/{{vaultDir}}/Memory/Daily" && echo "Memory/Daily: OK" || echo "Memory/Daily: MISSING"
test -f "$HOME/{{vaultDir}}/CLAUDE.md" && echo "CLAUDE.md: OK" || echo "CLAUDE.md: MISSING"
test -f "$HOME/{{vaultDir}}/Skills/connector-routing.md" && echo "connector-routing.md: OK" || echo "connector-routing.md: MISSING"
```

**On any MISSING:** halt and surface the remediation:

> "I can't find `{path}` — this prompt assumes the Foundry canonical architecture. Run the onboarding setup prompt from `https://foundry.9ton.io/{{slug}}` first, then come back here."

## P2. Composio MCP availability

The Composio MCP must be loaded into the agent's tool surface. Probe with:

```
COMPOSIO_SEARCH_TOOLS({ queries: [{ use_case: "verify Composio is reachable" }], session: { generate_id: true } })
```

| Outcome | Action |
|---|---|
| Returns a normal response with toolkits | OK — proceed. |
| Tool is undefined (`mcp__composio__*` not in toolset) | NOT-LOADED — halt. Tell {{firstName}}: "Composio MCP isn't connected to your Claude Code. The Foundry portal (`https://foundry.9ton.io/{{slug}}`) handles this in Phase 1; complete that step first, or text Eitan if it's not working." |
| Returns auth error | EXPIRED — Composio account session expired. {{firstName}} should re-auth at https://platform.composio.dev. |

## P3. Existing Gmail connections

```
COMPOSIO_MANAGE_CONNECTIONS({ toolkits: [{ name: "gmail", action: "list" }] })
```

| Outcome | Action |
|---|---|
| 0 active connections | EXPECTED on first run — Phase 1 will add. |
| ≥1 active connection | Show {{firstName}} which aliases are already connected. Ask if they want to add more (Phase 1 is optional in this case). |


# PHASE 1 — CONNECT GMAIL ACCOUNT(S)

> Multi-account is the norm, not the exception. Most users have a Stanford / school account AND a personal Gmail. Some have a work account too. Wire all the ones that matter.

## 1.1 Ask which Gmail accounts {{firstName}} wants to connect

Before initiating any connection, ask:

> "Which of your Gmail accounts should I connect for {{agentName}}? List the email addresses + a short alias for each (e.g., 'edarwish@stanford.edu = stanford', 'eitan@gmail.com = personal'). The alias is how {{agentName}} will route email actions to the right account in the future ('reply from my personal', 'check stanford for the syllabus', etc.). You can do one now and add more later."

Wait for {{firstName}}'s answer. If they only name one account, fine — they can add more anytime by re-running this prompt.

## 1.2 Initiate connection per account

For EACH (email, alias) pair {{firstName}} listed:

```
COMPOSIO_MANAGE_CONNECTIONS({
  toolkits: [{ name: "gmail", action: "add", alias: "<alias>" }],
  session_id: "<session-id-from-P2>"
})
```

The response includes a `redirect_url` of the form `https://connect.composio.dev/link/lk_*`. Show this as a clickable markdown link to {{firstName}}:

> "**Connect [your-email-here] →** [Click here to authorize](redirect_url-here)
>
> What happens: a Composio-branded page opens, asks you to sign in with Google, then shows a consent screen with the requested scopes. The link expires in 10 minutes."

## 1.3 Wait for connection

After surfacing the link, immediately call:

```
COMPOSIO_WAIT_FOR_CONNECTIONS({
  toolkits: ["gmail"],
  mode: "any",
  session_id: "<session-id>"
})
```

This polls until the connection becomes ACTIVE (or fails / times out).

## 1.4 Stanford / managed-account fallback

If the OAuth flow fails with a "your administrator has disabled access to this third-party app" message: {{firstName}}'s Google Workspace admin has blocked third-party OAuth. Composio's OAuth app is on the Stanford allowlist as of 2026-05-08, so this should be rare — but if {{firstName}} hits it on a different managed account (corporate, university), the workaround is to connect a personal Google account instead and route school-related context through that. Do NOT try to work around the admin block; surface clearly to {{firstName}} that it's a Workspace policy and they'd need IT involvement to unblock.

## 1.5 Loop for additional accounts

After each successful connection, ask:

> "✓ Connected `<email>` as alias `<alias>`. Want to add another Gmail account?"

If yes, loop back to 1.2. If no, move to Phase 2.


# PHASE 2 — VALIDATE WITH A REAL SMOKE-TEST

For each connected alias, run a single read against the inbox to prove the connection works end-to-end:

```
GMAIL_FETCH_EMAILS({
  query: "is:unread",
  max_results: 3,
  ids_only: false,
  include_payload: false
})
```

(Use `user_id: "me"` implicit default. The connection's alias is the routing key — Composio resolves which account "me" is.)

Show {{firstName}} the 3 most recent unread subjects + sender names. Ask:

> "Does that look like your inbox? (Just sanity-checking the connection.)"

If they say no, halt — something's wrong with which account got authorized vs. expected. Suggest disconnecting via `COMPOSIO_MANAGE_CONNECTIONS({ toolkits: [{ name: 'gmail', action: 'remove', account_id: '<id>' }] })` and re-connecting.

If yes, the smoke-test passed. Continue.


# PHASE 3 — DOCUMENT IN VAULT

## 3.1 Write `Memory/Preferences/email-routing.md`

Append (or create if missing) the canonical email-routing doc:

```markdown
---
title: Email Routing
type: preference
tags: [preference, email, composio, routing]
---

# Email Routing

> Which Gmail account is used for which context, and how {{agentName}} should pick.

## Connected accounts (Composio aliases)

- **stanford** → `<stanford-email>` — school context, professors, classmates, Canvas
- **personal** → `<personal-email>` — friends, family, non-work
- **work** → `<work-email>` — clients, vendors, employer
- (add others as connected)

## Routing rules

- Ambiguous "send an email to X" → use `stanford` if X is a `.edu` address; otherwise `personal`.
- "Reply" → reply from the account that received the original.
- {{firstName}} explicitly names an alias → use that.

## Fallback

If Composio is down, fall back to gog (see [[Skills/connector-routing|connector-routing.md]]). gog must be installed separately; if it isn't, surface that to {{firstName}} rather than silently failing.
```

## 3.2 Append to today's daily note

```markdown
## Session: Gmail integration via Composio

Wired {{firstName}}'s Gmail accounts to {{agentName}} via Composio:

- **stanford** = `<email>` ✓
- **personal** = `<email>` ✓
- (etc)

Smoke-test passed for each: `is:unread` returned real subjects, {{firstName}} confirmed.

Routing documented at [[Memory/Preferences/email-routing|Memory/Preferences/email-routing.md]].

#auto-memory #composio #integration
```


# EVALS (≥3 — Library Standard requirement)

## S-1 (Structural): Connection roster matches what was asked

After Phase 1.5 finishes, the active Composio Gmail connection list should equal the (email, alias) pairs {{firstName}} requested. Verify:

```
COMPOSIO_MANAGE_CONNECTIONS({ toolkits: [{ name: "gmail", action: "list" }] })
```

PASS if the list of aliases matches what {{firstName}} asked for in 1.1.
FAIL if any expected alias is missing or any extra alias is present (likely from a stale connection).

## Sem-1 (Semantic): Smoke-test result reads accurate

In Phase 2, {{firstName}} confirmed the 3 unread subjects looked like their inbox.

PASS if {{firstName}}'s confirmation was unambiguous yes.
FAIL if they said "those don't look right" — re-do connection.

## B-1 (Behavioral): Vault docs are written and discoverable

After Phase 3, both files should exist and link to canonical structures:

```bash
test -f "$HOME/{{vaultDir}}/Memory/Preferences/email-routing.md" && echo "routing-doc: OK" || echo "routing-doc: MISSING"
grep -q "Composio" "$HOME/{{vaultDir}}/Memory/Daily/$(date +%Y-%m-%d).md" && echo "daily-log: OK" || echo "daily-log: MISSING"
```

PASS if both OK.
FAIL if either missing — write them now.


# AFTER YOU FINISH

Tell {{firstName}}:

> "Gmail is wired up. From here on out, just talk to me about email naturally — *'check my Stanford inbox for a syllabus update'*, *'draft a reply to that email Renee sent'*, *'forward this to myself'* — and I'll route to the right account.
>
> If you want to add another Gmail account later, just paste this prompt again and I'll add to the existing connections.
>
> If you ever want to disconnect or rotate access, you can do that from https://platform.composio.dev directly, OR ask me to do it via `COMPOSIO_MANAGE_CONNECTIONS`."


# DONE-OF-DONE CHECKLIST

- [ ] At least one active Gmail connection
- [ ] Smoke-test returned real inbox data
- [ ] {{firstName}} confirmed the inbox looked right
- [ ] `Memory/Preferences/email-routing.md` written
- [ ] Daily note updated with session block
- [ ] All 3 evals (S-1, Sem-1, B-1) pass
