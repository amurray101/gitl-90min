---
name: session-retitle
description: Atomic skill — retitles raw session-transcript files in Memory/Daily/sessions/ with content-derived slugs (replacing the Stop-hook's first-5-words guess), assigns topical tags drawn from the vault's color-coded taxonomy (wingen/swordpoint/academics/foundry/{{agent_name}}-infra/etc.), then writes a sessions: array of wikilinks into the matching Memory/Daily/<date>.md frontmatter. Restores bidirectional navigation and Obsidian graph color-coding for past conversations.
title: "Session Retitle — Slug Cleanup + Daily Backlinks"
type: skill
created: 2026-05-07
updated: 2026-05-07
tags: [skill, vault, sessions, automation, sleep, system, hooks]
trigger: "Nightly via /rem-cycle as Step 1.5 (between extract and embed); or manual /session-retitle"
---

# Session Retitle — Slug Cleanup + Topic Tags + Daily Backlinks

> The Stop-hook (`agent/scripts/session-capture-hook.sh` on macOS/Linux, `agent/scripts/session-capture-hook.ps1` on Windows) writes one transcript per conversation to `Memory/Daily/sessions/YYYY-MM-DD_HHMM_<slug>.md`. The slug is just kebab-cased first-5-words of the opening prompt — often a system caveat, a `/skill` invocation, or "hey", which makes the file unscannable later. The hook also seeds a baseline `tags: [session, transcript, daily-<date>]` block but no topical tags, so the session is invisible to Obsidian's color-coded graph filters. This skill is the overnight cleanup: read the actual transcript, retitle the file, assign topical tags from the vault taxonomy, then write the daily-side backlink so each `Memory/Daily/<date>.md` knows which conversations produced it.

Three navigation primitives get restored in one pass:
1. **Slug** — descriptive filename so `ls` and quick-open are scannable.
2. **Topical tags** — Obsidian renders frontmatter tags in the graph color-coded by {{user_name}}'s `colorGroups` config (`wingen` blue, `swordpoint` dark blue, `academics` orange, `foundry` purple, etc.), so each session lights up under the right domain filter.
3. **Daily ↔ session backlinks** — `sessions:` wikilink array in the daily's frontmatter; bidirectional pair with the existing `Daily:` link in the session body.

## Design rules

1. **Stop-hook is the only writer of session bodies; this skill only renames, tags, and adds backlinks.** Never deletes session files. Never edits transcript content. Touches filename, the session frontmatter (`retitled:` flag, topical tags merged into existing `tags:` list), and the daily-side `sessions:` array.
2. **Idempotent via `retitled: true`.** A session file is a candidate iff its frontmatter is missing `retitled` or has `retitled: false`. Renamed files are flagged and skipped on subsequent runs — no slug churn.
3. **Stable session_id, mutable filename.** The Stop-hook looks up existing session files by `session_id:` in frontmatter (line 174 of the hook), not by filename. So renaming is safe across future Stop fires — the next Stop on the same conversation finds the renamed file by ID and overwrites it under its new name.
4. **Cap at 50 renames per run.** The historical backlog (~414 files as of 2026-05-07) drains over ~9 nightly runs without burning cost in any single night. Future steady-state will be 1–10/night.
5. **Oldest-first.** Process the historical mess before today's noise. Keeps the recent-files view useful sooner.
6. **Slug shape: 3–6 words, kebab-case, ≤50 chars.** Lowercase a–z0–9 + hyphens. No leading/trailing dashes. Collisions get `-2`, `-3` suffixes (rare — date+HHMM+slug already triple-keys uniqueness).
7. **Tags drawn from canonical taxonomy, not open text.** The LLM picks 1–4 topical tags from the vetted list in §"Tag taxonomy" below. Picking from the list keeps Obsidian's color-group filters working and prevents tag explosion. If nothing fits, leave topical tags empty rather than invent one.
8. **Daily `sessions:` array is rebuilt from scratch each pass; `tags:` are merged.** For `sessions:`, list all `<date>_*.md` currently in `Memory/Daily/sessions/` and write that. Rebuild beats merge because session files get renamed — a stale wikilink to an old slug would orphan otherwise. Session files are exclusively Stop-hook-written, so there's no manual-add concern. For `tags:`, however, merge — never drop existing tags (Stop-hook baseline + any human additions), only union with the new ones from Step 2.
9. **Cron-safe.** No HITL prompts. Runs unattended.

## Procedure

### Step 0 — Setup

1. `today = YYYY-MM-DD` (system date, local timezone).
2. `sessions_dir = Memory/Daily/sessions/`.
3. `daily_dir = Memory/Daily/`.
4. `max_renames = 50` (override via env `SESSION_RETITLE_MAX` if set).
5. Initialize counters: `candidates_found`, `renamed`, `skipped`, `errors`, `daily_files_updated`.

### Step 1 — Find candidates

1. List all `*.md` under `sessions_dir`.
2. For each file: parse YAML frontmatter. Skip if frontmatter is missing or unparseable (log `FM_PARSE_ERROR` with path → `errors`).
3. A candidate is any file where `retitled` is absent OR `retitled: false`.
4. Sort candidates by filename ascending (date+time prefix → oldest first).
5. Cap to first `max_renames`.
6. If `candidates_found == 0`, jump to Step 4 (still rebuild daily backlinks for any date whose `sessions:` array is incomplete — see 4a).

### Step 2 — Generate descriptive slug + topical tags per candidate

For each candidate file:

1. Read the file body. The transcript follows a `## Conversation` heading.
2. Build the LLM input: the first user prompt (parsed from `**User:**` blocks) plus the first ~3 assistant text blocks plus (if length allows) the last assistant block. Cap input to ~4,000 chars. Head + a glimpse of tail is enough — the topic is established early; the tail catches "and we shipped X" outcomes.
3. Ask an LLM (Sonnet preferred; Haiku acceptable for cost) for a JSON object with two fields:
   ```json
   {"slug": "homer-sla-cutover-shipped", "tags": ["wingen", "homer", "swordpoint"]}
   ```
   **Slug constraints** (in the prompt):
   - Lowercase a–z, 0–9, hyphens only.
   - 3–6 words.
   - ≤50 chars total.
   - No `session-`, `chat-`, `convo-`, `discussion-` filler prefixes.
   - Capture the *outcome* or *topic*, not the opener (e.g. "homer-sla-cutover-shipped", not "ok-lets-debug-the-homer").

   **Tag constraints** (in the prompt):
   - 1–4 tags. Empty array allowed if nothing in the taxonomy fits.
   - Pick **only** from the canonical taxonomy (§"Tag taxonomy" below). Pass the list inline in the prompt so the LLM doesn't invent tags.
   - Prefer the most-specific applicable tag (e.g. `homer` over `swordpoint` if Homer-specific; both are fine when the session genuinely touches both).
   - Course tags (`stramgt-386`, `stramgt-351`, …) only if the session is class-specific, not for general academic chatter.

4. Parse the JSON. Validate:
   - Slug: regex `^[a-z0-9]+(-[a-z0-9]+){2,5}$` AND `len ≤ 50`.
   - Tags: each must be in the canonical taxonomy (case-sensitive); strip any not on the list (don't fail the whole file for one bad tag).
   If slug invalid, retry once with a stricter prompt; on second failure, skip this file (`skipped++`, log `SLUG_INVALID`). If JSON parse fails, retry once with a JSON-mode hint; second failure → skip.
5. If the new slug equals the old slug (modulo trim) **and** the tags are already a subset of existing frontmatter tags, flip `retitled: true` and skip both the rename and tag-write — nothing to do but mark it processed.

### Step 3 — Rename + tag + flag

For each candidate with a valid new slug:

1. Compute `new_path = sessions_dir/<date>_<HHMM>_<new-slug>.md`. Date+HHMM are read from the existing filename, NOT regenerated (preserves the original session start time).
2. Collision check: if `new_path` exists AND its `session_id` differs from this file's `session_id`, suffix `-2`, `-3`, … until unique.
3. **Update frontmatter first** (atomic: write to `<file>.tmp`, rename to `<file>`):
   - Set `retitled: true`.
   - Update `last_updated:` to `<today> <HH:MM> <TZ>`.
   - **Merge tags**: read existing `tags:` list (Stop-hook seeds `[session, transcript, daily-<date>]`); union with the new topical tags from Step 2; preserve order (existing first, then new). Never drop an existing tag.
4. **Then rename the file** on disk: `mv <old_path> <new_path>`.
5. Increment `renamed`. Record `(old_path, new_path, date)` for Step 4.

If either step errors, leave the file in whichever state it landed (frontmatter flag without rename is fine — next run will see `retitled: true` and skip; rename without flag is impossible since the flag is written first). Log `RENAME_ERROR` with path → `errors`.

### Step 4 — Daily backlinks

The "daily ↔ session" wikilink lives in `Memory/Daily/<date>.md` frontmatter as a `sessions:` list of wikilink strings.

#### 4a. Determine which daily files to rebuild

- **Always rebuild**: any daily date that had a rename in this run (collected in Step 3).
- **Catch-up rebuild (optional)**: if `SESSION_RETITLE_BACKFILL=1` is set, ALSO walk every date with files in `sessions_dir/` and ensure its daily's `sessions:` array is comprehensive. Default: skip catch-up (incremental safer).

#### 4b. For each target date

1. Read `Memory/Daily/<date>.md`. If it doesn't exist, log `DAILY_MISSING` and skip (don't create — that's not this skill's job).
2. List all `<date>_*.md` files currently in `sessions_dir/` for that date (after the renames in Step 3).
3. Build `wanted_links` = the wikilink string for each, sorted by filename (= chronological since filenames lead with date+HHMM): `"[[Memory/Daily/sessions/<basename-without-ext>]]"`.
4. Parse the daily's frontmatter. **Rebuild `sessions:` from `wanted_links` (do not merge).** Rename-driven: a stale wikilink to an old slug would orphan, so always rewrite from the current state of disk. Acceptable because session files are exclusively Stop-hook-written; there's no manual-add concern.
5. If the rebuilt array differs from the existing one, write it back into frontmatter. Atomic: tmp + rename. **Do not touch the body.**
6. Increment `daily_files_updated`.

#### 4c. Frontmatter shape

Daily file (`Memory/Daily/2026-05-06.md`):

```yaml
---
title: "2026-05-06"
type: daily
tags: [daily]
extracted: true
extracted_to:
  - "[[Swordpoint/WinGen/Logs/...]]"
  - "..."
sessions:
  - "[[Memory/Daily/sessions/2026-05-06_1300_homer-sla-cutover-shipped]]"
  - "[[Memory/Daily/sessions/2026-05-06_2200_comp-paint-v13-to-v27]]"
---
```

Session file (after retitle):

```yaml
---
title: "2026-05-06 13:00 — homer sla cutover shipped"
type: session-transcript
date: 2026-05-06
time: "13:00"
session_id: "abc-123-..."
tags: [session, transcript, daily-2026-05-06, wingen, homer, swordpoint]
retitled: true
...
---
```

`sessions:` slots in alongside `extracted_to:` (existing convention). Order: alphabetical = chronological because filenames lead with date+HHMM. Topical tags append after the Stop-hook's baseline `[session, transcript, daily-<date>]`.

### Step 4.5 — Tag taxonomy

The LLM in Step 2 picks topical tags **only from this list**. Sourced from `.obsidian/graph.json` (color-coded groups, marked ★) plus high-frequency vault tags that route domain content. Update this list when {{user_name}} adds a new color group or a new domain.

**Domain tags (color-coded ★):**
- `wingen` ★ — WinGen ops (HD, HVAC, Homer, Carrier as customer)
- `swordpoint` ★ — Swordpoint HoldCo level (cross-portfolio, comp, board)
- `academics` ★ — Stanford GSB schoolwork, broadly
- `stanford` ★ — Stanford-the-place (admin, social, beyond just classes)
- `{{agent_name}}-infra` ★ — {{agent_name}}'s own systems (skills, hooks, vault, cron, hippocampus)
- `foundry` ★ — Foundry agent-onboarding practice + portal
- `dartmouth` ★ — Dartmouth context
- `mckinsey` ★ — McKinsey-era context
- `friends-seminary` ★ — Friends Seminary (school)
- `rodeph` ★ — Rodeph context
- `suck-down` ★ — McGovern's wider social network
- `weekly` ★ — weekly-cadence content
- `daily` ★ — daily-cadence content (rarely needed on sessions; Stop-hook handles)

**Sub-domain tags (high-frequency, not color-coded but useful):**
- `journey` — Journey (Swordpoint sub)
- `homer` — Homer product (WinGen sub)
- `home-depot` / `carrier` — specific accounts
- `raci` — RACI/Staci product
- `infrastructure` — vault/system architecture work (often pairs with `{{agent_name}}-infra`)
- `architecture` — when the session is about system design

**Course tags (use only when class-specific):**
- `stramgt-386` · `stramgt-351` · `stramgt-329` · `stramgt-543` · `stramgt-221`
- `oit-277` · `mgtecon-583` · `390` (AI Search)

**People tags:** skip — `tags:` is for topics, not people. People surface through `Memory/People/*.md` wikilinks, which extract handles.

**Type tags already seeded by Stop-hook** (don't re-emit):
- `session` · `transcript` · `daily-<date>`

**Decision rules for the LLM:**
- Most sessions get 1–3 tags total (after Stop-hook baseline).
- Prefer specific over general (`homer` over `wingen` over `swordpoint` when the session is Homer-specific; pick all three only if the session genuinely spans levels).
- If unsure, fewer tags. Empty array is allowed.
- Pure-coding sessions in non-vault repos may legitimately have zero topical tags — tag them only if a domain anchor is clear.

### Step 5 — Report back to /rem-cycle

Return a summary structure:

```yaml
status: ok
candidates_found: <int>
renamed: <int>
tagged: <int>              # sessions that received >=1 topical tag
tag_frequency:             # tag → count for this run; helps spot taxonomy drift
  wingen: <int>
  homer: <int>
  ...
skipped: <int>
errors: <int>
daily_files_updated: <int>
backlog_remaining: <int>   # files in sessions_dir still without retitled:true after this run
sample_renames:            # up to 5 for the rem-cycle report
  - "<old_basename> → <new_basename> [tags: wingen, homer]"
  - ...
```

The `backlog_remaining` field tells future-{{user_name}} how many nights of cleanup are left. The `tag_frequency` map is the early-warning for taxonomy drift — if a non-canonical tag shows up, the LLM is hallucinating; tighten the prompt or expand the canonical list.

## What this skill does

- Renames session-transcript files in `Memory/Daily/sessions/` with content-derived slugs.
- Assigns 1–4 topical tags from the canonical taxonomy (color-coded domain tags + sub-domain + course tags).
- Sets `retitled: true` in their frontmatter so they aren't reprocessed.
- Adds/merges a `sessions:` array of wikilinks into `Memory/Daily/<date>.md` frontmatter for each affected date.
- Reports renamed count + tag frequency + backlog-remaining to `/rem-cycle` for the morning report.

## What this skill does NOT do

- Does not delete files (never-delete-files rule).
- Does not edit transcript bodies — only frontmatter (`retitled:`, `last_updated:`, `tags:` merge).
- Does not invent tags outside the canonical taxonomy.
- Does not create `Memory/Daily/<date>.md` files that don't exist.
- Does not touch the daily body (no inline wikilinks on `### Session:` headers — that's the extract skill's job if ever wanted; out of scope here).
- Does not send messages or external API calls beyond the LLM slug+tag generation calls.
- Does not retry failed LLM responses more than once per run (the retry happens within Step 2; subsequent failures wait for next night).

## Failure modes

- **Frontmatter parse error on session file** — skip that file, log to errors, continue. The Stop-hook will overwrite the file's frontmatter on the next Stop fire on that conversation, which often self-heals the YAML.
- **LLM unavailable** — abort gracefully. Status = `failed`. rem-cycle queues `rem-cycle: session-retitle failed`. Files are untouched; next night retries.
- **Slug invalid after retry** — skip that file (counted in `skipped`), continue. Backlog drains slower but doesn't get blocked by one bad transcript.
- **Daily file missing** — log, skip backlink update for that date. The session file itself is still renamed.
- **Disk-full on rename** — leave file in place; log; continue. Next run retries.

## Coexistence with the Stop-hook

- **Stop-hook owns creation + body content + the initial slug guess.** It writes the file under its first-pass slug at the moment of stop.
- **session-retitle owns the post-hoc cleanup.** Renames the file, sets `retitled: true`, ensures the daily knows about it.
- **No race condition**: if a Stop fire lands on a renamed file mid-rem-cycle, the hook re-finds it by `session_id` (frontmatter, not filename) and overwrites the body under the renamed filename. The `retitled: true` flag survives because the hook does not write that field — it preserves frontmatter it doesn't manage.

Wait — actually the hook *does* fully rewrite frontmatter on every Stop fire (see `session-capture-hook.sh` / `session-capture-hook.ps1`). It does not preserve `retitled: true`. **This is a bug to fix in a follow-up**: either (a) make both hook implementations merge frontmatter rather than overwrite, or (b) make this skill check the timestamp delta and skip files written within the last hour. For v1, accept the imperfection: a Stop fire that lands during rem-cycle will undo `retitled: true` for that one file, which then gets re-renamed next night under (likely) the same slug. Cost is negligible.

## Related skills

- [[Skills/rem-cycle/SKILL|REM Cycle]] — calls this as Step 1.5, between extract (Step 1) and embed (Step 2). Embed indexes the renamed paths.
- [[Skills/extraction/SKILL|Extract]] — Step 1 of rem-cycle; reads `Memory/Daily/<date>.md` files, writes `extracted_to:` frontmatter. `sessions:` lives alongside `extracted_to:` and follows the same wikilink-array convention.
- [[Skills/hippo-refresh/SKILL|Hippo Refresh]] — Step 5 of rem-cycle; Hippocampus references daily files but not session files directly. No interaction.
- [[Skills/spider/SKILL|Spider]] — Step 3 of rem-cycle; orphan-resolves wikilinks. Will register the new `sessions:` links in graph state.
- Stop-hook at `agent/scripts/session-capture-hook.sh` or `agent/scripts/session-capture-hook.ps1` — creates the session files this skill renames.
