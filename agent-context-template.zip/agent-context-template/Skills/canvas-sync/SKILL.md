---
name: canvas-sync
description: Sync active Canvas LMS courses (Stanford or any institution) into the vault's Academics/ folder. Walks user through generating a Personal Access Token, persists it to agent/secrets/canvas.token, fetches courses via agent/scripts/canvas.py, scaffolds Academics/<course-slug>/ per course with index, Logs/, and Prep/ subdirectories. Usable standalone post-onboarding to add courses mid-quarter.
---

# /canvas-sync — Pull active Canvas courses into the vault

> Stanford uses Canvas at `canvas.stanford.edu`. Other institutions: replace base URL in `agent/scripts/canvas.py`. Authentication is via a user-generated Personal Access Token (no admin OAuth approval needed).

## Usage

```
/canvas-sync
```

No arguments. First-run prompts for the token; subsequent runs reuse the persisted token.

## PRE-CHECKS

1. **`school` is in `answers.yaml.domains`** (if `_seed/answers.yaml` exists). If not, abort with: *"Canvas sync only fires for student vaults. Re-run /hatch with `school` in your domains, or skip this skill."*
2. **`agent/scripts/canvas.py` exists.**
3. **`python3` available** in PATH. (`which python3` returns a path.)
4. **`Academics/` folder exists** (scaffolded by /hatch). If not, create it.

## WORK PHASES

### Phase 1 — Token acquisition

Check `agent/secrets/canvas.token` exists.

**If yes:** read it, validate by hitting `GET /api/v1/users/self` — if 200, proceed to Phase 2. If 401, token expired; treat as "no token" below.

**If no:** walk the user through generation:

```
To pull your courses, I need a Canvas Personal Access Token. This is generated in your Canvas account (no Stanford admin approval needed).

1. Open https://canvas.stanford.edu/ (or your school's Canvas) in your browser, log in.
2. Click your avatar → Account → Settings.
3. Scroll to "Approved Integrations" → click "+ New Access Token".
4. Purpose: "Foundry agent". Expires: 90 days from now (re-run /canvas-sync to refresh).
5. Click "Generate Token" → copy it.
6. Paste it here when ready.
```

Wait for user reply with the token. Persist:

```bash
mkdir -p agent/secrets
echo "<token>" > agent/secrets/canvas.token
chmod 600 agent/secrets/canvas.token
```

(Confirm `agent/secrets/` is in `.gitignore`. Should be from template.)

### Phase 2 — Fetch active courses

Run:
```bash
python3 agent/scripts/canvas.py --list-active-courses --token-file agent/secrets/canvas.token
```

Expected output: JSON array of `{id, name, course_code, term, instructor}` objects. (Or whatever shape `canvas.py` returns — adapt the SKILL.md if the script's interface differs.)

If the script doesn't have a `--list-active-courses` flag (it was lifted from 9ton's vault and may use a different invocation), read the script and adapt accordingly. Common options: `--list`, `--courses`, default behavior.

### Phase 3 — Scaffold per-course folders

For each active course, create:

```
Academics/<course-slug>/
├── 0-<course-slug>-index.md       # course title, instructor, meeting time, Canvas URL, syllabus link
├── Logs/
│   └── 0-logs-index.md
└── Prep/
    └── 0-prep-index.md
```

`<course-slug>` = lowercase + hyphenated course_code (e.g. `STRAMGT 386` → `stramgt-386`).

Each `0-<slug>-index.md` should include frontmatter:

```yaml
---
title: <Course Name>
type: course
course_code: <code>
term: <term>
canvas_id: <id>
instructor: <name>
canvas_url: https://canvas.stanford.edu/courses/<id>
tags: [academics, course, <slug>]
created: <ISO date>
---
```

Plus a body section pre-populated with: the official course description (if obtainable from Canvas's `/courses/:id/syllabus` endpoint), the meeting time/location, and a "Recent activity" header that future skills can append to.

### Phase 4 — Verify + report

Count: `find Academics -type d -name "0-*-index.md"` should match the number of active courses returned in Phase 2.

Print:

```
✓ Canvas sync complete.
  Found <N> active courses → scaffolded Academics/<course>/ for each:
    • <course-1>
    • <course-2>
    • ...

Token saved to agent/secrets/canvas.token (gitignored, expires <date>).
```

## EVALS

1. **Token file exists + chmod 600.**
2. **One Academics/<slug>/ per active course.** N folders match N courses returned.
3. **Each course folder has `0-<slug>-index.md`** with valid frontmatter (parseable YAML).
4. **`agent/secrets/` is gitignored** (`grep "agent/secrets" .gitignore` returns a hit).

## DEFINITION OF DONE

User opens one `Academics/<course>/0-<course-slug>-index.md` and sees real course data. They can now use `/class-prep` (if installed), `/handoff`, etc., scoped to that course.

## AFTER YOU FINISH

Suggest: *"Want me to fetch this term's assignments + due dates next? Run `/canvas-assignments`."* (Defer if /canvas-assignments not yet installed — for v1 we just scaffold the course shells.)
