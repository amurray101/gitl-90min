---
title: "Skills"
type: context
tags: [skills, procedures, index, skill]
---

# Skills — Reusable Procedures

> **Rule: Check skills FIRST before executing any procedure.**

## Core Skills

- **[[Skills/search/SKILL|Search]]** — `/search` - Tiered vault search: Radar → wikilinks → keywords → calendar/email → web
- **[[Skills/session-handoff/SKILL|Session Handoff]]** — `/handoff` - Archive session, update Radar, prepare next session
- **[[Skills/radar-verify/SKILL|Radar Verify]]** — `/radar-verify` - Probe each Radar item's `✓ Done when:` clause, auto-clear HIGH-confidence items so HQ Collect XP can release; called by `/handoff` as Step 1.5
- **[[Skills/extraction/SKILL|Extraction]]** — Extract and consolidate knowledge from daily notes  
- **[[Skills/send-email/SKILL|Send Email]]** — `/email` - Compose and send emails via gog
- **[[Skills/extraction/SKILL|Extraction (Librarian)]]** — `/extract` - Route knowledge from Daily notes and meeting files into structured vault locations (People, Logs, Lessons, Preferences, Radar)
- **[[Skills/spider/SKILL|Spider]]** — `/spider` - Graph audit: link discovery, tag enrichment, orphan resolution, index file freshness
- **[[Skills/swarm/SKILL|Swarm]]** — Parallel subagent coordination for complex tasks

## Academic Skills

- **[[Skills/prep-sweep/SKILL|Prep Sweep]]** — `/prep-sweep` - Daily academic prep check (Canvas + calendar + Radar update)
- **[[Skills/academic-pipeline/0-academic-pipeline-index|Academic Pipeline]]** — `/assignment` - Full assignment completion workflow
- **[[Skills/academic-writing/SKILL|Academic Writing]]** — Writing protocol and style guide
- **[[Skills/class-prep/SKILL|Class Prep]]** — `/class-prep` - Session prep pipeline (scan modules → gather → draft → vault → PDF → Cardinal Print → Telegram)
- **[[Skills/cardinal-print/SKILL|Cardinal Print]]** — `/cardinal-print` - Send a PDF to Stanford's Cardinal Print queue via email submission. Auto-fired by `/class-prep` and `/assignment` (format step). Adds 48h pickup reminder to Radar.

## Development Skills  

- **[[Skills/coding-protocol/SKILL|Coding Protocol]]** — Development workflow and standards
- **[[Skills/feature-pipeline/0-feature-pipeline-index|Feature Pipeline]]** — `/feature` - Full feature development workflow (intake → research → spec → implement → verify → integrate → ship)
- **[[Skills/devlog/SKILL|Devlog]]** — `/devlog` - Append a dated entry to the current repo's `docs/DEVLOG.md` (context, changes, why, tradeoffs, open items). Repo-local memory — does NOT touch the vault.
- **[[Skills/auto-dream/SKILL|Auto Dream]]** — Automated ideation and concept development
- **[[Skills/bulk-extract/SKILL|Bulk Extract]]** — Batch processing and data extraction

## Finance Skills

- **[[Skills/invoice/SKILL|Invoice]]** — `/invoice` - Interactive invoice generation (calendar → review → expenses → markdown + PDF)

## Visualization Skills

- **[[Skills/paint-the-picture/SKILL|Paint the Picture]]** — `/paint-the-picture <description>` - Spin up a live localhost UI for whatever's in session context (tables, kanban, networks, dashboards). Iterate by talking; the browser auto-reloads. Each paint becomes a vault artifact at `Workbench/paint/<slug>/` with wikilinks to source entities.
- **[[Skills/paint-the-canvas/SKILL|Paint the Canvas]]** — `/paint-the-canvas` — Specialized variant of paint-the-picture: live academic dashboard rendered from synced Canvas LMS data (courses, assignments, deadlines, readings, announcements). Designed as the wow-moment finale of any GSB Foundry onboarding; reusable as the ongoing academic cockpit.

## Communication Skills

- **[[Skills/draft-email/SKILL|Draft Email]]** — Create Gmail drafts via `gog gmail drafts create`
- **[[Skills/sweep-imessage/SKILL|iMessage Sweep]]** — `/sweep-imessage` - Triage unreads + unresponded texts, enrich people graph, propose Radar/calendar/reply actions (approval-gated)
- **[[Skills/sweep-whatsapp/SKILL|WhatsApp Sweep]]** — `/sweep-whatsapp` - Triage WhatsApp state (unreads, unresponded threads), enrich people graph, propose Radar/calendar/reply actions. Never sends without approval.
- **[[Skills/swordpoint-sweep/SKILL|Swordpoint Sweep]]** — `/swordpoint-sweep` - Work-life parallel to /prep-sweep. Reconciles six Swordpoint surfaces (Outlook, Gmail, iMessage, DEVLOGs, Granola, calendar) into Radar + People notes. Tier 2 + 3 auto-apply; Tier 1 + 4 print to chat.

## Integration Skills

- **[[Skills/granola-sync/SKILL|Granola Sync]]** — `/granola-sync` - Sync Granola meetings into vault with domain routing
- **[[Skills/stanford-calendar-sync/SKILL|Stanford Calendar Sync]]** — Mirror Stanford calendar busy blocks to SwordPoint Outlook via Composio (runs nightly at 3:30am)

## System Skills

- **[[agent/automations|Automations]]** — Scheduled jobs and the self-healing vault
- **[[Skills/rem-cycle/SKILL|REM Cycle]]** — `/rem-cycle` - Master nightly orchestrator. Runs [[Skills/extraction/SKILL|extract]] → [[Skills/session-retitle/SKILL|session-retitle]] → embed → [[Skills/spider/SKILL|spider]] → [[Skills/radar-verify/SKILL|radar-verify]] → [[Skills/hippo-refresh/SKILL|hippo-refresh]] in sequence, then frontmatter audit / Radar staleness / weekly cadence diagnostics, into one morning report + Radar items. Runs 4:00am via launchd on macOS or Task Scheduler on Windows.
- **[[Skills/hippo-refresh/SKILL|Hippo Refresh]]** — `/hippo-refresh` - Atomic skill, called by `/rem-cycle` as Step 5. Rewrites `Memory/Hippocampus.md` Now block from last 3 days of Daily/ + current Radar; rewrites Arc if ≥48h stale; prunes items that no longer have an upstream referent. The morning-fresh working-memory step.
- **[[Skills/session-retitle/SKILL|Session Retitle]]** — `/session-retitle` - Atomic skill, called by `/rem-cycle` as Step 1.5. Retitles raw session transcripts in `Memory/Daily/sessions/` with content-derived slugs (replacing the Stop-hook's first-5-words guess), assigns topical tags from the vault's color-coded taxonomy (wingen/swordpoint/foundry/academics/{{agent_name}}-infra/…), then writes a `sessions:` array of wikilinks into the matching `Memory/Daily/<date>.md` frontmatter. Bidirectional daily ↔ session navigation + Obsidian graph color-coding.
- **[[Skills/frontmatter-audit/SKILL|Frontmatter Audit]]** — `/frontmatter-audit` - Read-only walker over the vault that reports frontmatter drift (missing blocks, missing tags, malformed YAML, dead `updated:` dates). Stdlib-only Python; composed by `/rem-cycle`.
- **[[Skills/guardrails/SKILL|Guardrails]]** — Safety protocols and error handling

## Subagents

- **[[Skills/subagents/0-subagents-index|Subagents]]** — Specialized AI agents for specific domains
- **[[Archive/Skills/subagents/strategic-overview/PROMPT|Strategic Overview Agent]]** — Dashboard overview generator prompt *(archived)*
