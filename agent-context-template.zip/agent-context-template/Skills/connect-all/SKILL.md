---
name: connect-all
description: Orchestrate every connector the user picked in the portal — Gmail+Calendar OAuth, Granola sync (if installed), Canvas Personal Access Token (if school+canvas selected), iMessage/WhatsApp deferred. Then fires /lookback to mine the freshly-connected sources, populating Memory/People/* with real interaction history, themes, and voice samples. Run AFTER /hatch.
---

# /connect-all — Wire connectors + mine data

> One command runs the full enrichment chain: connect → mine → enrich. End state: Memory/People/* has real data, Memory/Connectors/* has status per source.

## Usage

```
/connect-all
```

No arguments. Reads `_seed/connectors-plan.md` for the plan.

## PRE-CHECKS

1. **Vault is hatched.** `Memory/Hippocampus.md` exists and contains no `{{}}` placeholders. If not → "Run `/hatch <agent-name>` first."
2. **Connectors plan present.** `_seed/connectors-plan.md` exists and is parseable. If not → abort.
3. **Memory/Connectors/ exists.** Create if not.

## WORK PHASES

### Phase 1 — Read the plan

Read `_seed/connectors-plan.md`. Extract the ordered list of connectors with their `enabled: true|false` status. Expected connectors: `gmail`, `calendar`, `granola`, `canvas`, `imessage`, `whatsapp`. Anything else → log + skip.

### Phase 2 — Walk each connector in order

For each enabled connector, run its setup, then write `Memory/Connectors/<name>.md` with:

```yaml
---
title: <name>
type: connector
status: <ok | deferred | error>
configured_at: <ISO date>
tags: [connector, <name>]
---
```

Plus a body: how it was wired, what scopes/permissions granted, troubleshooting notes.

#### Gmail + Calendar (joined OAuth — same Google account)

If `gmail: true` OR `calendar: true`: invoke the `/gmail-connect` skill, which defaults to **Composio** (hosted-OAuth — no Google Cloud project required). The flow:

1. Verify Composio MCP is loaded (`COMPOSIO_SEARCH_TOOLS` reachable). If not, halt and tell the user to complete Phase 1 connectors at `https://foundry.9ton.io/<slug>` first.
2. For each Gmail account in `answers.yaml.accounts.gmail`: call `COMPOSIO_MANAGE_CONNECTIONS({ toolkits: [{ name: 'gmail', action: 'add', alias: '<alias>' }] })`. Surface the `redirect_url` as a clickable link, then `COMPOSIO_WAIT_FOR_CONNECTIONS` until ACTIVE.
3. Smoke-test: `GMAIL_FETCH_EMAILS({ query: 'is:unread', max_results: 3 })`. Confirm with user that the inbox looks right.
4. Same flow for Calendar (Composio handles Google Calendar via the same connection — usually no separate auth needed).

**Fallback (if user opted out of Composio):** see `prompts/integrations/gmail-gog-advanced.md` for the manual gog setup. That path requires creating a Google Cloud project and is documented as friction-y on purpose. Tell the user to ping Eitan if they're stuck on the gog path.

On success: write `Memory/Connectors/gmail.md` and `Memory/Connectors/calendar.md` with status `ok` + connection mode (`composio` or `gog`) + alias(es) granted. On failure: status `error` + the error message.

#### Granola (local desktop)

If `granola: true`: check `/Applications/Granola.app` exists.
- If yes: invoke `/granola-sync` to read the local cache and pull recent meeting transcripts into `Memory/Meetings/`. Write `Memory/Connectors/granola.md` status `ok`.
- If no: write `Memory/Connectors/granola.md` status `deferred` with note "Install Granola desktop from granola.ai then re-run /granola-sync. The connector will read from ~/Library/Application Support/Granola/."

#### Canvas (Stanford LMS, conditional)

If `canvas: true` AND `school` is in `answers.yaml.domains`: invoke `/canvas-sync`. The canvas-sync skill prompts for a Personal Access Token, persists it to `agent/secrets/canvas.token` (gitignored), then runs `agent/scripts/canvas.py` to fetch active courses and scaffold `Academics/<course>/` per course.

Edge case: if `canvas: true` but `school` NOT in domains, log warning + skip. (User shouldn't have been able to select Canvas without school in the portal, but be defensive.)

#### iMessage / WhatsApp (deferred for v1)

If selected: write `Memory/Connectors/<name>.md` status `deferred` with note "High-friction local setup (Full Disk Access for iMessage; MCP for WhatsApp). Will guide you through post-seminar via dedicated /sweep-imessage and /sweep-whatsapp skills."

### Phase 3 — Fire `/lookback`

Once all `ok` connectors are wired, invoke `/lookback`. The lookback skill:
- Mines Gmail (window from `answers.yaml.lookback.window_days`, default 60)
- Mines Calendar events from same window
- Reads Granola transcripts (if status ok)
- Reads Canvas course rosters (if status ok)
- Clusters threads, infers themes, samples voice
- **Enriches each `Memory/People/<slug>.md`** with frequency stats, last-interaction date, voice samples
- **Surfaces NEW people** not in `answers.yaml.people` but discovered via volume — writes proposals to `Memory/Lessons/lookback-candidates.md`

### Phase 4 — Validation report

Print a status summary to chat:

```
Connectors:
  ✓ Gmail · 4,233 messages indexed (60d window)
  ✓ Calendar · 188 events
  ↷ Granola · deferred (app not installed)
  ✓ Canvas · 5 active courses → Academics/* scaffolded
  ↷ iMessage · deferred (post-seminar)

Lookback:
  • Enriched 5 People stubs with real frequency + voice samples
  • Surfaced 12 new people candidates → Memory/Lessons/lookback-candidates.md
  • Inferred 6 themes (work, family, school, hobby)
  • Voice samples: 10 representative excerpts saved to agent/Soul.md
```

Then prompt: *"Run /rem-cycle next to consolidate everything into Hippocampus and freshen the graph. Then open Obsidian and watch your vault come alive."*

## EVALS

1. **Each enabled connector has a Memory/Connectors/<name>.md** with `status:` field set to `ok`, `deferred`, or `error`.
2. **At least one `ok` connector OR explicit error** — if all connectors are `deferred`, that's a configuration smell; surface it.
3. **Memory/People/ files updated post-lookback.** At least one `*.md` in Memory/People/ has a non-empty "Recent interactions" section (or other enrichment) after Phase 3.
4. **For Stanford-cohort runs** (school + canvas): `Academics/<course>/0-<course-slug>-index.md` exists for each active Canvas course.

## DEFINITION OF DONE

User sees the validation report AND can verify enriched People/* + scaffolded Academics/* (if applicable). The vault has gone from "stubs and structure" to "living graph with real data."

## AFTER YOU FINISH

Print: *"Run `/rem-cycle` to consolidate. Then open this vault in Obsidian (`obsidian:vault-folder`) and toggle Graph View — that's your brain."*
