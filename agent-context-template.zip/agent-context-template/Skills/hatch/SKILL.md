---
name: hatch
description: Personalize a freshly-cloned foundry-template vault from a seed bundle. Reads _seed/{answers.yaml, connectors-plan.md, essay.md, eitan-notes.md}, stamps identity files (Soul/Mind/Identity/Hippocampus/CLAUDE.md/AGENTS.md), seeds Memory/People/, scaffolds domain folders, wires session-capture hooks for the active harness, then introduces itself in voice with real essay + relational context. The first slash command anyone runs in their new vault.
---

# /hatch — Birth a personalized agent from the seed bundle

> Run once on day zero. Reads `_seed/`, makes the vault yours, and ends with the agent's first words.

## Usage

```
/hatch <agent-name>
```

The `<agent-name>` argument is for confirmation — it should match `_seed/answers.yaml.agent_name`. If they differ, abort and ask the user which is correct.

## PRE-CHECKS (must all pass before WORK PHASES)

1. **Seed bundle present:** `_seed/answers.yaml` exists and is valid YAML. If not → abort with "Drop your seed bundle into `_seed/` first. The portal generates one at the end of P1."
2. **Bundle completeness:** `_seed/connectors-plan.md` exists. (essay.md and eitan-notes.md are optional but logged if missing.)
3. **Identity name match:** `<agent-name>` argument equals `answers.yaml.agent_name`. If not → confirm with user before proceeding.
4. **Vault root sanity:** confirm we're in the foundry-template structure — verify `agent/Soul.md`, `agent/Mind.md`, `agent/Identity.md` exist as templated files containing `{{agent_name}}` placeholder. If they don't, this isn't a fresh template — abort.
5. **Not already hatched:** check that `Memory/Hippocampus.md` still contains `{{hatch_date}}` placeholder. If not, the vault has been hatched before — confirm with user before re-running (re-hatch will overwrite identity files).

## WORK PHASES

### Phase 1 — Read the seed bundle

Read all 4 files into context:
- `_seed/answers.yaml` — parse as YAML.
- `_seed/connectors-plan.md` — read raw markdown.
- `_seed/essay.md` — read raw text (may be empty).
- `_seed/eitan-notes.md` — read raw text (may be empty).

### Phase 2 — Stamp identity files

For each templated file, substitute `{{placeholder}}` tokens with values from `answers.yaml`. Use Edit (not Write) so unrelated content is preserved.

Files to stamp + the placeholders each owns:

| File | Placeholders to substitute |
|---|---|
| `CLAUDE.md` | `{{agent_name}}`, `{{user_name}}`, `{{vault_dir}}` |
| `AGENTS.md` | `{{agent_name}}`, `{{user_name}}`, `{{vault_dir}}` |
| `agent/Soul.md` | `{{agent_name}}`, `{{agent_name_lower}}`, `{{user_name}}`. **Voice + Bond now ship as 0–100 sliders**, not named pills. Read `answers.yaml.voice.{register, emoji, honorifics, default_length}` (numeric values + matching `_label` fields) AND `answers.yaml.bond.{role, agreement, initiative, truth}`. Use the `_label` ("lean casual", "firmly contrarian", etc.) for human-readable text + the numeric for nuance. **Generate a "## Voice" section** that translates the labels into prose ("I write casual, with structure when stakes are high. Skip honorifics. Default to short replies unless asked for depth."). **Generate a "## Bond" section** describing the role/agreement/initiative/truth axes the user picked. Also append `answers.yaml.voice.personality_freeform` verbatim into a "## Personality" subsection (the user's own paragraph painting their agent). Append `answers.yaml.focus_projects` into a "## Current Projects" section. |
| `agent/Mind.md` | Read `answers.yaml.mind.{pushback, devil_advocate, premortem}` (numeric sliders + `_label` fields). Mind.md ships with the canonical 11 reasoning moves; **don't replace those** — append a new "## User-tuned reasoning style" section at the bottom that names the user's slider positions in plain prose ("Pushback: lean assertive — name disagreements directly. Devil's advocate: balanced — fire on big asks, not small. Premortem: balanced — run on big asks before plans ship."). Then append `answers.yaml.mind.freeform` verbatim if non-empty. If both are empty/default, skip the section. |
| `agent/Identity.md` | `{{agent_name}}`, `{{agent_name_lower}}`, `{{agent_pronouns}}`, `{{user_name}}`, `{{voice_register}}`, `{{name_origin}}`, `{{logo_concept}}`, `{{primary_color}}`, `{{voice_provider}}`, `{{voice_id}}`, `{{voice_accent}}`, `{{evolution_phase_zero}}` (write today's date + a one-line origin summary) |
| `Memory/Hippocampus.md` | `{{agent_name}}`, `{{user_name}}`, `{{hatch_date}}` (today's ISO date) |

For any placeholder where `answers.yaml` doesn't have a value, write a sensible default and note it in the post-hatch report (Phase 7).

### Phase 3 — Seed Memory/People/*

`answers.yaml.people` is a flat list of `{name, why}` entries (no buckets). For each entry, create one file at `Memory/People/<slug>.md`:

```markdown
---
title: <Full Name>
type: person
why: "<the why text from answers.yaml>"
tags: [people]
created: <hatch_date>
---

# <Full Name>

> Stub created by /hatch from `_seed/answers.yaml`. Will be enriched by /lookback when {{user_name}} runs the connector chain.

## Why they matter

<the `why` field from answers.yaml — e.g. "wife", "daughter (5)", "McKinsey co-founder", "old college roommate">

## Recent interactions

(Empty — populate via /lookback.)
```

Slugify names: lowercase, hyphenate spaces, strip punctuation. e.g., `Elizabeth McGovern` → `elizabeth-mcgovern`. If `people:` is empty in the seed, skip Phase 3 entirely (leave `Memory/People/` as-is).

### Phase 4 — Scaffold domain folders per `answers.yaml.domains`

Preset domain → folder mapping:

| Domain key | Folder name |
|---|---|
| `work` | `Work/` |
| `family` | `Family/` |
| `school` | `Academics/` |
| `hobby` | `Hobbies/` |
| `finance` | `Finance/` |
| `personal` | `Personal/` |

**Custom domains** are also supported. Anything in `domains:` not in the preset list is treated as a custom domain — convert it to TitleCase + slug for the folder name (e.g. `consulting` → `Consulting/`; `side-projects` → `Side-Projects/`). In the index file's body, note "(custom domain — created from your seed selection)" so it's clear this wasn't a preset.

For each domain in `answers.yaml.domains`:
1. Create `<DomainFolder>/` if it doesn't exist.
2. Create `<DomainFolder>/0-<slug>-index.md` with frontmatter (`tags: [<slug>]`) and a one-paragraph stub describing what this domain holds. For preset domains use the canonical description; for custom domains use a generic stub.
3. Create `<DomainFolder>/Logs/` directory (`.gitkeep` inside) for arc/log entries.

If `domains` is empty or missing in answers.yaml, skip Phase 4 and note in the report.

### Phase 5 — Wire session-capture hooks

Detect both the operating system and active harness before writing hook config:

```bash
node -e "console.log(process.platform)"
```

Use these rules:

1. If running in Codex, register the Stop hook in `~/.codex/hooks.json`.
2. If running in Claude Code, register the Stop hook in `.claude/settings.json`.
3. If uncertain, write both registrations. Session capture is load-bearing; duplicate inert config is better than a silent memory gap.
4. Never overwrite unrelated existing hook entries. Merge idempotently by checking for the exact hook command first.

If the OS output is `win32`, use the Windows command. Otherwise use the macOS/Linux command.

#### macOS / Linux branch

Claude Code project hook command:

```json
{
  "hooks": {
    "Stop": [
      {
        "matcher": "",
        "hooks": [
          {
            "type": "command",
            "command": "agent/scripts/session-capture-hook.sh",
            "timeout": 30,
            "statusMessage": "Capturing session to daily log..."
          }
        ]
      }
    ]
  }
}
```

Codex global hook command:

```json
{
  "hooks": {
    "Stop": [
      {
        "matcher": "",
        "hooks": [
          {
            "type": "command",
            "command": "<absolute path to vault>/agent/scripts/session-capture-hook.sh",
            "timeout": 30,
            "statusMessage": "Capturing session to daily log..."
          }
        ]
      }
    ]
  }
}
```

After writing, verify `agent/scripts/session-capture-hook.sh` exists and is executable. If needed:

```bash
chmod +x agent/scripts/session-capture-hook.sh
```

#### Windows branch

Claude Code project hook command:

```json
{
  "hooks": {
    "Stop": [
      {
        "matcher": "",
        "hooks": [
          {
            "type": "command",
            "command": "powershell.exe -NoProfile -ExecutionPolicy Bypass -File agent\\scripts\\session-capture-hook.ps1",
            "timeout": 30,
            "statusMessage": "Capturing session to daily log..."
          }
        ]
      }
    ]
  }
}
```

Codex global hook command:

```json
{
  "hooks": {
    "Stop": [
      {
        "matcher": "",
        "hooks": [
          {
            "type": "command",
            "command": "powershell.exe -NoProfile -ExecutionPolicy Bypass -File \"<absolute path to vault>\\agent\\scripts\\session-capture-hook.ps1\"",
            "timeout": 30,
            "statusMessage": "Capturing session to daily log..."
          }
        ]
      }
    ]
  }
}
```

Verify `agent/scripts/session-capture-hook.ps1` exists. If it does not, create it by copying the canonical Windows Stop-hook body from the Foundry template; do not point Windows at the `.sh` hook.

**What we deliberately do NOT wire here (and why):**

- **No vault-autosync hooks (push or pull).** Those are Eitan's multi-device GitHub-backed setup. Foundry classmates run a single-device vault — no GitHub repo, no cross-device sync need. Wiring them would silently fail on every Stop / SessionStart and clutter the agent's status line. If a classmate later adopts a multi-device flow, they can opt into a sync skill from the library.
- **No UserPromptSubmit recall hook.** That requires the vector-DB embedding setup (vsearch / Ollama). Wired post-onboarding by a future `/wire-recall` skill once the user has built up enough vault content for retrieval to be useful.

The single capture-on-Stop hook is the load-bearing one — without it, daily logs stay empty and the librarian extraction has nothing to consolidate.

### Phase 5b — Install the nightly `/rem-cycle` scheduler

Without this, the user's vault never auto-consolidates: Hippocampus stays
stale, extraction never fires, the People graph never freshens. This is the
load-bearing automation that ages the agent's memory over time.

Detect the OS again. macOS uses `launchd`; Windows uses Task Scheduler. If scheduler setup fails on either OS, do not abort hatch — the manual `/rem-cycle` command still works.

#### macOS branch: launchd

**Steps:**

1. Make sure the log directory exists: `mkdir -p ~/<vault-dirname>/agent/Logs/rem-cycle`.

2. Read `agent/scripts/rem-cycle.plist` (the template shipped in this vault).
   Substitute the three placeholders:
   - `{{home_path}}` — read `$HOME` (e.g. `/Users/julia`).
   - `{{vault_dirname}}` — the leaf name of the user's vault (e.g.
     `itachi-brain`). Read it from the working directory: the basename of
     `pwd`. Or from `answers.yaml.vault_dir` if available — strip the `~/`.
   - `{{agent_name_lower}}` — slugified agent name from `answers.yaml`.

3. Write the substituted plist to:
   `~/Library/LaunchAgents/com.foundry-<agent_name_lower>.rem-cycle.plist`
   (create `~/Library/LaunchAgents/` if it doesn't exist).

4. Activate the agent:
   ```bash
   launchctl bootstrap gui/$(id -u) ~/Library/LaunchAgents/com.foundry-<agent_name_lower>.rem-cycle.plist
   ```
   If `bootstrap` errors with "service already loaded," that's fine —
   `launchctl bootout` first then re-bootstrap. If `launchctl bootstrap`
   fails on older macOS, fall back to:
   ```bash
   launchctl load ~/Library/LaunchAgents/com.foundry-<agent_name_lower>.rem-cycle.plist
   ```

5. Verify it's loaded:
   ```bash
   launchctl list | grep com.foundry-<agent_name_lower>.rem-cycle
   ```
   Should print a line with a status of `0` (no error). Don't fire it now —
   `RunAtLoad` is false; it'll fire at 4 AM local time.

6. **In the reveal-beat output, mention this explicitly:** "I've also wired a
   nightly cron — every night at 4 AM I'll run `/rem-cycle` to consolidate
   your daily logs into Hippocampus, refresh People graph enrichments, and
   keep the brain fresh. You don't need to do anything; it just runs."

If `launchctl bootstrap` fails (e.g., user has SIP / restricted environment),
log the failure clearly and tell the user to run `launchctl bootstrap` manually
later — don't abort hatch. The vault still works without the cron; the user
just has to manually invoke `/rem-cycle` periodically.

#### Windows branch: Task Scheduler

1. Make sure the log directory exists:

   ```powershell
   New-Item -ItemType Directory -Force -Path "agent\Logs\rem-cycle" | Out-Null
   ```

2. Register a scheduled task that runs daily at 4:00 AM from the vault root:

   ```powershell
   $VaultRoot = (Get-Location).Path
   # Compute this from answers.yaml.agent_name: lowercase, spaces/punctuation -> hyphen.
   $AgentNameLower = "<slugified-agent-name>"
   $TaskName = "Foundry-$AgentNameLower-rem-cycle"
   $LogPath = Join-Path $VaultRoot "agent\Logs\rem-cycle\scheduled-task.log"
   $Action = New-ScheduledTaskAction -Execute "powershell.exe" -Argument "-NoProfile -ExecutionPolicy Bypass -Command `"Set-Location '$VaultRoot'; claude -p '/rem-cycle' *>> '$LogPath'`""
   $Trigger = New-ScheduledTaskTrigger -Daily -At 4:00am
   $Settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable
   Register-ScheduledTask -TaskName $TaskName -Action $Action -Trigger $Trigger -Settings $Settings -Description "Foundry nightly rem-cycle" -Force
   ```

3. Verify:

   ```powershell
   Get-ScheduledTask -TaskName "Foundry-<slugified-agent-name>-rem-cycle"
   ```

4. In the reveal-beat output, mention this explicitly:

   > "I've also wired a Windows Scheduled Task — every night at 4 AM I'll run `/rem-cycle` to consolidate daily logs into Hippocampus, refresh People graph enrichments, and keep the brain fresh."

If `Register-ScheduledTask` fails because Windows policy blocks it, log the failure clearly and tell the user:

> "Windows blocked automatic Task Scheduler registration. The vault still works; run `/rem-cycle` manually before bed until we wire the scheduled task."

### Phase 6 — Verify CLAUDE.md @-refs

Re-read `CLAUDE.md` and confirm these four lines are present:

```
@agent/Soul.md
@agent/Mind.md
@agent/Identity.md
@Memory/Hippocampus.md
```

If any are missing, append them under their headers. (Should already be present from template, but verify.)

### Phase 7 — The reveal beat

This is the seminar's emotional payoff. The agent introduces itself in its newly-stamped voice, drawing on real content from `essay.md` and `eitan-notes.md`.

Read your own freshly-stamped `agent/Soul.md` to refresh in-context tone. Then output a chat message following these rules:

1. **Open with the agent's name + the user's name.** *"Hey {{user_name}} — I'm {{agent_name}}."*
2. **Reference at least one specific detail from `essay.md`** if the file has content. Quote a phrase or paraphrase a theme. Example: *"I read your essay on your grandfather's bakery in Queens — the entrepreneurial-acquisition fit makes complete sense."*
3. **Reference at least one specific detail from `eitan-notes.md`** if the file has content. Make it feel relational, not transactional. Example: *"Eitan also mentioned you two overlapped on the Goldman engagement at McKinsey, and that you're on his short list."*
4. **Name the people seeded from `answers.yaml.people`.** Example: *"I know about Elizabeth, Hadley, Wyatt."*
5. **End with a forward-looking ask.** *"Ready for `/connect-all`?"* (per `connectors-plan.md` — name the first 1-2 connectors that will run).
6. **Voice match:** if `voice_register` is `warm-direct`, use that. If `terse`, keep it short. If `playful`, lighter touch. The point is: this should sound like the agent that just got born, not a system-generated welcome message.

If essay.md or eitan-notes.md is empty, skip the corresponding line — but the message still needs at least the agent name + user name + people + forward-looking ask.

## EVALS (must all pass before declaring DONE)

1. **No placeholders remain.** `grep -r '{{.*}}' agent/Soul.md agent/Identity.md Memory/Hippocampus.md CLAUDE.md` → empty.
2. **`.claude/settings.json` is valid JSON.** Parse-test it.
3. **`Memory/People/` count matches.** Number of `*.md` files (excluding `.gitkeep`) equals number of distinct people in `answers.yaml.people`.
4. **Domain folders match.** For each domain in `answers.yaml.domains`, the corresponding folder exists with an `0-<slug>-index.md` and `Logs/` subdirectory.
5. **Reveal beat references real content.** The output message contains at least one phrase/name from essay.md (if non-empty) AND at least one phrase from eitan-notes.md (if non-empty) AND at least one name from answers.yaml.people.

If any eval fails, list the failure to the user and offer to retry with corrections rather than silently leaving a half-hatched vault.

## DEFINITION OF DONE

The user sees the reveal beat in their CC chat AND can verify (via `ls Memory/People/`, `cat agent/Soul.md`, etc.) that personalization landed. They should walk away from this skill feeling like the agent is *theirs*.

## AFTER YOU FINISH

Print the next-move banner:

```
✓ /hatch complete. Welcome, {{user_name}}.

Next: run /connect-all to wire your selected connectors and mine your data.
That populates Memory/People/ with real interaction history, voice samples,
and themes. Then /rem-cycle consolidates everything and you can open Obsidian
to see your vault as a graph for the first time.

Or if you want to explore alone first, just talk to me. I'm here.
```
