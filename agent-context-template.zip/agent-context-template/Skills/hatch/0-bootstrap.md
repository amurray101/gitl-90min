# 0-bootstrap.md — paste-this-FIRST prompt

> Skills only become slash commands when registered into `~/.claude/skills/`. The vault ships them in `Skills/`, but Claude Code only scans its global skills directory at startup. This prompt bootstraps that registration.

## When to use

Run this prompt **once**, immediately after `claude .` opens this vault for the first time. After it finishes, exit Claude Code (`Ctrl-C` then `Ctrl-D` or type `/exit`), restart with `claude .`, then `/hatch <agent-name>` will be available.

## Paste this into Claude Code

```
Walk the Skills/ folder in this vault. For each subdirectory containing a SKILL.md file:

1. Read the SKILL.md to confirm it has valid frontmatter (name, description fields).
2. Detect the operating system.
3. Register the skill:
   - macOS/Linux: create ~/.claude/skills/<skill-name>/ if needed, then create or refresh a symlink from ~/.claude/skills/<skill-name>/SKILL.md to the absolute path of this vault's Skills/<skill-name>/SKILL.md.
   - Windows: create $HOME\.claude\skills\<skill-name> if needed, then copy this vault's Skills\<skill-name>\SKILL.md into $HOME\.claude\skills\<skill-name>\SKILL.md. Do not use symlinks on Windows unless the user explicitly confirms Developer Mode/admin privileges are enabled.
4. Verify each registered SKILL.md is readable from Claude Code's global skills directory.

After processing all skills:
- List each skill that was registered, with its one-line description.
- Note any that failed registration and why (missing frontmatter, broken yaml, etc.).

When done, print this message:
"✓ All skills registered. Now exit Claude Code (Ctrl-C, Ctrl-D) and restart with `claude .` so the new slash commands take effect. Then type /hatch <your-agent-name> to begin."

Do not skip the restart. Skills registered mid-session will not appear as slash commands until the runtime re-scans on startup.
```

## What this does (in plain English)

The vault's `Skills/` folder contains procedure-shaped markdown files (each `<skill>/SKILL.md`). Claude Code registers slash commands by scanning `~/.claude/skills/` at startup. On macOS/Linux, this prompt creates symlinks so future skill-edits in the vault are picked up automatically. On Windows, it uses copies because symlink behavior depends on Developer Mode/admin permissions; rerun this bootstrap prompt after skill updates to refresh the copies.

After restart, you'll have ~25 slash commands available — `/hatch`, `/connect-all`, `/lookback`, `/rem-cycle`, `/handoff`, `/spider`, `/paint-the-picture`, etc.
