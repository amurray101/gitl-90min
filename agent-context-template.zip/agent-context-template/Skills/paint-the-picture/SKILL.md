---
name: paint-the-picture
description: Spin up a live localhost UI to visualize whatever's in session context — guest lists, project comparisons, kanban boards, people graphs, anything {{user_name}} wants to see rather than read. Iterate by talking; the page auto-reloads. Each paint becomes a vault artifact with wikilinks back to its source entities. Invoked via /paint-the-picture <description>.
title: Paint the Picture
type: skill
created: 2026-05-01
updated: 2026-05-01
tags: [skill, ui, viz, paint, workbench]
trigger: "User invokes /paint-the-picture <description>. Use when {{user_name}} wants to SEE something interactively (table, board, network, comparison) instead of reading it in chat. Iteration commands afterwards (\"add a column for X\", \"sort by Y\", \"now group by Z\") regenerate the active paint in place."
---

# Paint the Picture

> Build a live, browser-based view of session context. Iterate by talking — the page reloads itself.

## What this is

A skill that turns conversation into an interactive artifact you can keep open in a browser tab. Like Claude's chat artifacts, but local: served from `Workbench/paint/` on `http://localhost:4747/`, persists across sessions, lives in the vault as a real file with wikilinks to its source entities.

**When to use:**
- {{user_name}} invokes `/paint-the-picture <description>` — always.
- Anytime he says "show me X as a table / board / graph" and the data exists in conversation or the vault.

**When NOT to use:**
- One-shot answers that fit in chat (a short list, a quick number).
- Static snapshots for export — that's PDF / markdown, not paint.
- Anything that needs auth, server-side compute, or a real backend (Tailwind + inlined JSON only).

## Procedure

### 1. Parse the invocation

The user types `/paint-the-picture <description>`. The description tells you:
- **What to paint** — the subject (guestlist, project comparison, people graph, kanban).
- **Shape** — table / cards / kanban / network / timeline / dashboard. Default to **table** if unspecified.
- **Source** — what session context or vault entities to pull from.

If the description is ambiguous, ask one clarifying question before building. Don't paint blind.

### 2. Decide if this is a NEW paint or ITERATION on an existing one

- **New paint**: Different topic from the last paint, or no paint exists. Make a new slug.
- **Iteration**: {{user_name}} says "add a column", "now sort by", "include their email", "group by domain", "switch to kanban" — applies to a target paint. Resolve the target in this priority order:
  1. **Explicit reference** — {{user_name}} named a slug, title fragment, or topic ("on the guestlist paint", "in `2026-05-01-rollout`"). Grep `Workbench/paint/recent.jsonl` for the most recent match.
  2. **This-session paint** — the paint *you* most recently created or iterated on in this conversation. Trust your own conversational context over filesystem state — that's the parallel-safe path.
  3. **Global fallback** — the last entry in `recent.jsonl`. Only use this if (1) and (2) don't apply. If multiple paints are live and you're unsure, ask {{user_name}} which one he means rather than guessing.

Reuse the slug and `data.json`; regenerate `index.html`; bump `version.txt`.

Cross-paint state lives in `Workbench/paint/recent.jsonl` — an append-only log, one JSON object per line: `{"ts": "<ISO-8601-Z>", "slug": "...", "title": "...", "action": "create" | "iterate"}`. Appends under 4KB are atomic on POSIX, so parallel sessions can write without locking. Do NOT use `.active` (legacy single-slot pointer; ignore it if you find one).

### 3. Slug + title

- **Slug**: `YYYY-MM-DD-kebab-case-topic`. Keep under 50 chars. Use today's date from the environment context.
- **Title**: a clear noun phrase (e.g., "Agent Session Guestlist — May 1").
- **Subtitle**: 1-line of source/scope (e.g., "8 attendees · pulled from Memory/People + Apr 28 chat").

### 4. Gather the data

Pull from:
- **Conversation context** — what's been discussed in this session.
- **Vault entities** — if the description names people, projects, or domains, read the relevant files (`Memory/People/<slug>.md`, `Swordpoint/...`, etc.). If auto-recall context is present, use it first; otherwise read the relevant vault files directly. Do follow-up reads when you need a specific field.
- **Live data** — calendar (`gog calendar events`), email (`gog gmail search`), Granola, etc., when the description requires fresh data.

Structure as JSON: an array of objects for tables/cards, a tree for hierarchies, a `{nodes, edges}` shape for graphs. Keep field names lowercase + snake_case.

**Confidence flags**: when you're inferring a field (someone's role, a relationship), include a `_confidence` or visibly mark unknowns as `—` rather than fabricating.

### 5. Pick the visualization

Match the shape to the request:

| Shape | When | Render hint |
|---|---|---|
| Table | Default. Comparing entities across same fields. | `<table>` with sticky header, sortable columns |
| Cards | Heterogeneous fields per entity, narrative-heavy | Tailwind grid of cards |
| Kanban | Status flow (todo / doing / done) | Columns, draggable not needed (read-only) |
| Network | Relationships matter more than attributes | Inline SVG; small graphs only — for >50 nodes, switch to a clustered layout |
| Timeline | Chronology is the spine | Vertical or horizontal line, dated entries |
| Dashboard | Mixed: stat tiles + a chart + a table | Top: KPI tiles; below: components |

If unsure, start with a table and tell {{user_name}} he can ask to switch shape.

### 6. Render the HTML

- Read `Workbench/paint/template.html` as the base.
- Substitute `{{TITLE}}`, `{{SUBTITLE}}`, `{{DATA_JSON}}` (the data, JSON-encoded), `{{VERSION}}` (the integer version), `{{IS_LATEST}}` (`true` for `index.html`, `false` for history snapshots), and `{{BASE_HREF}}` (empty string for `index.html`, `<base href="../">` for history snapshots — this makes relative URLs in snapshot files resolve to the slug root).
- Replace the `<!-- BODY -->` marker with the visualization markup. Use Tailwind utility classes (the CDN script is already loaded). Build complete, working HTML — no placeholders.
- Add inline `<script>` to render from the `#paint-data` JSON if the visualization needs JS (e.g., sortable columns). Keep JS minimal and dependency-light.
- The template already includes the undo/redo toolbar in the header (◀ v3 / 7 ▶). Don't add or remove it — just render the BODY content into `<main id="root">` and the toolbar wires itself up from `{{VERSION}}` + polling `version.txt`.

**Style defaults**: when no design direction is mentioned in the invocation, default to the **active Radar theme**. Read it from `Workbench/paint/2026-05-01-radar-southwest-mockups/data.json` → `themes[active_theme]` (currently `taos` / Taos (renamed from southwest-adobe / Adobe Cream) — warm cream surfaces, terracotta urgent, sage success, dusty teal accent). This keeps paints visually consistent with {{user_name}}'s HQ cockpit. Generous padding, monospace for IDs/codes, subtle borders. If {{user_name}} specifies a look ("dark", "neon", "minimal whitepaper"), override the default. The base `template.html` is dark-mode by default — when using a light theme like Taos, write the HTML inline rather than substituting the template, and skip the dark `:root { color-scheme: dark; }` declaration.

**Taos tokens (cache for quick reference)**:
- page bg `#F5EFE0`, surface `#EDE3CD`, surface alt `#E5D8B8`
- border `#D9C9A8`, border strong `#C5B084`
- text `#3E2C1F`, muted `#8A7560`, dim `#A89880`
- urgent `#A53A20` (bg `rgba(165,58,32,.10)`), success `#4F6F44`, warning `#D2A24C`, accent `#5B8A8F`

**Accessibility**: real `<th>` for table headers, `aria-label` on icon-only controls, keyboard-navigable.

### 7. Write the files (live + history snapshot)

For each paint at `Workbench/paint/<slug>/`:

**Live (overwritten every render):**
- `index.html` — rendered template with `{{VERSION}}=N`, `{{IS_LATEST}}=true`, `{{BASE_HREF}}=` (empty)
- `data.json` — the underlying data (so you can re-render on iteration without re-querying sources)
- `version.txt` — a monotonically incrementing integer (start at 1; bump on every regeneration). Drives auto-reload.
- `<slug>.md` — vault-indexed metadata + summary + wikilinks. **Filename matches the folder slug exactly** (e.g. `2026-05-01-mba27-people-candidates/2026-05-01-mba27-people-candidates.md`). Don't name it `README.md` — that produces a vault full of identically-named graph nodes and breaks recent-files / search / graph view. Vault graph nodes follow vault naming; `README.md` is reserved for actual code repos.

**History snapshot (immutable, written every render):**
- `history/v<N>.html` — same body markup as `index.html`, but rendered with `{{VERSION}}=N`, `{{IS_LATEST}}=false`, `{{BASE_HREF}}=<base href="../">`. Lets the user step back to compare. Once written, never overwrite.
- `history/v<N>.json` — copy of that render's `data.json`. Useful if you ever need to true-revert (overwrite root `data.json` from a snapshot).

So every render produces 5 files: 3 live (index.html, data.json, version.txt) + 2 history (history/v<N>.html, history/v<N>.json). The `<slug>.md` is updated, not duplicated per version.

`<slug>.md` template:

```markdown
---
title: <Title>
type: paint
domain: <best guess: workbench / academics / swordpoint / personal>
created: YYYY-MM-DD
updated: YYYY-MM-DD
url: http://localhost:4747/<slug>/
related:
  - "[[Memory/People/...]]"
  - "[[Swordpoint/...]]"
tags: [paint, <topic-tags>]
---

# <Title>

<1-paragraph plain-English summary of what this paint shows and why {{user_name}} asked for it.>

## Source

- <bullet list of where the data came from: vault paths, conversation, live queries>

## Live URL

<http://localhost:4747/<slug>/>

## Iteration log

- YYYY-MM-DD HH:MM — created (initial render)
- YYYY-MM-DD HH:MM — added column X / switched to kanban / etc.
```

The `related:` frontmatter is the load-bearing piece — it makes the paint discoverable in Obsidian's graph and via `vsearch`. Wikilink every entity (people, projects, courses, log files) the paint draws from. Don't be stingy.

### 8. Ensure the server is running

```bash
python3 <your-vault>/Workbench/paint/server.py status
# if "not running":
python3 <your-vault>/Workbench/paint/server.py start
```

The server is shared and persistent. If port 4747 is taken by something else, the script refuses to start — surface that to {{user_name}} rather than picking a different port (consistency matters more than fallback).

### 9. Open the browser (only on first render of a paint)

```bash
open "http://localhost:4747/<slug>/"
```

On iteration, **don't re-open** — the existing tab auto-reloads via `version.txt` polling. Re-opening would steal focus and create duplicate tabs.

### 10. Append to `recent.jsonl` and update the index

- Append one line to `Workbench/paint/recent.jsonl`:
  ```json
  {"ts": "<ISO-8601-Z>", "slug": "<slug>", "title": "<title>", "action": "create"}
  ```
  Use `>>` for the append so concurrent sessions don't clobber each other. Action is `"iterate"` on iteration appends (see below).
- Add a line to `Workbench/paint/0-paint-index.md` under "## Live paints":
  `- [[Workbench/paint/<slug>/<slug>|<title>]] — <one-line summary> · created YYYY-MM-DD`
  Newest first. Move stale paints (>30 days, no recent iteration) to `Archive/Paint/` during nightly maintenance.

### 11. Tell {{user_name}}

After rendering, one short line:

```
Painted: <Title> → http://localhost:4747/<slug>/
Linked to: <count> vault entities. Talk to me to iterate (add columns, change shape, pull more data).
```

Don't dump the data back at him — he's looking at it in the browser. Stay quiet until he asks for changes.

## Iteration mechanics

When {{user_name}} says something like "add an `email` column" or "now sort by domain":

1. **Resolve the target paint** using the priority order in step 2 (explicit reference → this-session paint → recent.jsonl fallback). When in doubt, ask.
2. Read `<slug>/data.json` → current state.
3. Apply the requested change (mutate data, change shape, add field). If a field needs new info from the vault or external sources, fetch it.
4. Compute the new version: `N = read(version.txt) + 1`.
5. Regenerate `index.html` with the updated data, rendered as `{{VERSION}}=N`, `{{IS_LATEST}}=true`, `{{BASE_HREF}}=` (empty).
6. Write `history/v<N>.html` — same body markup, but `{{IS_LATEST}}=false`, `{{BASE_HREF}}=<base href="../">`. Write `history/v<N>.json` (copy of new data.json). Create `history/` if missing.
7. Bump `version.txt` to `N`.
8. Append a line to `<slug>.md`'s "Iteration log".
9. Update `related:` frontmatter if new entities entered the paint.
10. Append `{"ts": ..., "slug": ..., "title": ..., "action": "iterate"}` to `Workbench/paint/recent.jsonl`.
11. Acknowledge in chat with one line — no preamble.

Browser auto-reloads within ~1 second (if the user is viewing `index.html`). If the user is viewing a `history/v<N>.html` snapshot, the page does NOT reload — only the toolbar's "v3 / 7" count updates so the new version is reachable via redo.

**Backward compat for paints created before history snapshots existed:** if you're iterating a paint and `history/` doesn't exist yet, before writing the new files, snapshot the *current* (about-to-be-overwritten) state to `history/v<current>.html` and `history/v<current>.json` so the user can still undo one step. Re-render the snapshot HTML with `{{IS_LATEST}}=false` and `{{BASE_HREF}}=<base href="../">` using the existing `data.json` and the body from the existing `index.html` (extract the contents of `<main id="root">…</main>` and re-template). If body extraction is fragile, fall back to copying `index.html` verbatim into `history/v<current>.html` — auto-reload will misbehave on that one snapshot but undo/redo still works.

## Parallel safety

Paints are designed to coexist. Multiple paints can be live at once across one or many Claude sessions / terminals.

- **Shared server**: one process on port 4747 serves every slug. No conflict.
- **Per-paint state**: each slug owns its own `data.json`, `version.txt`, `index.html`, `<slug>.md`. Writes are scoped to the paint folder — no cross-contamination.
- **Cross-paint state**: only `recent.jsonl` (append-only, atomic for sub-4KB lines) and `0-paint-index.md` (rare appends, low-contention). No single-slot active pointer.
- **Disambiguating iteration**: when multiple paints are live, prefer (1) explicit references in {{user_name}}'s message and (2) your own conversation context over the global recent log. If two sessions are both iterating, each session's "what I just made" is a stronger signal than `recent.jsonl`'s last entry. Ask before guessing.
- **No file locks needed**: the design avoids shared-mutable state. Two parallel sessions painting different topics can run start-to-finish without coordination.

## Edge cases

- **Server already running on a different paint folder root**: never. The server is rooted at `Workbench/paint/`; it serves all slugs from there.
- **User invokes `/paint-the-picture` with no arguments**: ask what to paint. Don't render an empty page.
- **Data is too big for inline JSON (>1MB)**: write `data.json` separately and have the HTML `fetch('data.json')` on load. Threshold: pragmatic, not strict.
- **{{user_name}} asks for something the browser can't do** (real-time DB query, requires login): say so, suggest the closest static alternative.
- **{{user_name}} asks to "stop" or "close" the paint**: don't delete the folder (vault artifact). Just confirm; the server keeps running for other paints.

## Portability (Foundry clients)

This skill is designed to work in any Foundry vault, not just {{agent_name}}'s. To port it:

1. Copy `Workbench/paint/` (server.py, template.html, .gitignore, 0-paint-index.md) into the client vault. Pick a different port if the client's machine might collide (4748, 4749, etc.) — set it in `server.py`'s `PORT` constant.
2. Copy this `SKILL.md` to the client's `Skills/paint-the-picture/` and to `~/.claude/skills/paint-the-picture/` on the client's machine.
3. Replace any {{agent_name}}-specific examples in this skill (Swordpoint, Memory/People paths) with the client's vault structure during onboarding.

The mechanism is generic — paint takes whatever's in session and renders it. The personality of *what* gets painted is the agent's, not the skill's.

## See also

- [[Workbench/paint/0-paint-index|Paint index]] — list of live paints + how the folder is laid out
- [[Skills/devlog/SKILL|Devlog]] — repo-side decision log; paint is the vault-side visual log
- [[Skills/spider/SKILL|Spider]] — graph audit; if paint `<slug>.md` files become orphaned, spider catches it
