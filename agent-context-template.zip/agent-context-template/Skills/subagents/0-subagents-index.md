---
tags: [skill, subagents, architecture]
title: "{{agent_name}} Sub-Agents"
type: reference
---

# {{agent_name}} Sub-Agents

Specialized agents that run focused tasks with stored prompts. Each sub-agent has its own directory with a prompt file and configuration.

## Directory Structure

```
subagents/
├── README.md                    # This file
├── strategic-overview/          # Dashboard overview generator
│   ├── PROMPT.md               # The agent's instructions
│   └── [[Skills/subagents/strategic-overview/config.json|config.json]]  # Model, schedule, I/O config
├── code-review/                 # (Future) Code quality auditor
├── security-audit/              # (Future) Security scanner
├── research-synthesizer/        # (Future) Research compiler
└── ...
```

## How Sub-Agents Work

1. **Trigger**: Heartbeat, cron, or on-demand request (see [[agent/automations|Automations]] for scheduled jobs)
2. **Spawn**: Main {{agent_name}} spawns the sub-agent with `sessions_spawn`
3. **Execute**: Sub-agent reads its PROMPT.md and follows instructions
4. **Output**: Writes to configured output file(s)
5. **Announce**: Reports completion back to main session

## Creating a New Sub-Agent

1. Create a new directory: `subagents/<agent-name>/`
2. Write `PROMPT.md` with clear instructions
3. Create `config.json` with execution settings
4. Register in the Sub-Agents HQ tab

## Configuration Schema

```json
{
  "id": "unique-id",
  "name": "Human Name",
  "description": "What this agent does",
  "version": "1.0.0",
  
  "execution": {
    "model": "anthropic/claude-sonnet-4",  // or claude-opus-4, gpt-4o, etc.
    "thinking": "off|low|medium|high",
    "timeoutSeconds": 120,
    "cleanup": "delete|keep"
  },
  
  "schedule": {
    "type": "heartbeat|cron|manual",
    "frequency": "description of when",
    "cronExpr": "0 7 * * *"  // if type=cron
  },
  
  "inputs": {
    "dataFiles": ["file1.json", "file2.json"],
    "externalCommands": ["command to run"],
    "contextFromMain": false
  },
  
  "outputs": {
    "primaryFile": "output.json",
    "announceToMain": true,
    "notifyChannel": "telegram"  // optional
  },
  
  "history": {
    "lastRun": "ISO timestamp",
    "lastSuccess": "ISO timestamp",
    "runCount": 0,
    "averageDurationMs": null
  },
  
  "tags": ["category", "tags"]
}
```

## Running a Sub-Agent

### From Main {{agent_name}}
```
"Run the strategic overview agent"
→ {{agent_name}} reads subagents/strategic-overview/PROMPT.md
→ Spawns with sessions_spawn
→ Agent executes and writes output
→ Announces completion
```

### Programmatically
```javascript
// In heartbeat or on-demand
const prompt = fs.readFileSync('subagents/strategic-overview/PROMPT.md');
const config = JSON.parse(fs.readFileSync('subagents/strategic-overview/config.json'));

sessions_spawn({
  task: prompt,
  model: config.execution.model,
  thinking: config.execution.thinking,
  timeoutSeconds: config.execution.timeoutSeconds,
  label: config.id
});
```

## Best Practices

1. **Single Responsibility**: Each agent does ONE thing well
2. **Clear Outputs**: Define exactly what files the agent writes
3. **Idempotent**: Running twice should produce the same result
4. **Timeout Safe**: Agent should complete within its timeout
5. **Self-Contained**: Prompt includes everything needed (no assumptions)

## Current Sub-Agents

| Agent | Purpose | Schedule | Status |
|-------|---------|----------|--------|
| `strategic-overview` | Generate dashboard overview | On-demand / Heartbeat | ✅ Active |
| `code-review` | Audit code quality | Manual | 📋 Planned |
| `security-audit` | Find vulnerabilities | Manual | 📋 Planned |
| `canvas-sync` | Sync Canvas assignments | Hourly | 📋 Planned |

## Agent Configs

- [[Skills/subagents/strategic-overview/config.json|Strategic Overview Config]] — Model, schedule, and I/O configuration for the strategic overview agent
