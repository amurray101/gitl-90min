---
name: handoff
description: End-of-session handoff — writes daily notes, runs radar-verify in apply mode, updates Radar, regenerates Hippocampus, captures context for the next session.
title: Session Handoff
type: skill
created: 2026-04-06
updated: 2026-04-09
tags: [skill, session, handoff]
trigger: "End of any significant work session — invoked via /handoff slash command or manually."
---

# Session Handoff

> Clean close-out of a work session. Captures what happened, updates Radar, sets up the next session.

## Procedure

### 1. Write Today's Daily Entry

Append to `Memory/Daily/YYYY-MM-DD.md` (create if it doesn't exist). If the file already has content from earlier sessions, add a `---` separator.

**IMPORTANT:** Every daily file MUST have an `extracted:` flag in frontmatter. If `extracted: true`, flip it to `false` when adding new content. If the flag is missing entirely, add `extracted: false`. This ensures new sessions get picked up by future `/extract` runs.

```markdown
---

### Session: HH:MM — [brief description]

**What happened:**
- [Key actions, decisions, and outcomes from this session]

**Files created/modified:**
- [List significant files with wikilinks]

**Open questions:**
- [Anything unresolved or needing follow-up]

**Recommended next context:**
- [What the next session should read/know to continue this work]
```

The daily file should have frontmatter if newly created:
```yaml
---
title: "YYYY-MM-DD"
type: daily
tags: [daily]
---
```

### 1.5. Verify Radar (auto-clear what's actually done)

Before rewriting Radar, run [[Skills/radar-verify/SKILL|/radar-verify]] in `apply` mode. The verifier walks every item with a `✓ Done when:` clause, probes the named place(s) for evidence, and:

- Auto-deletes HIGH-confidence cleared items from `Radar.md` (the HQ pipeline picks up the diff and queues them for the Collect XP button — {{user_name}} stays the human gate).
- Surfaces MEDIUM-confidence "candidate" items for {{user_name}} to review during the handoff summary.
- Lists items missing a `Done when:` clause so they can be annotated next time.

Daily-notes grep is part of every probe — {{user_name}} often mentions "sent X" or "shipped Y" in passing across sessions, and that casual mention is corroborating evidence.

In the handoff output, surface the verifier's report (cleared count, candidates, items needing criteria) so {{user_name}} can spot a wrong call before pressing Collect XP.

### 2. Update Radar

Rewrite `Radar.md` to reflect current state. The four sections:

- **Urgent (next 48h)** — Time-sensitive items
- **Active (this week)** — Work in progress
- **Watching (needs attention soon)** — Coming up
- **Open Loops** — Unresolved threads

Radar is REWRITTEN, not appended. Keep it under 30 lines. Remove items that are done. Add items that emerged this session.

**SMART rule for Urgent.** Every item in `Urgent (next 48h)` must be SMART-framed. This mirrors the RACI philosophy — Urgent is for things that can be picked up and finished, not for vague "review X" / "deliver Y" placeholders. The five tests:

- **S**pecific — concrete artifact or action (not "work on X")
- **M**easurable — explicit done-state (file path, recipient, link, click)
- **A**chievable — doable as written, no hidden blockers
- **R**elevant — tied to an active project or commitment
- **T**ime-bound — deadline within 48h (else it belongs in Active)

**Plus: {{user_name}}-doer rule.** Urgent is reserved for items where {{user_name}} ships a concrete deliverable in the next 48h (send an email, submit a writeup, draft a doc, provision DNS). **NOT a deliverable:** attending a meeting (the calendar fires it), waiting on someone else's reply, reviewing inbox. If a meeting's prep is already shipped, the meeting itself does NOT belong in Urgent — post-meeting capture (RACI item, log, follow-up) gets added AFTER the meeting fires, not before. If prep isn't done, only the prep itself goes in Urgent (e.g. "Submit Office case writeup to Canvas by Mon 12:55pm"), and clears once shipped.

Template: `[Verb] [artifact] to/at [destination] by [datetime] — [supporting detail/link]`

Examples:
- ✅ `Submit Office case writeup to STRAMGT-386 Canvas by Mon Apr 27 12:55pm PT — paste from Prep/2026-04-27-canvas-submission.md`
- ❌ `Comp-plan recommendation for Ben & Elizabeth — URGENT` (no artifact, no deadline)

If an item fails any test, either rewrite it to SMART or relocate it to Active / Watching / Open Loops. Vague items in Urgent are dead weight — they don't move because nobody knows what "done" looks like. Items in `Active`, `Watching`, and `Open Loops` don't need to be SMART (they're carrying context, not action), but apply the same template when an item is genuinely actionable.

**`✓ Done when:` line — required for auto-verification.** Every Radar item should end with a `✓ Done when:` clause *before* the `<!-- id:r_xxx -->` comment. The clause names the place where the proof of done-ness will land — a sent email, a commit on main, a vault file, a daily-note mention, a Canvas grade. [[Skills/radar-verify/SKILL|/radar-verify]] reads each criterion, runs the right probe, and auto-clears HIGH-confidence matches. Items without the line carry forward indefinitely.

Format: `- **<title>** — <body>. ✓ Done when: <criterion>. <!-- id:r_xxx -->`

Examples:
- `✓ Done when: Stanford Sent has a message to dadkins@stanford.edu after Apr 27`
- `✓ Done when: Memory/Daily/2026-04-28.md or 2026-04-29.md mentions the Zan comp conversation`
- `✓ Done when: Academics/390-ai-search/Logs/2026-04-27_gerald-first-checkin.md exists`
- `✓ Done when: git log in ~/swordpoint-projects/wingen-warren shows commit touching sync-map-coverage.js`

Items where verification doesn't make sense (habits, "watch this" items with no observable end-state) can omit the clause; the verifier will list them under "missing criteria" so they can be either annotated or accepted as carry-forward.

**Preserve item IDs.** Each Radar item has an HTML comment ID suffix like `<!-- id:r_7kx3m -->`. When rewriting:
- **Existing items:** preserve the `<!-- id:xxx -->` at the end of the line, even if you reword the item or move it between sections.
- **New items:** do NOT add an ID — the system auto-assigns one.
- **Done items:** simply omit the line. The system records the clear.
- Read the current Radar.md before rewriting to capture existing IDs.

**Wikilink to project homes.** The most important link on any Radar item is the one that takes {{user_name}} to the project it belongs to — the index file where context, decisions, and history live. For every Radar item, ask: *does this belong to a project/course/domain that has a vault home?* If yes, link the item's name to that home.

Priority order for link targets:
1. **Project index** — `Workbench/{slug}/0-{slug}-index`, `Swordpoint/WinGen/{slug}/0-{slug}-index`, etc.
2. **Course index** — `Academics/{slug}/0-{slug}-index`
3. **Domain index** — `{Domain}/0-{slug}-index` (Foundry, SlideBitch, etc.)
4. **People** — `Memory/People/{slug}` for named individuals
5. **Log entries / meeting notes** — when the item traces to a specific conversation or build log

Use display aliases for readability (e.g. `[[path/to/0-homer-index|Homer]]`). If unsure whether a target exists, check before linking. Don't create dead links.

### 3. Regenerate Hippocampus.md

`Memory/Hippocampus.md` is the injected working-memory file (loaded every session via `@Memory/Hippocampus.md` in vault CLAUDE.md). Two sections, different cadences. (Renamed from `Brain.md` 2026-04-24.)

**Always rewrite the `## Now` section:**
- **Today** — date + 1–3 sentences on what's happening and what's heavy
- **Last 3 days — the arc** — one bullet per day, 2–4 lines each, distilled from daily files
- **Active this week** — pulled from Radar's "Active" section, short-form
- **Watching** — one-line compressed list from Radar's "Watching"
- **Parked / open loops** — one-line compressed list from Radar's "Open Loops"

**Check the `arc-updated:` field in frontmatter.** If it's >48h old (or missing), rewrite the `## Arc` section too:
- **Swordpoint** — HoldCo state, who's who, current strategic posture
- **RACI** — product status snapshot
- **Academics** — quarter, live courses, upcoming deadlines
- **Foundry** — client pipeline state
- **Relationships currently active** — close circle + recent surfacing + parked-but-alive
- **The through-line right now** — 2–3 sentences on what this chapter is about

Target total size: ≤1,500 words. If it grows past that, cut — not bloat. When rewriting Arc, update the `arc-updated:` field to today's date. Always update `updated:` to today.

**Frontmatter discipline — `updated:` and `arc-updated:` are scalar timestamps ONLY.** Format: `YYYY-MM-DD` or `YYYY-MM-DD <coarse-time>` (e.g. `2026-04-27`, `2026-04-27 late-night`). **Never** put session recap, parenthetical handoff notes, wikilinks, bold/italic, colons, brackets, or any prose into these fields — they are YAML scalars and any of those characters will silently break frontmatter parsers (Dataview, embeddings, vault tooling). Recap belongs in the `## Now` body, not in YAML. If you feel the urge to write `updated: 2026-04-27 (handoff — ...)`, stop: write the timestamp, then put the recap in the body.

**Wikilinks are mandatory, not optional.** Hippocampus is the most frequently-read file in the vault — every mention of a person, project, meeting, course, or planning doc MUST be a wikilink so {{agent_name}} can jump straight to the source in the same turn it's mentioned.

Link rules:
- Every named person → `[[Memory/People/<slug>|FirstName]]` (aliased to keep prose readable)
- Every active project → its `0-<slug>-index` file
- Every course → its index in `Academics/<slug>/`
- Every referenced meeting → `[[Memory/Meetings/YYYY-MM-DD_slug]]`
- Every planning/prep doc → direct wikilink, not plain text
- Daily-arc bullets → link the date to the daily file: `[[Memory/Daily/YYYY-MM-DD|Apr N (Mon)]]`

Before linking, confirm the target exists (avoid dead links). If a person surfaces for the first time and has no file yet, use plain text — let the extraction subagent create the stub before the next Hippocampus rewrite.

This is what makes Hippocampus a *healthy* hub: links are earned by the item being mid-flight, not by cataloging. When something drops off Radar/daily, its link drops out of Hippocampus on the next rewrite — no stale spokes.

**Do NOT duplicate content from:**
- CLAUDE.md (identity, vault rules) — that's already loaded
- Auto-memory `MEMORY.md` (feedback rules) — also loaded
- `Memory/Lessons/`, `Memory/People/`, project `0-*-index.md` files — reached via the wikilinks above

Hippocampus is a snapshot, not a library.

### 4. Update Domain Logs (if significant)

If this session involved significant work on a domain (shipped a feature, made a key decision, hit a milestone), append to the relevant `Domain/Logs/` file with a dated entry.

Only do this for notable work — not every small fix needs a log entry.

### 5. Surface Anything Urgent

If there's something {{user_name}} should know before next session (deadline, blocker, risk), say it explicitly in the handoff summary. Don't bury it in the daily file.

## Output

After completing the handoff, print a concise summary:

```
Handoff complete.
- Daily: Memory/Daily/YYYY-MM-DD.md [updated/created]
- Radar verify: <N> auto-cleared, <M> candidates, <P> missing criteria
- Radar: updated
- Hippocampus: Now rewritten [+ Arc refreshed if stale]
- [Any domain logs updated]
- Next session should: [one-liner recommendation]
```

## See Also

- [[Skills/radar-verify/SKILL|Radar Verify]] — Step 1.5 of handoff; probes each `✓ Done when:` line and auto-clears HIGH-confidence items
- [[Skills/extraction/SKILL|Extraction (The Librarian)]] — Full knowledge routing from Daily notes into structured vault locations
- [[Skills/spider/SKILL|Spider]] — Graph audit: orphan resolution, link discovery, index file freshness
- [[Skills/granola-sync/SKILL|Granola Sync]] — Sync meeting transcripts before or alongside handoff