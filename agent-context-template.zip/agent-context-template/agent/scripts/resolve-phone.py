#!/usr/bin/env python3
"""resolve-phone.py — phone number → Memory/People/<file>.md resolver.

Why this exists: macOS Contacts.app on the Mac Mini is empty (iCloud Contacts
not syncing), so iMessage/WhatsApp MCPs that rely on Contacts (`lookup_contact`)
return null for everything. The People graph is the only ground truth, but
naive substring grep gives false positives. This script normalizes phones to
their last-10-digits and only matches anchored phone-shaped patterns.

Used by /sweep-imessage and /sweep-whatsapp as the primary resolution path.

Usage:
    resolve-phone.py +14042451776                 # single lookup
    resolve-phone.py +14042451776 +13057613064    # batch
    echo +14042451776 | resolve-phone.py -        # stdin, one per line
    resolve-phone.py --build-index                # dump full phone -> file map as JSON

Output: tab-separated <phone>\t<file_or_NO_MATCH>, one per line.
"""

import json
import os
import re
import sys
from pathlib import Path

PEOPLE_DIR = Path(os.environ.get("VAULT_PEOPLE", "/Users/<user>/<vault>/Memory/People"))

PHONE_PATTERNS = [
    re.compile(r"(?i)(?:phone|cell|mobile|tel|number)[^\n]*?([+\d][\d\s().\-]{9,20})"),
    re.compile(r"\+1\s*[\d\s().\-]{10,15}"),
    re.compile(r"\(\d{3}\)\s*\d{3}[\s\-]\d{4}"),
    re.compile(r"\b\d{3}[\s\-\.]\d{3}[\s\-\.]\d{4}\b"),
]


def normalize(s: str) -> str | None:
    digits = re.sub(r"\D", "", s)
    if len(digits) == 11 and digits.startswith("1"):
        digits = digits[1:]
    return digits if len(digits) == 10 else None


def build_index() -> dict[str, list[str]]:
    """Walk Memory/People/ once, return {normalized_phone: [filename, ...]}."""
    idx: dict[str, list[str]] = {}
    for fn in os.listdir(PEOPLE_DIR):
        if not fn.endswith(".md"):
            continue
        try:
            content = (PEOPLE_DIR / fn).read_text(encoding="utf-8")
        except Exception:
            continue
        found = set()
        for pat in PHONE_PATTERNS:
            for m in pat.findall(content):
                n = normalize(m if isinstance(m, str) else m[0])
                if n:
                    found.add(n)
        for n in found:
            idx.setdefault(n, []).append(fn)
    return idx


def resolve(phone: str, idx: dict[str, list[str]]) -> str:
    n = normalize(phone)
    if not n:
        return "NO_MATCH"
    matches = idx.get(n, [])
    return ", ".join(matches) if matches else "NO_MATCH"


def main():
    args = sys.argv[1:]
    if not args:
        print(__doc__, file=sys.stderr)
        sys.exit(2)

    idx = build_index()

    if args == ["--build-index"]:
        json.dump(idx, sys.stdout, indent=2, sort_keys=True)
        return

    if args == ["-"]:
        phones = [line.strip() for line in sys.stdin if line.strip()]
    else:
        phones = args

    for p in phones:
        print(f"{p}\t{resolve(p, idx)}")


if __name__ == "__main__":
    main()
