param()

# Foundry Stop-hook for Windows PowerShell.
# Reads the Claude Code Stop-hook JSON payload on stdin and writes one
# transcript markdown file per session under Memory/Daily/sessions/.

$ErrorActionPreference = "SilentlyContinue"

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$vaultRoot = $env:VAULT_ROOT
if (-not $vaultRoot) {
  $vaultRoot = Resolve-Path (Join-Path $scriptDir "..\..") | Select-Object -ExpandProperty Path
}

$dailyDir = Join-Path $vaultRoot "Memory\Daily"
$sessionsDir = Join-Path $dailyDir "sessions"
New-Item -ItemType Directory -Force -Path $sessionsDir | Out-Null

$payloadRaw = [Console]::In.ReadToEnd()
if ([string]::IsNullOrWhiteSpace($payloadRaw)) { exit 0 }

try {
  $payload = $payloadRaw | ConvertFrom-Json
} catch {
  exit 0
}

if ($payload.stop_hook_active -eq $true) { exit 0 }

$transcript = [string]$payload.transcript_path
if ([string]::IsNullOrWhiteSpace($transcript) -or -not (Test-Path $transcript)) { exit 0 }

$sessionId = if ($payload.session_id) { [string]$payload.session_id } else { "unknown" }
$cwd = if ($payload.cwd) { [string]$payload.cwd } else { "unknown" }

$records = @()
Get-Content -LiteralPath $transcript | ForEach-Object {
  if (-not [string]::IsNullOrWhiteSpace($_)) {
    try { $records += ($_ | ConvertFrom-Json) } catch {}
  }
}
if ($records.Count -eq 0) { exit 0 }

function Get-TextContent($content) {
  if ($null -eq $content) { return "" }
  if ($content -is [string]) { return $content }
  if ($content -is [System.Array]) {
    $parts = @()
    foreach ($item in $content) {
      if ($item.type -eq "text" -and $item.text) { $parts += [string]$item.text }
    }
    return ($parts -join "`n`n")
  }
  return ""
}

function Get-AssistantContent($content) {
  if ($null -eq $content) { return "" }
  if ($content -is [string]) { return $content }
  if ($content -isnot [System.Array]) { return "" }

  $parts = @()
  foreach ($item in $content) {
    if ($item.type -eq "text" -and $item.text) {
      $parts += [string]$item.text
    } elseif ($item.type -eq "tool_use") {
      $name = [string]$item.name
      $detail = ""
      if ($name -eq "Bash" -and $item.input.command) {
        $cmd = ([string]$item.input.command).Replace("`n", " ")
        if ($cmd.Length -gt 160) { $cmd = $cmd.Substring(0, 160) }
        $detail = " · ``$cmd``"
      } elseif (($name -eq "Edit" -or $name -eq "Write" -or $name -eq "MultiEdit") -and $item.input.file_path) {
        $detail = " · ``$($item.input.file_path)``"
      } elseif ($name -eq "Read" -and $item.input.file_path) {
        $detail = " · ``$($item.input.file_path)``"
      }
      $parts += "[Tool: $name$detail]"
    }
  }
  return ($parts -join "`n`n")
}

$firstUser = ""
foreach ($record in $records) {
  if ($record.type -eq "user") {
    $text = Get-TextContent $record.message.content
    if (-not [string]::IsNullOrWhiteSpace($text) -and
        $text -notmatch "^<command-" -and
        $text -notmatch "^<system-" -and
        $text -notmatch "^Tool loaded\." -and
        $text -notmatch "^Caveat:" -and
        $text -notmatch "^\[Request interrupted") {
      $firstUser = $text
      break
    }
  }
}

$slugWords = (($firstUser.ToLowerInvariant() -replace "[^a-z0-9 ]", " ") -replace "\s+", " ").Trim().Split(" ", [System.StringSplitOptions]::RemoveEmptyEntries) | Select-Object -First 5
$slug = ($slugWords -join "-")
if ([string]::IsNullOrWhiteSpace($slug)) { $slug = "session" }
if ($slug.Length -gt 50) { $slug = $slug.Substring(0, 50).TrimEnd("-") }

$userCount = ($records | Where-Object { $_.type -eq "user" }).Count
$assistantCount = ($records | Where-Object { $_.type -eq "assistant" }).Count
if ($userCount -lt 1) { exit 0 }

$today = Get-Date -Format "yyyy-MM-dd"
$hhmm = Get-Date -Format "HHmm"
$timeDisplay = Get-Date -Format "HH:mm"
$tzName = (Get-TimeZone).Id

$existing = Get-ChildItem -LiteralPath $sessionsDir -Filter "*.md" -ErrorAction SilentlyContinue |
  Where-Object { Select-String -LiteralPath $_.FullName -Pattern "session_id: `"$sessionId`"" -Quiet } |
  Select-Object -First 1

if ($existing) {
  $sessionFile = $existing.FullName
  $base = [IO.Path]::GetFileNameWithoutExtension($existing.Name)
  $parts = $base.Split("_")
  $fileDate = if ($parts.Length -ge 1) { $parts[0] } else { $today }
  $fileTime = if ($parts.Length -ge 2 -and $parts[1].Length -eq 4) { "$($parts[1].Substring(0,2)):$($parts[1].Substring(2,2))" } else { $timeDisplay }
  $displayTitle = if ($parts.Length -ge 3) { ($parts[2..($parts.Length - 1)] -join "_").Replace("-", " ") } else { $slug.Replace("-", " ") }
} else {
  $sessionFile = Join-Path $sessionsDir "$($today)_$($hhmm)_$slug.md"
  $fileDate = $today
  $fileTime = $timeDisplay
  $displayTitle = $slug.Replace("-", " ")
}

$rendered = @()
foreach ($record in $records) {
  if ($record.type -eq "user") {
    $text = Get-TextContent $record.message.content
    if (-not [string]::IsNullOrWhiteSpace($text) -and
        $text -notmatch "^<command-" -and
        $text -notmatch "^<system-" -and
        $text -notmatch "^Tool loaded\." -and
        $text -notmatch "^Caveat:") {
      $rendered += "**User:**`n`n$text"
    }
  } elseif ($record.type -eq "assistant") {
    $text = Get-AssistantContent $record.message.content
    if (-not [string]::IsNullOrWhiteSpace($text)) {
      $rendered += "**Assistant:**`n`n$text"
    }
  }
}

$lastUpdated = "$today $timeDisplay $tzName"
$body = @"
---
title: "$fileDate $fileTime - $displayTitle"
type: session-transcript
date: $fileDate
time: "$fileTime"
last_updated: "$lastUpdated"
session_id: "$sessionId"
user_msgs: $userCount
assistant_msgs: $assistantCount
extracted: false
tags: [session, transcript, daily-$fileDate]
---

# $fileDate $fileTime - $displayTitle

**Auto-rendered by Stop-hook** from JSONL transcript. Overwrites at every Stop with latest content (one file per conversation).
Last updated: $lastUpdated
Daily: [[Memory/Daily/$fileDate|$fileDate]]
CWD: ``$cwd``

---

$($rendered -join "`n`n---`n`n")
"@

Set-Content -LiteralPath $sessionFile -Value $body -Encoding UTF8
exit 0
