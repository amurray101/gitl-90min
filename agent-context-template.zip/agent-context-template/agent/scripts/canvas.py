#!/usr/bin/env python3
# /// script
# requires-python = ">=3.10"
# dependencies = ["canvasapi", "python-dateutil"]
# ///
"""
Canvas LMS Integration for foundry-agent
Fetches courses, assignments, modules, announcements, files, and discussions from Stanford Canvas.
"""

import json
import os
import sys
from datetime import datetime, timedelta
from pathlib import Path

import re
from canvasapi import Canvas
from dateutil import parser as date_parser
from dateutil.tz import tzlocal


def parse_due_date_from_module_name(module_name, year=2026):
    """Extract due date from module name patterns."""
    # Pattern 1: "(due Mon. DD)" or "(due Month DD)"
    match = re.search(r'\(due ([A-Za-z]+\.?\s+\d+)\)', module_name)
    if match:
        try:
            date_str = match.group(1).replace('.', '') + f" {year}"
            return date_parser.parse(date_str).strftime("%Y-%m-%d")
        except:
            pass

    # Pattern 2: "- Day, Mon DD:" like "- Thu, Jan 8:"
    match = re.search(r'- [A-Za-z]+, ([A-Za-z]+ \d+):', module_name)
    if match:
        try:
            date_str = match.group(1) + f" {year}"
            return date_parser.parse(date_str).strftime("%Y-%m-%d")
        except:
            pass

    # Pattern 3: Exam window "(Feb 6, 5pm - Feb 9, 10pm)" - use end date
    match = re.search(r'\([A-Za-z]+ \d+.*?- ([A-Za-z]+ \d+)', module_name)
    if match:
        try:
            date_str = match.group(1) + f" {year}"
            return date_parser.parse(date_str).strftime("%Y-%m-%d")
        except:
            pass

    return None

# Config
CANVAS_URL = "https://canvas.stanford.edu"
TOKEN_FILE = Path(__file__).parent.parent / "data" / "canvas_token.txt"
DATA_DIR = Path(__file__).parent.parent / "data"


def get_token():
    """Get Canvas API token from file or environment."""
    if os.environ.get("CANVAS_TOKEN"):
        return os.environ["CANVAS_TOKEN"]
    if TOKEN_FILE.exists():
        return TOKEN_FILE.read_text().strip()
    print(f"Error: No Canvas token found. Save your token to {TOKEN_FILE}")
    sys.exit(1)


def fetch_courses(canvas):
    """Fetch active courses."""
    courses = []
    for course in canvas.get_courses(enrollment_state="active"):
        try:
            courses.append({
                "id": course.id,
                "name": getattr(course, "name", f"Course {course.id}"),
                "code": getattr(course, "course_code", ""),
            })
        except Exception:
            pass
    return courses


def fetch_module_items(canvas, course_ids=None):
    """Fetch ALL module items — graded, ungraded, pages, files, links, everything."""
    items = []

    for course in canvas.get_courses(enrollment_state="active"):
        if course_ids and course.id not in course_ids:
            continue

        course_name = getattr(course, "name", f"Course {course.id}")

        try:
            for module in course.get_modules():
                module_name = getattr(module, "name", "")
                module_position = getattr(module, "position", 0)

                try:
                    for item in module.get_module_items():
                        item_type = getattr(item, "type", "")
                        content_id = getattr(item, "content_id", None)
                        completion_req = getattr(item, "completion_requirement", None)

                        # Parse due date from module name
                        due_date = parse_due_date_from_module_name(module_name)

                        items.append({
                            "id": item.id,
                            "content_id": content_id,
                            "course_id": course.id,
                            "course_name": course_name,
                            "module_name": module_name,
                            "module_position": module_position,
                            "name": getattr(item, "title", "Untitled"),
                            "type": item_type,
                            "html_url": getattr(item, "html_url", ""),
                            "external_url": getattr(item, "external_url", ""),
                            "completion_requirement": completion_req,
                            "completed": getattr(completion_req, "completed", False) if completion_req else None,
                            "due_date": due_date,
                        })
                except Exception as e:
                    print(f"Warning: Could not fetch items for module {module_name}: {e}", file=sys.stderr)
        except Exception as e:
            print(f"Warning: Could not fetch modules for {course_name}: {e}", file=sys.stderr)

    return items


def fetch_assignments(canvas, course_ids=None):
    """Fetch upcoming assignments from courses with submission status."""
    assignments = []
    now = datetime.now(tzlocal())

    for course in canvas.get_courses(enrollment_state="active"):
        if course_ids and course.id not in course_ids:
            continue

        course_name = getattr(course, "name", f"Course {course.id}")

        try:
            for assignment in course.get_assignments(order_by="due_at"):
                due_at = getattr(assignment, "due_at", None)
                if not due_at:
                    continue

                try:
                    due_date = date_parser.parse(due_at)
                except:
                    continue

                # Only include if not past due by more than 7 days
                if due_date < now - timedelta(days=7):
                    continue

                # Fetch submission status
                submitted = False
                submission_date = None
                try:
                    submission = assignment.get_submission("self")
                    workflow_state = getattr(submission, "workflow_state", None)
                    submitted = workflow_state in ["submitted", "graded", "pending_review"]
                    if submitted and getattr(submission, "submitted_at", None):
                        submission_date = submission.submitted_at
                except Exception:
                    pass  # No submission or API error

                assignments.append({
                    "id": assignment.id,
                    "course_id": course.id,
                    "course_name": course_name,
                    "name": assignment.name,
                    "due_at": due_at,
                    "due_date": due_date.strftime("%Y-%m-%d"),
                    "due_time": due_date.strftime("%H:%M"),
                    "points_possible": getattr(assignment, "points_possible", None),
                    "html_url": getattr(assignment, "html_url", ""),
                    "description": getattr(assignment, "description", "")[:500] if getattr(assignment, "description", None) else "",
                    "submission_types": getattr(assignment, "submission_types", []),
                    "is_past_due": due_date < now,
                    "submitted": submitted,
                    "submitted_at": submission_date,
                })
        except Exception as e:
            print(f"Warning: Could not fetch assignments for {course_name}: {e}", file=sys.stderr)

    # Sort by due date
    assignments.sort(key=lambda x: x["due_at"])
    return assignments


def fetch_announcements(canvas, course_ids=None, days_back=14):
    """Fetch recent announcements across courses."""
    announcements = []
    now = datetime.now(tzlocal())
    start_date = (now - timedelta(days=days_back)).strftime("%Y-%m-%d")

    # Get course list for filtering
    courses = []
    for course in canvas.get_courses(enrollment_state="active"):
        if course_ids and course.id not in course_ids:
            continue
        courses.append(course)

    if not courses:
        return announcements

    # Canvas API: announcements are discussion topics with is_announcement=True
    # Use the announcements endpoint with context_codes
    context_codes = [f"course_{c.id}" for c in courses]

    try:
        for announcement in canvas.get_announcements(context_codes=context_codes, start_date=start_date):
            posted_at = getattr(announcement, "posted_at", None)

            announcements.append({
                "id": announcement.id,
                "course_id": getattr(announcement, "context_code", "").replace("course_", ""),
                "title": getattr(announcement, "title", "Untitled"),
                "message": getattr(announcement, "message", "")[:1000] if getattr(announcement, "message", None) else "",
                "posted_at": posted_at,
                "author": getattr(announcement, "user_name", getattr(announcement, "author", {}).get("display_name", "Unknown") if isinstance(getattr(announcement, "author", None), dict) else "Unknown"),
                "html_url": getattr(announcement, "html_url", ""),
            })
    except Exception as e:
        print(f"Warning: Could not fetch announcements: {e}", file=sys.stderr)

    # Sort by posted date, most recent first
    announcements.sort(key=lambda x: x.get("posted_at", "") or "", reverse=True)
    return announcements


def fetch_discussion_topics(canvas, course_ids=None):
    """Fetch discussion topics (non-announcement) across courses."""
    discussions = []
    now = datetime.now(tzlocal())

    for course in canvas.get_courses(enrollment_state="active"):
        if course_ids and course.id not in course_ids:
            continue

        course_name = getattr(course, "name", f"Course {course.id}")

        try:
            for topic in course.get_discussion_topics():
                # Skip announcements — those are fetched separately
                if getattr(topic, "is_announcement", False):
                    continue

                due_at = getattr(topic, "assignment", {})
                if isinstance(due_at, dict):
                    due_at = due_at.get("due_at")
                else:
                    due_at = getattr(due_at, "due_at", None) if due_at else None

                discussions.append({
                    "id": topic.id,
                    "course_id": course.id,
                    "course_name": course_name,
                    "title": getattr(topic, "title", "Untitled"),
                    "message": getattr(topic, "message", "")[:500] if getattr(topic, "message", None) else "",
                    "posted_at": getattr(topic, "posted_at", None),
                    "due_at": due_at,
                    "html_url": getattr(topic, "html_url", ""),
                    "discussion_type": getattr(topic, "discussion_type", ""),
                    "published": getattr(topic, "published", True),
                })
        except Exception as e:
            print(f"Warning: Could not fetch discussions for {course_name}: {e}", file=sys.stderr)

    return discussions


def fetch_recent_files(canvas, course_ids=None, days_back=14):
    """Fetch recently uploaded/updated files across courses."""
    files = []
    now = datetime.now(tzlocal())
    cutoff = now - timedelta(days=days_back)

    for course in canvas.get_courses(enrollment_state="active"):
        if course_ids and course.id not in course_ids:
            continue

        course_name = getattr(course, "name", f"Course {course.id}")

        try:
            for f in course.get_files(sort="updated_at", order="desc"):
                updated_at = getattr(f, "updated_at", None)
                if updated_at:
                    try:
                        updated = date_parser.parse(updated_at)
                        if updated < cutoff:
                            break  # Files are sorted desc, so stop once we're past cutoff
                    except:
                        pass

                files.append({
                    "id": f.id,
                    "course_id": course.id,
                    "course_name": course_name,
                    "filename": getattr(f, "display_name", getattr(f, "filename", "unknown")),
                    "content_type": getattr(f, "content-type", getattr(f, "mime_class", "")),
                    "size": getattr(f, "size", 0),
                    "url": getattr(f, "url", ""),
                    "created_at": getattr(f, "created_at", None),
                    "updated_at": updated_at,
                    "folder_path": getattr(f, "folder", ""),
                })
        except Exception as e:
            print(f"Warning: Could not fetch files for {course_name}: {e}", file=sys.stderr)

    return files


def main():
    import argparse

    parser = argparse.ArgumentParser(description="Canvas LMS Integration")
    parser.add_argument("command", choices=["courses", "assignments", "upcoming", "modules", "announcements", "discussions", "files", "sync"],
                       help="Command to run")
    parser.add_argument("--json", action="store_true", help="Output as JSON")
    parser.add_argument("--days", type=int, default=14, help="Days ahead/back to look")
    parser.add_argument("--course-id", type=int, help="Filter to a specific course ID")
    args = parser.parse_args()

    token = get_token()
    canvas = Canvas(CANVAS_URL, token)

    course_ids = [args.course_id] if args.course_id else None

    if args.command == "courses":
        courses = fetch_courses(canvas)
        if args.json:
            print(json.dumps(courses, indent=2))
        else:
            for c in courses:
                print(f"[{c['id']}] {c['code']}: {c['name']}")

    elif args.command in ["assignments", "upcoming"]:
        assignments = fetch_assignments(canvas, course_ids)

        if args.command == "upcoming":
            now = datetime.now(tzlocal())
            cutoff = now + timedelta(days=args.days)
            assignments = [a for a in assignments if not a["is_past_due"] and date_parser.parse(a["due_at"]) <= cutoff]

        if args.json:
            print(json.dumps(assignments, indent=2))
        else:
            for a in assignments:
                status = "✅" if a["submitted"] else ("⏰ PAST DUE" if a["is_past_due"] else "")
                print(f"[{a['due_date']} {a['due_time']}] {a['course_name']}: {a['name']} {status}")

    elif args.command == "modules":
        items = fetch_module_items(canvas, course_ids)
        if args.json:
            print(json.dumps(items, indent=2))
        else:
            for item in items:
                status = "✓" if item.get("completed") else "○"
                print(f"[{status}] {item['course_name']} > {item['module_name']}: {item['name']} ({item['type']})")

    elif args.command == "announcements":
        announcements = fetch_announcements(canvas, course_ids, days_back=args.days)
        if args.json:
            print(json.dumps(announcements, indent=2))
        else:
            for a in announcements:
                print(f"[{a['posted_at']}] {a['title']} — {a['author']}")

    elif args.command == "discussions":
        discussions = fetch_discussion_topics(canvas, course_ids)
        if args.json:
            print(json.dumps(discussions, indent=2))
        else:
            for d in discussions:
                print(f"[{d['course_name']}] {d['title']}")

    elif args.command == "files":
        files = fetch_recent_files(canvas, course_ids, days_back=args.days)
        if args.json:
            print(json.dumps(files, indent=2))
        else:
            for f in files:
                size_kb = f['size'] // 1024 if f['size'] else 0
                print(f"[{f['updated_at']}] {f['course_name']}: {f['filename']} ({size_kb}KB)")

    elif args.command == "sync":
        courses = fetch_courses(canvas)
        assignments = fetch_assignments(canvas, course_ids)
        module_items = fetch_module_items(canvas, course_ids)
        announcements = fetch_announcements(canvas, course_ids)
        discussions = fetch_discussion_topics(canvas, course_ids)
        recent_files = fetch_recent_files(canvas, course_ids)

        data = {
            "lastSync": datetime.now().isoformat(),
            "courses": courses,
            "assignments": assignments,
            "moduleItems": module_items,
            "announcements": announcements,
            "discussions": discussions,
            "recentFiles": recent_files,
        }

        output_file = DATA_DIR / "canvas.json"
        output_file.write_text(json.dumps(data, indent=2))
        print(f"Synced {len(courses)} courses, {len(assignments)} assignments, "
              f"{len(module_items)} module items, {len(announcements)} announcements, "
              f"{len(discussions)} discussions, {len(recent_files)} files "
              f"to {output_file}")


if __name__ == "__main__":
    main()
