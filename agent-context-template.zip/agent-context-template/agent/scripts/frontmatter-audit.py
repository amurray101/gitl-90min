#!/usr/bin/env python3
"""Frontmatter audit — read-only walker over the foundry-agent vault.

Emits structured findings about frontmatter drift: missing blocks, missing tags,
malformed YAML scalars, dead `updated:` dates. Stdlib-only so it runs anywhere.

Composed by /rem-cycle nightly; also invokable standalone via /frontmatter-audit.
"""
import argparse
import datetime as dt
import json
import os
import re
import sys
from pathlib import Path

DEFAULT_ROOT = Path.home() / "<vault>"

# Directories never walked. Archive is excluded by design (nothing gets deleted,
# but stale frontmatter there is not signal). .venv/.git/node_modules are noise.
EXCLUDE_DIR_NAMES = {
    "Archive",
    ".claude",
    ".git",
    "node_modules",
    ".venv",
    "venv",
    "__pycache__",
    "dist-info",
    ".obsidian",
    ".trash",
}
# Excluded path fragments (anywhere in the path). Third-party cloned repos
# under Workbench/ have foreign README/CLAUDE files that are out of scope.
EXCLUDE_PATH_FRAGMENTS = (
    "Workbench/vault-embeddings",
    "Workbench/whatsapp-access/whatsapp-mcp",
    "Workbench/imessage-access/jons-mcp-imessage",
    "/.git/",
    "/node_modules/",
)

# Forbidden characters in scalar timestamp fields (`updated:`, `arc-updated:`,
# `created:`). Per Skills/session-handoff/SKILL.md:142, these must be clean YAML
# scalars — no prose, parens, brackets, wikilinks, bold/italic, embedded colons.
SCALAR_FORBIDDEN_CHARS = ("(", ")", "[", "]", "**", "<<", ">>", "[[", "]]")
TIMESTAMP_FIELDS = ("updated", "arc-updated", "created")
DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}(\s+[A-Za-z0-9:\- ]+)?$")
WIKILINK_RE = re.compile(r"\[\[.+?\]\]")

DEAD_UPDATED_DAYS = 30  # `updated:` older than this → flag


def is_excluded(path: Path, root: Path) -> bool:
    rel = path.relative_to(root)
    parts = rel.parts
    if any(p in EXCLUDE_DIR_NAMES for p in parts):
        return True
    rel_str = str(rel)
    for frag in EXCLUDE_PATH_FRAGMENTS:
        if frag in rel_str:
            return True
    return False


def split_frontmatter(text: str):
    """Return (frontmatter_str, body_str) or (None, text) if no block."""
    if not text.startswith("---\n") and not text.startswith("---\r\n"):
        return None, text
    # Find closing fence
    lines = text.splitlines(keepends=True)
    if len(lines) < 2:
        return None, text
    for i in range(1, min(len(lines), 200)):
        if lines[i].strip() == "---":
            fm = "".join(lines[1:i])
            body = "".join(lines[i + 1 :])
            return fm, body
    return None, text


def parse_frontmatter(fm: str):
    """Best-effort YAML parse. stdlib-only — handles the flat-key shapes the
    vault actually uses (scalars, inline lists, multi-line `- item` lists).
    Returns (parsed_dict, error_msg_or_None)."""
    parsed: dict = {}
    error = None
    current_key = None
    current_list = None
    raw_value_lines: dict[str, list[str]] = {}

    for raw_line in fm.splitlines():
        if not raw_line.strip():
            current_list = None
            current_key = None
            continue
        if raw_line.startswith("- ") or raw_line.startswith("  - "):
            # Continuation of a list value
            if current_list is None:
                error = f"orphan list item: {raw_line!r}"
                continue
            current_list.append(raw_line.lstrip(" -").strip().strip("'\""))
            continue
        # New top-level key
        m = re.match(r"^([A-Za-z][A-Za-z0-9_\-]*)\s*:\s*(.*)$", raw_line)
        if not m:
            # Indented continuation? Treat as malformed for our purposes.
            if current_key:
                error = error or f"unexpected continuation under {current_key}: {raw_line!r}"
            else:
                error = error or f"unparseable line: {raw_line!r}"
            continue
        key = m.group(1).lower()
        value_raw = m.group(2).rstrip()
        current_key = key
        raw_value_lines[key] = [value_raw]

        if value_raw == "":
            # Multi-line list begins
            current_list = []
            parsed[key] = current_list
            continue
        # Inline list?
        if value_raw.startswith("[") and value_raw.endswith("]"):
            inner = value_raw[1:-1].strip()
            if not inner:
                parsed[key] = []
            else:
                items = [p.strip().strip("'\"") for p in inner.split(",")]
                parsed[key] = items
            current_list = None
            continue
        # Plain scalar
        # Strip surrounding quotes only; preserve original for char-validation
        scalar = value_raw.strip()
        if (scalar.startswith("'") and scalar.endswith("'")) or (
            scalar.startswith('"') and scalar.endswith('"')
        ):
            scalar = scalar[1:-1]
        parsed[key] = scalar
        current_list = None

    return parsed, error, raw_value_lines


def validate_scalar_field(name: str, raw_value: str, today: dt.date):
    """Return list of finding-strings for this scalar field."""
    findings = []
    stripped = raw_value.strip()
    # Strip a single layer of yaml quotes for checks
    bare = stripped
    if (bare.startswith("'") and bare.endswith("'")) or (
        bare.startswith('"') and bare.endswith('"')
    ):
        bare = bare[1:-1]

    for ch in SCALAR_FORBIDDEN_CHARS:
        if ch in bare:
            findings.append(f"{name}: forbidden char {ch!r} in value {bare!r}")
            break
    if WIKILINK_RE.search(bare):
        findings.append(f"{name}: wikilink embedded in scalar value {bare!r}")

    if name in ("updated", "arc-updated", "created"):
        if not DATE_RE.match(bare):
            findings.append(f"{name}: not a clean YYYY-MM-DD scalar (got {bare!r})")
        elif name == "updated":
            try:
                date_part = bare.split()[0]
                dt_val = dt.datetime.strptime(date_part, "%Y-%m-%d").date()
                age = (today - dt_val).days
                if age > DEAD_UPDATED_DAYS:
                    findings.append(f"updated: {age} days old (>{DEAD_UPDATED_DAYS}d)")
                if age < 0:
                    findings.append(f"updated: future-dated ({age} days ahead)")
            except ValueError:
                findings.append(f"updated: unparseable date {bare!r}")
    return findings


def audit_file(path: Path, today: dt.date):
    """Audit one file; return a finding dict (or None if clean)."""
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError as e:
        return {"path": str(path), "flags": ["read_error"], "detail": [str(e)]}

    fm, _body = split_frontmatter(text)
    flags: list[str] = []
    detail: list[str] = []

    if fm is None:
        flags.append("missing_frontmatter")
        return {"path": str(path), "flags": flags, "detail": detail, "type": None}

    parsed, parse_err, raw_value_lines = parse_frontmatter(fm)
    if parse_err:
        flags.append("malformed_yaml")
        detail.append(parse_err)

    if "tags" not in parsed:
        flags.append("missing_tags")
    else:
        tags_val = parsed.get("tags")
        if not isinstance(tags_val, list):
            flags.append("malformed_tags")
            detail.append(f"tags is {type(tags_val).__name__}, expected list")

    for field in TIMESTAMP_FIELDS:
        if field in parsed:
            raw = raw_value_lines.get(field, [""])[0]
            field_findings = validate_scalar_field(field, raw, today)
            for ff in field_findings:
                if "forbidden char" in ff or "wikilink" in ff or "not a clean" in ff or "unparseable" in ff:
                    if "malformed_yaml" not in flags:
                        flags.append("malformed_yaml")
                elif "days old" in ff:
                    flags.append("dead_updated")
                elif "future-dated" in ff:
                    flags.append("future_updated")
                detail.append(ff)

    return {
        "path": str(path),
        "flags": flags,
        "detail": detail,
        "type": parsed.get("type"),
    }


def walk(root: Path):
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in EXCLUDE_DIR_NAMES]
        for fname in filenames:
            if not fname.endswith(".md"):
                continue
            full = Path(dirpath) / fname
            if is_excluded(full, root):
                continue
            yield full


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--root", type=Path, default=DEFAULT_ROOT)
    p.add_argument("--json", action="store_true", help="Emit full JSON to stdout")
    p.add_argument("--summary", action="store_true", help="Counts only")
    p.add_argument("--limit", type=int, default=0, help="Max findings to include in JSON output (0 = no limit)")
    args = p.parse_args()

    if not args.root.exists():
        print(f"frontmatter-audit: root not found: {args.root}", file=sys.stderr)
        return 2

    today = dt.date.today()
    scanned = 0
    findings = []
    type_counts: dict[str, int] = {}

    for path in walk(args.root):
        scanned += 1
        result = audit_file(path, today)
        if result.get("type"):
            t = result["type"]
            type_counts[t] = type_counts.get(t, 0) + 1
        if result["flags"]:
            findings.append(result)

    summary = {
        "scanned": scanned,
        "with_findings": len(findings),
        "clean": scanned - len(findings),
        "by_flag": {},
        "type_counts": dict(sorted(type_counts.items(), key=lambda kv: -kv[1])),
    }
    for f in findings:
        for flag in f["flags"]:
            summary["by_flag"][flag] = summary["by_flag"].get(flag, 0) + 1

    if args.summary and not args.json:
        print(f"scanned: {scanned}")
        print(f"clean:   {summary['clean']}")
        print(f"flagged: {summary['with_findings']}")
        for flag, n in sorted(summary["by_flag"].items(), key=lambda kv: -kv[1]):
            print(f"  {flag}: {n}")
        print("type frequencies:")
        for t, n in summary["type_counts"].items():
            print(f"  {t}: {n}")
        return 0

    out = {"summary": summary, "findings": findings}
    if args.limit and len(findings) > args.limit:
        out["findings"] = findings[: args.limit]
        out["truncated"] = True
    print(json.dumps(out, indent=2, default=str))
    return 0


if __name__ == "__main__":
    sys.exit(main())
