#!/usr/bin/env bash
# session-capture-hook.sh v3
#
# Stop-hook companion to /handoff. Renders the FULL current state of a session
# transcript as readable markdown to a single vault file per session_id —
# overwriting at every Stop fire with the latest content. ONE file per
# conversation, not per turn.
#
# Architecture:
#   $VAULT_ROOT/Memory/Daily/sessions/YYYY-MM-DD_HHMM_<slug>.md  ← full transcript, overwrites at every Stop
#
# Does NOT write to the daily file. /handoff curates daily entries from the
# session files. Future rem-cycle integration can update daily link blocks.
#
# Vault is canonical. Never writes to ~/.claude/.
# Reads JSON payload on stdin from Claude Code Stop hook event.
# Always exits 0 (never blocks stop).

set +e

VAULT_ROOT="${VAULT_ROOT:-$(cd "$(dirname "$0")/../.." && pwd)}"
DAILY_DIR="$VAULT_ROOT/Memory/Daily"
SESSIONS_DIR="$VAULT_ROOT/Memory/Daily/sessions"
TODAY=$(date +%Y-%m-%d)
NOW_HHMM=$(date +%H%M)
NOW_DISPLAY=$(date +%H:%M)
TZ_NAME=$(date +%Z)
DAILY_FILE="$DAILY_DIR/$TODAY.md"

# Read stdin payload
PAYLOAD=$(cat)
[ -z "$PAYLOAD" ] && exit 0

TRANSCRIPT=$(echo "$PAYLOAD" | jq -r '.transcript_path // empty' 2>/dev/null)
SESSION_ID=$(echo "$PAYLOAD" | jq -r '.session_id // "unknown"' 2>/dev/null)
CWD=$(echo "$PAYLOAD" | jq -r '.cwd // "unknown"' 2>/dev/null)
STOP_HOOK_ACTIVE=$(echo "$PAYLOAD" | jq -r '.stop_hook_active // false' 2>/dev/null)

# Avoid loops
[ "$STOP_HOOK_ACTIVE" = "true" ] && exit 0
# Skip if no transcript
[ -z "$TRANSCRIPT" ] && exit 0
[ ! -f "$TRANSCRIPT" ] && exit 0

# --- Extract opening prompt for slug + metadata ---
FIRST_USER=$(jq -rs '
  [ .[] | select(.type == "user") |
    ( .message.content
      | if type == "string" then .
        elif type == "array" then (map(select(.type == "text") | .text) | join(" "))
        else "" end
    )
  ] | map(select(
    . != null and . != ""
    and (test("^<command-") | not)
    and (test("^<system-") | not)
    and (test("^Tool loaded\\.") | not)
    and (test("^Caveat:") | not)
    and (test("^Base directory for this skill:") | not)
    and (test("^Local command caveat:") | not)
    and (test("^\\[Request interrupted") | not)
  )) | .[0] // ""
' "$TRANSCRIPT" 2>/dev/null)

# Slug: kebab-cased first 5 words of opening prompt, hard-capped at 50 chars.
# Collapse newlines to spaces FIRST so multi-line skill bodies become one line.
SLUG=$(echo "$FIRST_USER" | tr '\n' ' ' | tr '[:upper:]' '[:lower:]' \
  | tr -c 'a-z0-9 ' ' ' \
  | tr -s ' ' \
  | awk '{
      s = ""
      n = (NF < 5) ? NF : 5
      for (i = 1; i <= n; i++) {
        s = s $i
        if (i < n) s = s "-"
      }
      if (length(s) > 50) s = substr(s, 1, 50)
      sub(/-+$/, "", s)
      print s
      exit
    }')
[ -z "$SLUG" ] && SLUG="session"

USER_MSG_COUNT=$(jq -rs '[.[] | select(.type == "user")] | length' "$TRANSCRIPT" 2>/dev/null || echo 0)
ASSISTANT_MSG_COUNT=$(jq -rs '[.[] | select(.type == "assistant")] | length' "$TRANSCRIPT" 2>/dev/null || echo 0)

[ "$USER_MSG_COUNT" -lt 1 ] && exit 0

# Files touched (Edit / Write / MultiEdit / NotebookEdit)
FILES_TOUCHED=$(jq -rs '
  [ .[] | select(.type == "assistant") | (.message.content // [])[]?
    | select(.type == "tool_use" and (.name == "Edit" or .name == "Write" or .name == "MultiEdit" or .name == "NotebookEdit"))
    | (.input.file_path // .input.notebook_path // empty)
  ] | unique | .[] // empty
' "$TRANSCRIPT" 2>/dev/null | grep -v '^$' | head -50)

BASH_COUNT=$(jq -rs '
  [.[] | select(.type == "assistant") | (.message.content // [])[]?
   | select(.type == "tool_use" and .name == "Bash")] | length
' "$TRANSCRIPT" 2>/dev/null || echo 0)

EDIT_COUNT=$(echo "$FILES_TOUCHED" | grep -c . || echo 0)
FILE_COUNT_DISPLAY=$(echo "$FILES_TOUCHED" | grep -c . | tr -d ' ')

# --- Render full conversation ---
RENDERED_CONVO=$(jq -rs '
  def render_user_text:
    if type == "string" then .
    elif type == "array" then (
      [ .[] | if .type == "text" then .text else empty end ] | join("\n\n")
    )
    else "" end;

  def summarize_tool_use:
    "[Tool: " + .name +
    (
      if .name == "Bash" then
        " · `" + ((.input.command // "") | .[0:160] | gsub("\n"; " ")) + "`"
      elif (.name == "Edit" or .name == "Write" or .name == "MultiEdit") then
        " · `" + (.input.file_path // "") + "`"
      elif .name == "Read" then
        " · `" + (.input.file_path // "") + "`"
      elif .name == "Grep" then
        " · pattern=`" + ((.input.pattern // "") | .[0:80]) + "`"
      elif .name == "Glob" then
        " · pattern=`" + ((.input.pattern // "") | .[0:80]) + "`"
      elif .name == "Agent" then
        " · " + (.input.description // "")
      elif .name == "Skill" then
        " · skill=" + (.input.skill // "")
      elif .name == "TodoWrite" or .name == "TaskCreate" or .name == "TaskUpdate" then
        ""
      elif .name == "WebFetch" then
        " · " + (.input.url // "")
      elif .name == "WebSearch" then
        " · `" + ((.input.query // "") | .[0:80]) + "`"
      else "" end
    ) + "]";

  def render_assistant_content:
    if type == "array" then (
      [ .[] |
        if .type == "text" then .text
        elif .type == "tool_use" then summarize_tool_use
        else empty end
      ] | join("\n\n")
    )
    else "" end;

  [ .[] | select(.type == "user" or .type == "assistant") |
    if .type == "user" then
      ( .message.content | render_user_text ) as $txt |
      if ($txt | length) > 0
         and ($txt | test("^<command-") | not)
         and ($txt | test("^<system-") | not)
         and ($txt | test("^Tool loaded\\.") | not)
         and ($txt | test("^Caveat:") | not)
      then
        "**User:**\n\n" + $txt
      else empty end
    elif .type == "assistant" then
      ( .message.content | render_assistant_content ) as $txt |
      if ($txt | length) > 0 then
        "**Assistant:**\n\n" + $txt
      else empty end
    else empty end
  ] | join("\n\n---\n\n")
' "$TRANSCRIPT" 2>/dev/null)

# --- Set up paths ---
# Look up existing session file by session_id frontmatter — ensures one file
# per conversation, overwritten on each Stop with latest content.
mkdir -p "$SESSIONS_DIR"
EXISTING_FILE=$(grep -l "^session_id: \"$SESSION_ID\"$" "$SESSIONS_DIR"/*.md 2>/dev/null | head -1)

if [ -n "$EXISTING_FILE" ]; then
  SESSION_FILE="$EXISTING_FILE"
  # Preserve original filename (date + first-Stop-time + first-Stop-slug)
  SESSION_BASENAME=$(basename "$SESSION_FILE" .md)
  # Parse the existing time from filename for display
  ORIG_DATE=$(echo "$SESSION_BASENAME" | cut -d'_' -f1)
  ORIG_HHMM=$(echo "$SESSION_BASENAME" | cut -d'_' -f2)
  ORIG_TIME_DISPLAY="${ORIG_HHMM:0:2}:${ORIG_HHMM:2:2}"
  SESSION_DISPLAY_TITLE=$(echo "$SESSION_BASENAME" | cut -d'_' -f3- | tr '-' ' ')
  # For the file content, use original date/time but include "last updated" current
  FILE_DATE="$ORIG_DATE"
  FILE_TIME_DISPLAY="$ORIG_TIME_DISPLAY"
else
  SESSION_FILE="$SESSIONS_DIR/${TODAY}_${NOW_HHMM}_${SLUG}.md"
  SESSION_DISPLAY_TITLE=$(echo "$SLUG" | tr '-' ' ')
  FILE_DATE="$TODAY"
  FILE_TIME_DISPLAY="$NOW_DISPLAY"
fi

# --- Write/overwrite session file ---
LAST_UPDATED="$TODAY $NOW_DISPLAY $TZ_NAME"
{
  echo "---"
  echo "title: \"$FILE_DATE $FILE_TIME_DISPLAY — $SESSION_DISPLAY_TITLE\""
  echo "type: session-transcript"
  echo "date: $FILE_DATE"
  echo "time: \"$FILE_TIME_DISPLAY\""
  echo "last_updated: \"$LAST_UPDATED\""
  echo "session_id: \"$SESSION_ID\""
  echo "user_msgs: $USER_MSG_COUNT"
  echo "assistant_msgs: $ASSISTANT_MSG_COUNT"
  echo "bash_calls: $BASH_COUNT"
  echo "files_edited: $EDIT_COUNT"
  echo "extracted: false"
  echo "tags: [session, transcript, daily-$FILE_DATE]"
  echo "---"
  echo ""
  echo "# $FILE_DATE $FILE_TIME_DISPLAY — $SESSION_DISPLAY_TITLE"
  echo ""
  echo "**Auto-rendered by Stop-hook** from JSONL transcript. Overwrites at every Stop with latest content (one file per conversation)."
  echo "Last updated: $LAST_UPDATED"
  echo "Daily: [[Memory/Daily/$FILE_DATE|$FILE_DATE]]"
  echo ""
  echo "## Metadata"
  echo ""
  echo "- **User msgs:** $USER_MSG_COUNT"
  echo "- **Assistant msgs:** $ASSISTANT_MSG_COUNT"
  echo "- **Bash calls:** $BASH_COUNT"
  echo "- **Files edited:** $EDIT_COUNT"
  echo "- **Session ID:** \`$SESSION_ID\`"
  echo "- **CWD:** \`$CWD\`"
  echo "- **Source JSONL:** \`$TRANSCRIPT\`"
  echo ""
  if [ -n "$FILES_TOUCHED" ]; then
    echo "## Files touched"
    echo ""
    while IFS= read -r f; do
      [ -z "$f" ] && continue
      echo "- \`$f\`"
    done <<< "$FILES_TOUCHED"
    echo ""
  fi
  echo "## Conversation"
  echo ""
  echo "$RENDERED_CONVO"
  echo ""
} > "$SESSION_FILE"

exit 0
