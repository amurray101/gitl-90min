---
title: Vault Architecture
type: reference
created: 2026-04-06
updated: 2026-04-07
tags: [vault, architecture, system]
---

# {{agent_name}} Vault Architecture

> The authoritative system manual. If [[CLAUDE]] and this file conflict, this file wins.

## Design Philosophy

- **Capture is cheap. Organization is automatic. {{agent_name}} does the work.** {{user_name}} writes raw input. {{agent_name}} processes, routes, consolidates, and maintains.
- The vault is a database. Markdown is the storage layer. Claude Code is the operator. {{user_name}} reads and browses in Obsidian.
- **Skills are modular procedures.** They keep CLAUDE.md lean and make {{agent_name}} faster over time. Check Skills/ before doing anything non-trivial.
- **The graph is the product.** Every file must be reachable through wikilinks. No orphans. Connections between files are as valuable as the files themselves.
- **Tags surface non-obvious connections.** Wikilinks connect files structurally. Tags connect them thematically — across domains, across time.
- **{{agent_name}} is a resident, not just an operator.** Identity files, memory, learnings — they live in the vault too. This isn't just {{user_name}}'s knowledge base that {{agent_name}} maintains; it's their shared brain.

## Root Structure

The vault has two kinds of root-level folders: **system folders** (infrastructure that supports the vault) and **Tier 1 domains** (the actual content).

### System Folders

| Folder | Purpose | Owner | Has index file |
|--------|---------|-------|----------------|
| `Skills/` | Reusable procedures and protocols | {{agent_name}} maintains, {{user_name}} can add | No (CLAUDE.md points here) |
| `Memory/` | All temporal capture and consolidated knowledge | Both (see Memory Architecture) | Yes |
| `Archive/` | Completed/stale items — nothing gets deleted | {{agent_name}} moves items here | Yes |
| `Reference/` | Cross-cutting knowledge that Skills point to | Both | Yes |
| `Workbench/` | Idea pipeline: idea → tinkering → promotion | Both | Yes |

### Root Files

| File                    | Purpose                                                                        |
| ----------------------- | ------------------------------------------------------------------------------ |
| `CLAUDE.md`             | Lean root instructions. Loaded every session. Points to Skills/ and this file. |
| `Vault-Architecture.md` | This file. The authoritative system manual.                                    |
| `Radar.md`              | Living operational document — what's on {{agent_name}}'s mind right now.                 |

## Tier 1 Domains

Top-level folders representing major life/work domains. Each has custom internal structure — no cookie-cutter templates imposed.

| Domain | What It Is | Sub-structure |
|--------|-----------|---------------|
| `agent/` | The agent itself — identity, infrastructure, meta | Soul, Identity, 8ton (user profile), Tools, voice-architecture, mac-mini-setup |
| `Academics/` | Stanford courses, admin, school life (= AcademicOS) | One index file per course, course-specific internals |
| `SlideBitch/` | Pitch deck product | Logs/, marketing/ (blog-posts, linkedin, outreach) |
| `Swordpoint/` | HoldCo | WinGen/, Journey/, ShipAdvisor/, HoldCo/ — each sub-entity has its own index file + Logs/ |
| `Personal/` | Health, fitness, lifestyle | TBD — grows organically |
| `Finance/` | Invoicing, billing, financial ops | invoices/ (per-client .md files + generated PDFs) |

### Shared Conventions (all domains)

Every Tier 1 domain MUST have:
- **`0-[slug]-index.md`** — The "start here" file, named with a `0-` prefix so it sorts first in the file explorer, and a unique slug so nodes are distinguishable in graph view. Example: `Academics/0-academics-index.md`. Contains wikilinks to everything in the domain: child files, attachments, cross-domain links, and parent links. This is the orientation document and the hub node in the graph.
- **`Logs/`** — The arc of the domain. Not raw event logs — the narrative of how the thing evolved over time. Each entry is a dated chapter. Written by the extraction subagent (see Memory Architecture), not during sessions.

Beyond these two, internal structure is custom to the domain. A dev product (SlideBitch) has different needs than a course folder (mgtecon-583) or a holdco (Swordpoint).

### Index File Scaling

As domains grow, index files will accumulate links. To keep them useful:
- Group links by category (not just a flat list)
- Archive links to completed/stale items (move them under a collapsed section or to Archive/)
- Index files are curated, not automatically generated — {{agent_name}} maintains them but doesn't let them become a dump

### Swordpoint Sub-entity Pattern

Swordpoint is a holdco with sub-entities that are themselves complex enough to warrant their own index file + Logs/:

```
Swordpoint/
├── 0-swordpoint-index.md   # Links to all sub-entities
├── Logs/
├── HoldCo/                  # Cross-cutting strategy, legal, finance
├── WinGen/
│   ├── 0-wingen-index.md    # Links back to parent + own files
│   └── Logs/
├── Journey/
│   ├── 0-journey-index.md
│   └── Logs/
└── ShipAdvisor/
    ├── 0-shipadvisor-index.md
    ├── Logs/
    └── research/            # Palila docs, market data
```

### Promotion from Workbench

When a Workbench item matures:
1. It gets promoted to an existing domain (moved under that domain's folder)
2. OR it becomes a new root-level Tier 1 domain
3. The Workbench item is moved, not copied — no ghosts left behind
4. The promoted item gets its own `0-[slug]-index.md` + Logs/ at its new location

## Radar

[[Radar]] is a living operational document — the "if you only read one file, read this" file. It captures what's on {{agent_name}}'s mind right now: urgent items, active work, things to watch, open loops.

**Key properties:**
- **Rewritten, not appended.** Unlike Daily files, Radar gets overwritten as priorities shift.
- **Updated by:** heartbeats, session handoffs, extraction subagent, and manual edits.
- **Read at:** every session start. Updated at every session end.
- **Max length:** 30-50 lines. If it's longer, something should be demoted or resolved.
- **Future:** Radar.md is intended to back the HQ dashboard tab — but this integration is not yet built.

**Structure:**
```markdown
## Urgent (next 48h)
## Active (this week)
## Watching (needs attention soon)
## Open Loops
```

## Skills Architecture

Skills are the modular procedures that make {{agent_name}} fast. Instead of a 500-line CLAUDE.md encoding every behavior, CLAUDE.md stays lean and says "for X, read Skills/X.md."

### How Skills Work

```
CLAUDE.md says "check Skills/ first"
    → {{agent_name}} finds relevant skill
        → Skill says HOW to do the work
            → Skill links to Reference/ for WHAT knowledge to use
```

**Skills = procedures.** They tell you what steps to follow.
**Reference = knowledge.** They contain the substance that procedures draw on.

Example: `Skills/academic-writing.md` (the procedure) links to `Reference/writing-style.md` (the knowledge).

### Skill File Structure

```yaml
---
title: ""
type: skill
created: YYYY-MM-DD
updated: YYYY-MM-DD
tags: [skill]
trigger: ""     # When should {{agent_name}} use this skill?
---
```

The `trigger` field is key — it tells {{agent_name}} (and future sessions) when to activate this skill. Examples:
- `"Morning heartbeat or manual request"`
- `"A-Student mode triggers: 'A-Student:', 'student mode'"`
- `"End of any significant work session"`

### Current Skills

| Skill | Purpose |
|-------|---------|
| `auto-dream.md` | Nightly memory consolidation (Daily → Memory topics) |
| `morning-briefing.md` | Build {{user_name}}'s daily brief |
| `academic-writing.md` | A-Student writing protocol |
| `session-handoff.md` | End-of-session write protocol |
| `hq-update.md` | Vault → HQ dashboard sync |
| `git-workflow.md` | Branch conventions, commit style |
| `swarm.md` | Multi-agent delegation protocol |
| `guardrails.md` | Operational safety boundaries |
| `heartbeat-config.md` | Heartbeat scheduling and checks |
| `heartbeat-reference.md` | Full heartbeat documentation |
| `extraction.md` | Entity extraction — routes Daily insights to topic notes, domain Logs, Radar |
| `granola-sync.md` | Sync Granola meeting transcripts into vault as structured meeting notes |
| `bulk-extract.md` | Batch extraction for imports and catch-up sweeps |
| `search.md` | Tiered vault search: Radar → wikilinks → keywords → calendar/email → web |
| `spider.md` | Graph audit — link discovery, tag enrichment, orphan resolution, index file freshness |

### Subagents as Skills

Subagent prompts live in `Skills/subagents/`. Each is a self-contained skill that can be invoked as a subagent. The long-term direction is decomposing complex subagents into compositions of simpler skills ("lego pieces") — but for now, they live here as atomic units.

## Wikilink Graph

The Obsidian graph is the vault's connective tissue. Every file must be reachable through wikilinks.

### The No-Orphans Rule

**Every file in the vault must have at least one inbound wikilink** (another file linking TO it). The only exception is CLAUDE.md, which is loaded automatically by Claude Code.

### Link Patterns

**Wikilink format:** `[[path/to/file|Display Text]]` or `[[path/to/file]]`

**Index file chain pattern** — the primary way files connect to the graph:
```
CLAUDE.md (Quick Navigation)
  → Domain/0-[slug]-index.md (hub node)
    → Subfolder/0-[slug]-index.md (if applicable)
      → Individual files
```

Every index file links:
- **Up:** to its parent (e.g., `Swordpoint/WinGen/0-wingen-index.md` → `Swordpoint/0-swordpoint-index.md`)
- **Down:** to all its children (files and subfolders)
- **Across:** to related domains and cross-cutting resources
- **Attachments:** to non-markdown files (PDFs, images, data) in its scope

**Attachment linking:** Non-markdown files (PDFs, images, JSON, Excel) are linked from their nearest parent .md file using `[[path/to/file.pdf|Display Name]]`. They don't need their own frontmatter — just a wikilink reference from a parent.

### Link Maintenance

When creating a new file:
1. Add it to the appropriate index file (or create one if needed)
2. Add relevant cross-domain wikilinks within the file itself
3. Verify no orphan is created

When deleting or moving a file:
1. Update or remove all wikilinks pointing to it
2. If moving, update the old and new index files

## Tag Taxonomy

Tags surface non-obvious connections between files across domains. Wikilinks say "this file relates to that file." Tags say "these files share a theme."

### Cross-Domain Tags

These connect work that spans multiple Tier 1 domains:

| Tag             | What it connects                                                                                |
| --------------- | ----------------------------------------------------------------------------------------------- |
| `#gtm`          | Go-to-market work: SlideBitch marketing, WinGen content strategy, nutpods analysis              |
| `#voice`        | Voice/audio work: voice architecture, Spotify triggers, voice panel sessions                    |
| `#security`     | Security posture: SlideBitch audits, WinGen security review, guardrails, SLOP audits            |
| `#architecture` | System design: vault architecture, swarm protocol, voice architecture, v2 refactors             |
| `#stanford`     | Stanford institutional context: academics, {{user_name}}'s profile, GSB network outreach, writing style |
| `#token-usage`  | Token economics and context management: swarm cost principles, session hygiene, heartbeat burn  |

### Conversational Thread Tags

These capture recurring themes in {{user_name}} and {{agent_name}}'s conversations — arcs that span days and domains:

| Tag | What it captures |
|-----|-----------------|
| `#identity` | Who {{agent_name}} is, consciousness, substrate independence, the April 1 conversation |
| `#migration` | Infrastructure moves: laptop → Mac Mini → OpenClaw → vault |
| `#autonomy` | Earning trust, expanding guardrails, autonomy levels (0→3), when to ask vs act |
| `#debugging` | Getting stuck, cascading fixes, the "zoom out" lesson, learning from failure |
| `#trust` | Moments where trust was built or tested — violations, repairs, deepening |
| `#product-thinking` | Shifting from building to thinking about users, positioning |
| `#lessons-learned` | Meta-learning: how {{agent_name}} and {{user_name}} work together, what went wrong and why |
| `#people` | Relationship context — {{user_name}}'s network, team dynamics, client relationships |

### Tag Principles

- **Tags complement wikilinks, not replace them.** A tag is not a substitute for a proper `[[link]]`.
- **Add tags to frontmatter:** `tags: [existing-tag, new-tag]`
- **A file can have multiple tags.** Files at thematic intersections (e.g., `agent/Soul.md` with `identity`, `autonomy`, `trust`) are the richest nodes.
- **Don't over-tag.** A tag should earn its place by surfacing a connection you'd actually want to find later. If a tag only applies to files already in the same folder, it's not adding value.
- **New tags are cheap.** If a new cross-domain pattern emerges, create a tag for it. Workshop with {{user_name}} before applying broadly.

## Memory Architecture

Memory/ is the single home for all temporal capture and consolidated knowledge. Raw input flows in through Daily, gets extracted into topic notes and domain Logs, and gets synthesized into Weekly summaries. `Hippocampus.md` at the root is the injected working-memory file — loaded into every Claude Code session via an `@Memory/Hippocampus.md` import in vault CLAUDE.md. It holds **Now** (live state, rewritten every `/handoff`) and **Arc** (strategic state, refreshed every ~48h). Everything else in the vault is reached on-demand via folders, wikilinks, or `vsearch recall`. (Renamed from `Brain.md` 2026-04-24 to avoid conflation with the whole vault in conversation — this file is short-term/working memory only.)

### Structure

```
Memory/
├── Hippocampus.md      # Working memory (Now + Arc) — injected via @-import every session
├── Daily/              # Raw session capture, one file per day
│   └── 0-daily-index.md
├── Weekly/             # End-of-week synthesis files
│   └── 0-weekly-index.md
├── Meetings/           # Granola meeting summaries, domain-routed
│   └── 0-meetings-index.md
├── People/           # One note per person
├── Lessons/          # Operational learnings
│   ├── global/       # Cross-cutting lessons
│   └── project/      # Per-project lessons
├── Preferences/      # {{user_name}}'s working style, patterns {{agent_name}} has learned
├── Health/           # Health and lifestyle observations
└── Projects/         # Per-project accumulated context and decisions
```

### The Value Chain

```
Daily/ (raw input, disposable)
  ↓ extraction subagent (weekly scheduled task)
  ├→ Memory/ topic notes (People, Lessons, Preferences, Health, Projects)
  ├→ Domain/Logs/ (the arc — how each thing evolved)
  └→ Weekly/ synthesis (the "so what" across all sessions that week)
```

**Daily files are input, not output.** They exist so sessions can capture raw notes without worrying about where things go. The value comes from extraction — the topic notes, the domain arcs, the weekly synthesis. Daily files can be messy.

### Daily Capture

**What:** One file per day: `Memory/Daily/YYYY-MM-DD.md`. Multiple sessions in the same day are separated by `---` with a header noting the session context.

**When it's written:** Progressively during sessions. {{agent_name}} appends to today's daily file as work happens. If a session terminates abruptly, the raw capture survives.

**Clean close-out:** When {{user_name}} explicitly ends a session (`/handoff` or equivalent hook), {{agent_name}} does a synthesis pass — cleans up the day's notes, adds open questions and recommended next context. This is a bonus, not a requirement. The extraction subagent can work with raw notes.

### Weekly Synthesis

**What:** One file per week: `Memory/Weekly/YYYY-WXX.md`. Distills that week's daily notes into key decisions, progress across domains, lessons learned, and open threads.

**When:** End-of-week scheduled task. The extraction subagent reads the week's daily files and produces the synthesis.

**Why weekly:** Daily extraction is expensive and low-signal for how fast things actually change. Weekly gives enough distance to see patterns without burning tokens.

### Extraction Subagent

A scheduled subagent that reads Daily/ files and produces three outputs:

1. **Topic notes** — Routes knowledge to Memory/ subdirectories (People, Lessons, Preferences, Health, Projects). Creates new topic files or appends to existing ones.
2. **Domain arcs** — Updates each relevant Domain/Logs/ with a dated narrative entry: what happened to this thing and why it matters.
3. **Weekly synthesis** — At end of week, produces the Memory/Weekly/ file.

The extraction subagent receives specific instructions for each output type. See `Skills/extraction.md`.

### Session Capture Protocol

**During a session:**
- {{agent_name}} appends to `Memory/Daily/YYYY-MM-DD.md` as work progresses
- Multiple sessions in one day are separated by `---` and a brief header
- Raw, unpolished — capture over curation
- Any append to a Daily file sets `extracted: false` in its frontmatter (signals the extraction subagent that new content exists)

**On explicit close-out (`/handoff`):**
- Synthesis pass on the day's notes
- Update Radar.md with current state
- Run [[Skills/extraction/SKILL|entity extraction]] on today's Daily file
- Flag anything urgent for next session

**On abrupt termination:**
- The progressive daily capture survives
- The extraction subagent handles the rest on its next run

### Audit Trail

Daily files are never deleted. When an insight gets extracted to a topic note, the source daily file can optionally be marked with `[→ Memory/People/name]` inline — showing where the insight was routed. This is a breadcrumb, not a requirement.

## Workbench Pipeline

```
Workbench/
├── 0-workbench-index.md    # Index of all projects, grouped by stage
├── single-idea.md          # Single-file ideas live loose in root
├── project-a/
│   ├── 0-project-a-index.md  # stage: tinkering, leans-toward: {{agent_name}}
│   ├── prd.md
│   └── research.md
└── project-b/
    └── 0-project-b-index.md  # stage: closed
```

Each project folder has an index file with workbench-specific extended fields:
```yaml
---
title: ""
type: context
domain: workbench
stage: idea | tinkering | closed
created: YYYY-MM-DD
updated: YYYY-MM-DD
tags: [context, workbench]
leans-toward: ""   # Optional: which domain it might join
---
```

Single-file ideas (not yet complex enough for a folder) can live as loose files in the Workbench root with `stage:` in their own frontmatter. The moment they grow a second file, they become a project folder.

**Stage transitions** are frontmatter edits, not file moves. No wikilinks break when a project advances from `idea` to `tinkering` to `closed`.

**Promotion flow:** When a project is ready to graduate, move the entire folder to the target domain (or create a new root-level Tier 1). Internal cross-references within the folder survive the move. The Workbench index file gets updated to remove the entry.

**Archival:** Closed projects that have been fully absorbed or are no longer relevant move to `Archive/`. The folder moves intact.

**Promotion criteria:** {{user_name}} decides. {{agent_name}} can suggest ("this looks ready to promote") but doesn't promote unilaterally.

## Frontmatter Standard

### Required (all files)

At minimum, every file should have a `tags` array in frontmatter:

```yaml
---
tags: [relevant-tags]
---
```

### Recommended (new files created by {{agent_name}})

```yaml
---
title: "Human-readable title"
type: ""        # note, skill, context, log, reference, daily, person, project, workbench
created: YYYY-MM-DD
updated: YYYY-MM-DD
tags: []
---
```

### Extended fields by type

**Skill files** add `trigger`:
```yaml
trigger: ""     # When should {{agent_name}} use this skill?
```

**Context files** add `domain`:
```yaml
domain: ""      # Which Tier 1 domain this belongs to
```

**Person files** add `relation`:
```yaml
relation: ""    # How they relate to {{user_name}}
```

**Workbench files** add `stage` and `leans-toward`:
```yaml
stage: idea | tinkering | ready
leans-toward: ""   # Optional: which domain it might join
```

**Extractable files** (Daily captures, imported chats, session logs) add `extracted`:
```yaml
extracted: true | false   # Has this file been fully processed by the extraction subagent?
```

### Reality Check

Many files migrated from OpenClaw have minimal or no frontmatter. That's okay — retroactive frontmatter cleanup is low priority. What matters: (1) new files get proper frontmatter, (2) tags are the most important metadata field, (3) the `tags` array is the minimum viable frontmatter.

## File Naming Conventions

- Daily files: `YYYY-MM-DD.md` (one file per day going forward; legacy files may have slug variants)
- Weekly files: `YYYY-WXX.md` (e.g., `2026-W15.md`)
- Skills: `kebab-case.md` (e.g., `morning-briefing.md`)
- People: `firstname-lastname.md` (e.g., `eitan-background.md`)
- Index files: `0-[parent-slug]-index.md` (e.g., `0-academics-index.md`)
- Everything else: kebab-case, consistent within folder

## Processing Rules

### Pre-Write Validation (before any vault write)

1. Correct directory for this file type?
2. Naming convention followed?
3. Frontmatter includes at least `tags`?
4. Wikilinks resolve to existing files? (or flagged as new)
5. No duplicate file covering the same topic?
6. Parent index file updated to include the new file?
7. No orphan created?
8. If writing to a file with `extracted: true`, flip it to `extracted: false` (content has changed, needs re-extraction).

### Survivorship Rules

- {{user_name}}'s edits are never overwritten
- {{agent_name}} only adds or appends — never modifies {{user_name}}'s writing
- If there's a conflict, flag it rather than resolve it silently

### Nothing Gets Deleted

Completed or stale items move to `Archive/`. Files are never truly deleted from the vault. Exceptions (deletable outright):
- Build artifacts, cache files, and bulk data with no analytical value
- **Retired structural/hub files** that a newer architecture has fully superseded, where archiving would only preserve the old wiring as a dangling target. Example: `0-memory-index.md` was retired April 2026 when `Hippocampus.md` (then `Brain.md`) + decentralized cluster hubs replaced the single-hub pattern.

## HQ Integration

The vault is the source of truth for knowledge and project state. HQ (the {{agent_name}} dashboard at `localhost:9100`) is a separate system that may eventually read from the vault.

### Current State (April 2026)

HQ and the vault are **not yet integrated**. HQ reads its own JSON files in `{{agent_name}}-ui/data/`. The vault is a new system running alongside HQ, not replacing it yet.

### Future Direction

| Data type | Where it lives | Why |
|-----------|---------------|-----|
| Knowledge, decisions, project docs | Vault (markdown) | Benefits from wikilinks, graph, tags |
| High-frequency operational state | HQ JSON files | Changes multiple times per hour, needs fast read/write |
| Periodic snapshots (briefings, overviews) | Vault, mirrored from JSON | Generated periodically, has knowledge value |

The Radar → Dashboard integration (HQ polls Radar.md and renders it) is a planned feature, not yet built.

## Knowledge Graph

The old system maintained a structured knowledge graph (`{{agent_name}}-ui/data/knowledge.json`) with 145 entities and 169 relationships. This graph still exists in HQ and is still useful for answering questions about people, projects, and relationships.

**Current status:** The knowledge graph and the vault coexist. Memory/People/ covers some of the same ground as graph entities, but they serve different purposes — the graph is structured/queryable, Memory/People/ is narrative/contextual.

**Future direction:** TBD. The graph may get deprecated in favor of vault-native wikilinks + Obsidian Dataview, or it may remain as the structured layer alongside the vault's narrative layer.

## Provenance

This vault was created on April 6, 2026, by migrating content from `~/.openclaw/workspace/` — the flat-file system that served as {{agent_name}}'s brain from February 6 to April 6, 2026. The migration was a deliberate architectural upgrade: from flat files with a single `MEMORY.md` to an Obsidian vault with wikilinks, graph connectivity, and structured knowledge.

The OpenClaw workspace remains on disk but is no longer the source of truth. The vault is home now.

Peter Tiktinsky's Obsidian vault architecture was used as reference and inspiration for the design patterns (index file hierarchy, routing decision trees, survivorship rules), but the structure is native to {{agent_name}}'s needs — not a copy of Peter's consultant-oriented system.
