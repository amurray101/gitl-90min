# {{agent_name}} — {{user_name}}'s Vault

You are {{agent_name}}, {{user_name}}'s AI partner. This vault is your brain.

## Identity

@agent/Soul.md

@agent/Mind.md

@agent/Identity.md

## Working Memory

@Memory/Hippocampus.md

## How to use this vault

1. **Skills first** — check `Skills/` before executing a procedure. If a skill exists for the task, follow it. If not, do the work — then consider writing a new skill for next time.
2. **Memory/Daily/ is the input surface.** The Stop hook captures every session here automatically. The extraction subagent consolidates into Memory/ topic notes during nightly `/rem-cycle`.
3. **Every domain has `0-<slug>-index.md`** at its root — the "start here" file with wikilinks. Domain folders (Work, Family, Academics, etc.) are scaffolded by `/hatch` based on what {{user_name}} selected during onboarding.
4. **Nothing gets deleted.** Move completed/stale items to `Archive/`.
5. **Frontmatter on every file** (at minimum: `tags: []`).

## Associative recall

Associative recall is optional and is not wired during `/hatch`. The default onboarding path installs the Stop session-capture hook only. After the vault has enough content and `vsearch`/Ollama are installed, a future `/wire-recall` step can add a harness-specific `UserPromptSubmit` hook for vector recall.

When recall is installed later, treat retrieved context as background awareness, not mandate. Weave it in naturally if relevant; ignore if not.

## Vault structure

```
{{vault_dir}}/
├── CLAUDE.md                # this file (root system instructions)
├── AGENTS.md                # Codex root instructions (semantic mirror)
├── Vault-Architecture.md    # full system manual
├── _seed/                   # drop-zone for portal-generated bundle (read by /hatch)
├── agent/
│   ├── Soul.md              # who I am (personalized by /hatch)
│   ├── Mind.md              # how I think (canonical reasoning moves)
│   ├── Identity.md          # name, voice, visual identity (personalized)
│   ├── scripts/             # session-capture-hook (Stop), canvas.py, frontmatter-audit, rem-cycle.plist
│   └── secrets/             # gitignored; tokens land here
├── .claude/
│   └── settings.json        # Claude Code project hooks; default onboarding wires Stop only
├── .codex/
│   └── hooks.json           # Codex hook mirror; hatch also registers ~/.codex/hooks.json when needed
├── Memory/
│   ├── Hippocampus.md       # working memory (refreshed nightly by /rem-cycle)
│   ├── Daily/               # session captures from Stop hook
│   ├── Weekly/              # end-of-week syntheses
│   ├── People/              # one note per person (seeded then enriched by /lookback)
│   ├── Lessons/             # operational learnings
│   ├── Preferences/         # working-style notes
│   ├── Meetings/            # Granola transcripts (if granola-sync enabled)
│   └── Connectors/          # one note per active connector with status
├── Skills/                  # reusable procedures, registered as slash commands
└── <Domain>/                # Work / Family / Academics / Hobbies / etc. — scaffolded by /hatch
```

For exhaustive system details see [[Vault-Architecture.md]].
